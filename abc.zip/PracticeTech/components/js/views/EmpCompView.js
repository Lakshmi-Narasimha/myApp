﻿define([
  'jquery',
  'underscore',
  'backbone',
  'appcommon/commonutility',
  'spinner',
  'components/js/views/AggregateView',
  'components/js/model/EmpCompModel',
  'text!components/template/EmpCompTemplate.html',
  'components/js/views/RadioButtonView',
  'appmodules/ncst/app/data/country-list',
  'appcommon/constants',
  'appmodules/ncst/app/js/lib/validate-4.2',
  'text!components/template/EmpCompViewTemplate.html',
], function ($, _, Backbone, CommonUtils, Spinner, AggregateView, EmpCompModel, EmpCompTemplate, RadioButtonsView, DropDownListOptions, Constants, Validator, EmpCompViewTemplate) {
    var self;
    var EmpCompView = AggregateView.extend({
        // PUBLIC PROPERTIES/FUNCTIONS
        //setEmployerCompanyInfo: function (empCompInfo) { this.employerCompanyInfo = _.clone(empCompInfo); },
        //getEmployerCompanyInfo: function () { return self.populateModelFromView(new EmpCompModel()); },
        triggerFieldEvents: null, // OPTIONAL: function(Object) ... callback when tab out from inputs...
        triggerCancelBtnEvt: null, // OPTIONAL: function(Object) ... callback when cancel button is clicked...arg is the selected container

        // PRIVATE PROPERTIES/FUNCTIONS
        employerCompanyInfo: null, // EmpCompModel

        employercomptemplate: _.template(EmpCompTemplate),
        employercompViewTemplate: _.template(EmpCompViewTemplate),
        //radioBtnViewName: 'radioBtnViewName',
        componentName: null,
        componentNameSmLetters: null,
        componentId: 0,
        launchMode: "edit", //default mode is edit. Possible values 'view' and 'edit'
        initializeElementVars: function () {
            //var self = this;
            this.componentNameSmLetters = this.componentName.toLowerCase();

            this.$compNm = this.componentNameSmLetters;
            this.$compId = this.componentId;
            this.$employerName = this.$('#pt-' + this.$compNm + '-name-' + this.$compId);
            this.$addressType = this.$('#pt-' + this.$compNm + '-addrs-type-' + this.$compId);
            this.$address1 = this.$('#pt-' + this.$compNm + '-addrs1-' + this.$compId);
            this.$address2 = this.$('#pt-' + this.$compNm + '-addrs2-' + this.$compId);
            this.$courtesyCountryList = this.$('#pt-' + this.$compNm + '-countrylist-' + this.$compId);
            this.$city = this.$('#pt-' + this.$compNm + '-city-' + this.$compId);
            this.$courtesyStateList = this.$('#pt-' + this.$compNm + '-state-list-' + this.$compId);
            this.$provinceList = this.$('#pt-' + this.$compNm + '-province-list-select-' + this.$compId);
            this.$province = this.$('#pt-' + this.$compNm + '-province-list-select-' + this.$compId);
            this.$courtesyZipCode = this.$('#pt-' + this.$compNm + '-uszipcode-' + this.$compId);
            this.$primaryOccupation = this.$('#pt-' + this.$compNm + '-prioccupation-' + this.$compId)
            this.$priOccupationOther = this.$('#pt-employer-other-' + this.$compId);
            this.$jobTitle = this.$('#pt-' + this.$compNm + '-jobtitle-' + this.$compId);
            this.$tickerSymbol = this.$('#pt-' + this.$compNm + '-ticker-symbol-' + this.$compId);
        },
        events: {
            'keypress [data-for="us-zipcode"]': 'validateZipCodeLength',
            'blur input[type="text"], input[type="tel"], input[type="number"]': 'handleChangeAndBlurEvent',
            'change .trigger-change-event': 'handleChangeAndBlurEvent',
            'change input[type = "radio"]': 'handleAddressTypeChange',
            'click .cancel-the-section-btn': 'handleCancelBtn',
            'change [pt-empcomp-prioccupation]': 'handlePriOccupationChange',
            'change [pt-empcomp-country-list]': 'handleProvinceForCanadaChange',
            'keypress .us-zipcode': CommonUtils.numValidator
        },
        initialize: function (options) {
            self = this;
            AggregateView.prototype.initialize.apply(this, arguments);
            _.extend(this, _.pick(options, 'info', 'componentName', 'componentId', 'count', 'showPrimOccpatn', 'showJobTitleField'));
            this.employerCompanyInfo = options.compData;
        },
        render: function () {
            if (!this.employerCompanyInfo) {
                this.employerCompanyInfo = new EmpCompModel().toJSON();
            }
            this.employerCompanyInfo.launchMode = this.launchMode;
            this.renderTemplate();
            $("#ncst-user-home-view").invokeInfoPopup();
        },
        renderTemplate: function () {
            var launchMode =  this.launchMode;
            var empCompInformation = this.employerCompanyInfo;
            var selectedAddrsType = empCompInformation.addressType;
            var selectedCountryCd = empCompInformation.countryNm;
            var selectedUSStateCd = empCompInformation.state;
            var selectedPriOccupationCd = empCompInformation.primaryOccupation;
            var jobTitleCd = empCompInformation.jobTitle;


            this.$el.empty();
            if (launchMode == "edit") {
                this.$el.html(this.employercomptemplate({ showJobTitleField: this.showJobTitleField, showPrimOccpatn: this.showPrimOccpatn, addrsModel: empCompInformation, componentName: this.componentName, componentId: this.componentId, count: this.count }));
                // Initialization of Element Vars
                this.initializeElementVars();
                // Radio Template
                this.renderAddrsTypeRadioButtons(selectedAddrsType, this.componentName, this.componentId, self.$courtesyStateList, self.$courtesyCountryList, self.$courtesyZipCode);

                //Render Country List
                this.renderCountryList(selectedCountryCd);
                //Render State List
                this.renderUSStatesList(selectedUSStateCd);
                if (selectedAddrsType && selectedAddrsType == "Foreign") {
                    this.handleProvinceForCanadaChange(undefined, true/*donot clear state/province falg*/);
                    if (empCompInformation.province) {
                        this.$provinceList.val(empCompInformation.province);
                    }

                }

                //Render Pri Occupation
                this.renderPriOccupation(selectedPriOccupationCd, self.$priOccupationOther);
            } else {
                this.$el.html(this.employercompViewTemplate({ componentName: this.componentName, componentId: this.componentId, count: this.count, addrsModel: empCompInformation }));
                // Initialization of Element Vars
                this.initializeElementVars();
            }
            
        },
        reRender: function () {
            this.renderTemplate();
        },
        validateComponent: function () {
            this.populateModelFromView();
            return true;
        },
        clearAddressRelatedFields: function () {
            this.$address1.val("");
            this.$address2.val("");
            this.$courtesyCountryList.val("");
            this.$city.val("");
            this.$courtesyStateList.val("");
            this.$provinceList.val("");
            this.$courtesyZipCode.find('input[type="text"]').val("");
        },
        handleAddressTypeChange: function (e) {
            this.clearAddressRelatedFields();
            this.handleChangeAndBlurEvent(e);
        },
        handleChangeAndBlurEvent: function (e) {
            e.preventDefault();
            e.stopPropagation();
            this.populateModelFromView();
            if (this.triggerFieldEvents && this.launchMode == "edit") {
                this.triggerFieldEvents(e.modelPropNm, e.value);
            }
        },
        handleCancelBtn: function (e) {
            var target = e.target || e.currentTarget;
            var $ele = $(target);
            var itemIdentifier = $ele.data('identifier');
            if (this.triggerCancelBtnEvt) {
                this.triggerCancelBtnEvt(itemIdentifier, e);
            }
        },
        handlePriOccupationChange: function (e) {
            var target = e.target || e.currentTarget;
            var $ele = $(target);
            var $otherContainer = this.$priOccupationOther;
            var $other = $otherContainer.children();
            var isOtherVisible = $otherContainer.is(":visible");

            if ($ele.val() == "Other") {
                if (!isOtherVisible) {
                    $otherContainer.removeClass('hidden');
                    $other.attr('value', '');
                    $other.focus();
                }
            } else {
                if (isOtherVisible) {
                    $other.attr('value', '');
                    $otherContainer.addClass('hidden');
                }
            }
        },
        handleProvinceForCanadaChange: function (e, donotClearField) {
            //var target = e.target || e.currentTarget;
            var $ele = this.$courtesyCountryList.find('select');
            var dataIdentifier = $ele.data('identifier');

            var selectedCountry = $ele.val();
            var compNm = this.componentNameSmLetters;
            var compId = dataIdentifier;
            var $zipCode = $("#pt-" + compNm + "-zipcode-" + compId);
            var $zipCodeSection = $("[data-for='pt-" + compNm + "-zipcode-" + compId + "']");

            if (selectedCountry == "CA") {
                $("div[data-for=pt-" + compNm + "-state-list-" + compId + "]").addClass('hidden');
                if (!donotClearField) {
                    $("#pt-" + compNm + "-state-list-" + compId + "").val("").trigger('change');
                }
                $("div[data-for=pt-" + compNm + "-province-list-" + compId + "]").removeClass('hidden');
                //$("#pt-" + compNm + "-province-list-" + compId + "").removeClass('hidden');
                $zipCode.parent().parent().removeClass('hidden');
                $zipCodeSection.find('label.field-label').text('Postal code');
                $zipCode.removeClass('us-zipcode').addClass("canada-zipcode");
                $zipCode.attr('type', 'text');
            } /*else if ($('input[name=empAddressType]:checked').val() == "Foreign") {
                $("div[data-for=pt-" + compNm + "-state-list-" + compId +"]").addClass('hidden');
                $("div[data-for=pt-" +compNm + "-province-list-"+ compId +"]").addClass('hidden');
                $("#pt-" + compNm + "-province-list-"+ compId +"").val("").trigger('change');
                $("#pt-" +compNm + "-province-list-"+ compId +"").val("");
                $zipCode.parent().parent().addClass('hidden');
                $zipCode.val('');
                $zipCode.removeClass("required");
            }*/ else {
                $("div[data-for=pt-" + compNm + "-province-list-" + compId + "]").addClass('hidden');
                if (!donotClearField) {
                    $("#pt-" + compNm + "-province-list-" + compId + "").val("").trigger('change');
                }
                //$("div[data-for=pt-" + compNm + "-state-list-"+ compId +"]").removeClass('hidden');
                $zipCodeSection.find('label.field-label').text('Zip code');
                $zipCode.removeClass('canada-zipcode').addClass('us-zipcode');
                $zipCode.attr('type', 'text');
                $zipCode.parent().parent().addClass('hidden');
            }
        },
        numValidator: function(obj) {
                var _regxNumOnly = /^\d*$/;
                var _str = String.fromCharCode(event.keyCode);
                var _maxlength = obj.currentTarget.maxLength;
                var _value = obj.currentTarget.value;
                if (!_regxNumOnly.test(_str)
                        || _value.length >= _maxlength) {
                    obj.stopPropagation();
                    if (event.preventDefault)
                        event.preventDefault();
                    return false;
                        }
            },
        validateZipCodeLength: function (e) {
            var target = e.target || e.currentTarget;
            var $ele = $('#'+target.id);
            var dataIdentifier = $ele.data('identifier').split('-');
            var compNm = dataIdentifier[0]; //Employer/Finra/Company
            var compId = dataIdentifier[1];

            var addressTypeSelected = $("input[name=select-choice-pt-" + compNm + "-addrs-type-" + compId + "]:checked").val();
            var countrySelected = $("#pt-" + compNm + "-country-list-" + compId).val();

            if (addressTypeSelected == "U.S") {
                if ($ele.val().length >= 5) {
                    e.stopPropagation();
                    e.preventDefault();
                    return false;
                }
            } else if (countrySelected == "CA") {
                if ($ele.val().length >= 6) {
                    e.stopPropagation();
                    e.preventDefault();
                    return false;
                }
            }
        },
        renderCountryList: function (selectedCountryCd) {
            var countryList = DropDownListOptions.countryList;
            var countrySelectBox = "#pt-" + self.componentNameSmLetters + "-country-list-" + self.componentId;
            CommonUtils.loadSelectbox([countrySelectBox], countryList, selectedCountryCd);
        },
        renderUSStatesList: function (selectedUSStateCd) {
            var stateList = DropDownListOptions.USStateslist;
            var stateSelectBox = "#pt-" + self.componentNameSmLetters + "-state-list-" + self.componentId;
            CommonUtils.loadSelectbox([stateSelectBox], stateList, selectedUSStateCd);
        },
        renderAddrsTypeRadioButtons: function (selectedAddrsType, componentName, componentId, courtesyStateList, courtesyCountryList, courtesyZipCode) {
            var radioButtonsView,
                self = this,
                addressTypeItems = [
                    { description: 'U.S', id: 'pt-' + componentName.toLowerCase() + '-addrstypeus' + componentId },
                    { description: 'Foreign', id: 'pt-' + componentName.toLowerCase() + '-addrstypeforeign' + componentId }
                ];
            radioButtonsView = new RadioButtonsView({
                el: self.$("#pt-" + componentName.toLowerCase() + "-addrs-type-" + componentId),
                items: addressTypeItems
            });

            $.each(addressTypeItems, function (key) {
                if (addressTypeItems[key].description == selectedAddrsType) {
                    radioButtonsView.selectedItem = addressTypeItems[key];
                } else {
                    radioButtonsView.selectedItem = addressTypeItems[0];
                }
            });
            radioButtonsView.triggerPreSelection = false;
            var preselectedItem = addressTypeItems[0];
            if (selectedAddrsType == "Foreign") {
                preselectedItem = addressTypeItems[1];
            }
            self.captureAddressTypeSelection(preselectedItem, courtesyStateList, courtesyCountryList, courtesyZipCode);
            radioButtonsView.itemSelectionComplete = function (selectedItem) {
                self.captureAddressTypeSelection(selectedItem, courtesyStateList, courtesyCountryList, courtesyZipCode);
                self.populateModelFromView();
            };

            var radioBtnViewName = 'radioBtnViewName' + componentId;
            self.addNestedView(radioBtnViewName, radioButtonsView);

            radioButtonsView.render();
        },
        renderPriOccupation: function (selectedPriOccupationCd, $priOccupationOther) {
            var $priOccupationContainer = $("#pt-" + self.componentNameSmLetters + "-pri-occupation-" + self.componentId);
            if (!self.showPrimOccpatn && self.componentNameSmLetters == "employer") {
                $priOccupationContainer.addClass('hidden');
                $priOccupationOther.addClass('hidden');
            } else if (self.showPrimOccpatn && self.componentNameSmLetters == "employer") {
                if (selectedPriOccupationCd == 'Other') {
                    $priOccupationOther.removeClass('hidden');
                } else {
                    $priOccupationOther.addClass('hidden');
                }
                $priOccupationContainer.removeClass('hidden');
                var priOccupationList = Constants.employerPriOccupationList;
                var priOccupationSelectBox = "#pt-" + self.componentNameSmLetters + "-prioccupation-" + self.componentId;
                CommonUtils.loadSelectbox([priOccupationSelectBox], priOccupationList, selectedPriOccupationCd);
            }
        },
        captureAddressTypeSelection: function (toggleValue, courtesyStateList, courtesyCountryList, courtesyZipCode) {
            this.courtesyAddrsTypeSelected = toggleValue;
            var stateContainer = $("div[data-for=pt-" + this.$compNm + "-state-list-" + this.$compId + "]");
            var provinceContainer = $("div[data-for=pt-" + this.$compNm + "-province-list-" + this.$compId + "]");
            var provinceListId = '#pt-' + this.$compNm + '-province-list-select-' + this.$compId;
            var countryListId = '#pt-' + this.$compNm + '-country-list-' + this.$compId;

            if (toggleValue.description != 'Foreign') { //US
                stateContainer.removeClass('hidden');
                courtesyStateList.removeClass('hidden');
                courtesyZipCode.removeClass('hidden');

                courtesyZipCode.find('label.field-label').text('Zip code');
                courtesyZipCode.find('input').removeClass('canada-zipcode').addClass('us-zipcode').attr('type', 'text');
                courtesyCountryList.find('#pt-employer-country-list-1').val();

                courtesyCountryList.find(countryListId).val($(countryListId + " option:first").val()); //Default to first option
                courtesyCountryList.addClass('hidden');

                provinceContainer.find(provinceListId).val($(provinceListId + " option:first").val());
                provinceContainer.addClass('hidden');
            } else { //Foreign
                stateContainer.addClass('hidden');
                courtesyStateList.addClass('hidden');
                courtesyZipCode.addClass('hidden');
                courtesyCountryList.removeClass('hidden');
            }
        },
        populateModelFromView: function () {
            var countryCd,
                countryNm,
                provinceCd,
                provinceNm,
                stateCd,
                stateNm;
            if (this.launchMode == "view") {
                this.employerCompanyInfo.tickerSymbol = this.$tickerSymbol.val();
                return;
            }
            
            this.clearFieldValuesFromModel();
            this.employerCompanyInfo.compId = this.$compId;
            this.employerCompanyInfo.compNm = this.$compNm;
            this.employerCompanyInfo.employerName = this.$employerName.val();
            this.employerCompanyInfo.addressType = this.$addressType.find('input[name="select-choice-pt-' + this.$compNm + '-addrs-type-' + this.$compId + '"]:checked').val();
            this.employerCompanyInfo.address1 = this.$address1.val();
            this.employerCompanyInfo.address2 = this.$address2.val();
            countryCd = this.$courtesyCountryList.find('option:selected').val();
            this.employerCompanyInfo.countryNm = countryCd;
            if (!countryCd) {
                countryNm = "";
            } else {
                countryNm = this.$courtesyCountryList.find('option:selected').text();
            }
            this.employerCompanyInfo.countryFullNm = countryNm;
            this.employerCompanyInfo.city = this.$city.val();
            stateCd = this.$courtesyStateList.find('option:selected').val();
            this.employerCompanyInfo.state = stateCd;
            if (!stateCd) {
                stateNm = "";
            } else {
                stateNm = this.$courtesyStateList.find('option:selected').text();
            }
            this.employerCompanyInfo.stateFullNm = stateNm;
            provinceCd = this.$province.find('option:selected').val();
            this.employerCompanyInfo.province = provinceCd;
            if (!provinceCd) {
                provinceNm = "";
            } else {
                provinceNm = this.$province.find('option:selected').text();
            }
            this.employerCompanyInfo.provinceFullNm = provinceNm;
            this.employerCompanyInfo.zipCode = this.$courtesyZipCode.find('input[type="text"]').val();
            this.employerCompanyInfo.primaryOccupation = this.$primaryOccupation.find('option:selected').val();
            this.employerCompanyInfo.priOccupationOther = this.$priOccupationOther.children().val();
            this.employerCompanyInfo.jobTitle = this.$jobTitle.val();
            this.employerCompanyInfo.tickerSymbol = this.$tickerSymbol.val();
        },
        clearFieldValuesFromModel: function () {
            this.employerCompanyInfo.addressType = "";
            this.employerCompanyInfo.address1 = "";
            this.employerCompanyInfo.address2 = "";
            this.employerCompanyInfo.countryNm = "";
            this.employerCompanyInfo.countryFullNm = "";
            this.employerCompanyInfo.city = "";
            this.employerCompanyInfo.state = "";
            this.employerCompanyInfo.stateFullNm = "";
            this.employerCompanyInfo.province = "";
            this.employerCompanyInfo.provinceFullNm = "";
            this.employerCompanyInfo.zipCode = "";
            this.employerCompanyInfo.employerName = "";
            this.employerCompanyInfo.primaryOccupation = "";
            this.employerCompanyInfo.priOccupationOther = "";
            this.employerCompanyInfo.jobTitle = "";
            this.employerCompanyInfo.tickerSymbol = "";
        },
        isTheAddressValid: function () {
            var isAddressValid = true,
                self = this,
                addressType = this.employerCompanyInfo.addressType,
                ObjectKeys = ["employerName", "addressType", "address1", "city"],
                addressModel;
            if (addressType == "Foreign") {
                ObjectKeys.push("countryNm");
                if (self.employerCompanyInfo.countryNm == "CA") {
                    ObjectKeys.push("province", "zipCode");
                } 
            } else {
                ObjectKeys.push("state", "zipCode");
            }
            addressModel = _.pick(self.employerCompanyInfo, ObjectKeys);
            if (!addressModel.hasOwnProperty("employerName")) {
                isAddressValid = false;
            }
            for (var key in addressModel) {
                if(!CommonUtils.hasValue(addressModel[key])){
                    isAddressValid = false;
                }
            }
            return isAddressValid;
        }

    });
    return EmpCompView;
});
