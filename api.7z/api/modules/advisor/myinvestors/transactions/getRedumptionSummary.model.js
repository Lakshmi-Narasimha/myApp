// getFundComposition.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var RedumptionSummaryModelSchema = new mongoose.Schema({
    RedumptionSummaryResp: {
        type: Array,
        "default": []
    }
});

var RedumptionSummaryModelLookUp = mongoose.model('RedumptionSummaryModelLookUp', RedumptionSummaryModelSchema);

var RedumptionSummaryModel = new RedumptionSummaryModelLookUp({
    RedumptionSummaryResp : {
        "redemption": {
            "fundWiseData": [
                {
                    "folioNo": "2341621",
                    "fund": "Franklin India Equity Fund - Growth",
                    "familySolutions": "Yes",
                    "totalRedemptionAmount": "23,987"
                },
                {
                    "folioNo": "124523",
                    "fund": "Franklin India Equity Fund - Growth",
                    "familySolutions": "Yes",
                    "totalRedemptionAmount": "23,987"
                }
            ],
            "grandTotal": "47,974"
        }
    }
});

RedumptionSummaryModelLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having trouble in creating RedumptionSummaryModelLookUp table, please contact admin...');
    } else {
        RedumptionSummaryModelLookUp.remove({}, function(err) {
            console.log('RedumptionSummaryModelLookUp collection removed');
            RedumptionSummaryModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating RedumptionSummaryModelLookUp table, please contact admin...');
                }
                console.log('RedumptionSummaryModelLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = RedumptionSummaryModelLookUp;
