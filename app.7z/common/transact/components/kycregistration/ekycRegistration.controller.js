/**
 * @ngdoc property
 * @name ekycRegistrationCtrl Controller
 * @requires $scope
 * @description
 *
 * - 
 *
 **/


 'use strict';
// Controller naming conventions should start with an uppercase letter
function ekycRegistrationCtrl($scope, transactModel,$state,transactEventConstants,ekycVerificationModel,otpGenerationModel,authenticationService) {    
	console.log("ekycRegistration controller");	
	$scope.closeFlow = false;
	$scope.openFlow = true;
	$scope.resultObj;
	var instantKycVals = [];

	$scope.folioId =  transactModel.getSelectedFolioDts().folioId;
	$scope.inputObj = transactModel.getSelectedFolioDts().holderDetails;
	$scope.config.transactHeader = {};
	$scope.config.transactHeader.title = "KYC Registration";
	$scope.$emit("setBreadCrumb",{cat : "kycReg"});

	$scope.folioIdheader = {
		heading : 'FolioId : '+$scope.folioId
	};

	$scope.physicalKycValidation = function(){
		$scope.phyResult = false;
		angular.forEach($scope.resultObj, function(value, key){
			if ($scope.resultObj[key].aadhar == "" || null || undefined) {
				$scope.phyResult = true;
			}
		});
		return $scope.phyResult;
	}

	$scope.checkTerms =  {
		label:"I give consent to FT to access details from AADHAAR database on behalf of all the unit holders.",
		value:"",
		required : true,
		name: 'checkTerms'
	}

	$scope.continue = function(){
		if ($scope.ekycReg.$valid) {
			$scope.$broadcast(transactEventConstants.transact.INSTANT_KYC);
			$scope.resultObj = $scope.ekycReg.kycVal;
			if ($scope.physicalKycValidation()) {
				transactModel.setInstantKyc = [];
				$scope.closeFlow = true;
				$scope.openFlow = false;
			}
			else{
				instantKycVals = $scope.ekycReg.kycVal;
				angular.forEach(instantKycVals,function(obj,key){

					obj.pan = $scope.inputObj[key].pan;
					obj.kycStatus = $scope.inputObj[key].kycStatus;
					instantKycVals[key] = obj;


				}); 
				transactModel.setInstantKyc(instantKycVals);
				console.log("Came back after setting" + instantKycVals);
				var requestAadharObj = [];

				if(instantKycVals.length > 0){
					requestAadharObj.push({"adrPANPkrn":instantKycVals[0].aadhar.toString()});
				}
				if(instantKycVals.length > 1){
					requestAadharObj.push({"adrPANPkrn":instantKycVals[1].aadhar.toString()});
				}
				if(instantKycVals.length > 2){
					requestAadharObj.push({"adrPANPkrn":instantKycVals[2].aadhar.toString()});
				}

				var requestObject = {
                              paramObj: {"guId" : authenticationService.getUser().guId},
                              bodyObj: {
                                "validateOTPeKYC":requestAadharObj
                              }
                 }
				ekycVerificationModel.generateAndSendEkycOtp(requestObject).then(otpDtlsSuccess, otpDtlsFailure);
				
			}                    
		}
	}

	$scope.handleContinue = function(){
            $state.go("transactnow.ekycVerification");
        }

        function otpDtlsSuccess(data) {   
        	otpGenerationModel.setOtpDetails(data);     
        	$scope.handleContinue();
        };
        function otpDtlsFailure(error){
        	console.log(error);
        	$scope.handleContinue();
        }
    }

    ekycRegistrationCtrl.$inject = ['$scope','transactModel','$state','transactEventConstants','ekycVerificationModel','otpGenerationModel','authenticationService'];
    module.exports = ekycRegistrationCtrl;