var express = require('express');
var https = require('https');
var http = require('http');
var querystring = require('querystring');
var logger = require('../../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var router = express.Router();
var engagementModel = require('./engagement.model');
var getMessageModel = require('../getMessage/getMessage.model');
var dataPassModel = require('../dataPass/dataPass.model');
var myCache = require('../../../api-server');
var apiUtils = require('../../common/apiUtils');
var proxy = require('../../../config/proxy')

/* Trigerring the Engagement API on request from Client */
// API Route
router.route('/mfchatnode/rest/engagement')
    .post(function(req, res) {

        logger.general.info(logger.formatInBoundReqMsg(req));

        req.body.RequestParams = req.body.RequestParams || {};       
        req.session.agentGroupID = req.body.RequestParams.agentGroupID;
        req.session.nickName = req.body.RequestParams.nickName;
        req.session.accRole = req.body.RequestParams.accRole;
        req.session.MDN = req.body.RequestParams.MDN;        
        if(req.body.RequestParams.InitialParams && req.body.RequestParams.InitialParams.model.toUpperCase().indexOf("IPAD") > -1){
            req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID] + engagementModel.createLaunchType[req.body.RequestParams.agentGroupID+'_IPad'];
            req.session.businessRuleID = engagementModel.businessRuleID[req.body.RequestParams.agentGroupID+'_IPad'];
        }else{
            req.uri = engagementModel.createRequestUri[req.body.RequestParams.agentGroupID] + engagementModel.createLaunchType[req.body.RequestParams.agentGroupID];
            req.session.businessRuleID = engagementModel.businessRuleID[req.body.RequestParams.agentGroupID];
        }
        /* Trigerring the Engagement API internally to TC */
        var initialMessage = encodeURI(req.body.RequestParams.InitialMessage);
        logger.formatConvsStrtMsg(req);
        var reqObj = {
            host: config.TC_SERVER_NAME,
            method: 'GET',
            path: req.uri + '&InitialMessage=' + initialMessage,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Cookie': req.session.sessionCookie,
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            rejectUnauthorized: true
        };

        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
        var resbody = [];
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            proxyResponse.on('data', function(chunk) {                
                resbody.push(chunk);
            }).on('end', function(){
                logger.general.info(logger.formatOutBoundResMsg(reqObj, resbody, req.session.id));                
                chunk = JSON.parse(resbody);
                if (chunk.engagementID) {
                    engagementModel.response.Page.status = (chunk.status === "queued" ? "accepted" : chunk.status);
                    engagementModel.response.Page.engagementID = req.engagementID = req.session.engagementID = chunk.engagementID; /// storing engagementID into the session
                    engagementModel.response.Page.customerID = req.session.customerID = chunk.customerID; /// storing customerID into the session
                    engagementModel.ResponseInfo.topMessage = "It may take a few moments to connect";
                    engagementModel.ResponseInfo.type = "ChatTop";
                    engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
                    engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
                    //req.session.chatSendMsgCounter = (req.session.chatSendMsgCounter || 1);
                    myCache.set(req.session.engagementID+'.Datapass' , apiUtils.getUserInfo(req));
                    myCache.set(req.session.engagementID+'.VATranscript' , apiUtils.getVATranscript(req.body.RequestParams.VATranscript)); 
                    logger.general.info(logger.formatInfoMsg(req.session.id, req.session.agentGroupID+ " chat started with engagementID "+ req.engagementID));                                  
                    apiUtils.generateToken(req, res, function(tokenResponse) {                            
                            tokenResponse = tokenResponse || {};
                            tokenResponse.data = tokenResponse.data || {primaryMS: '', secondaryMS: ''};
                            if (tokenResponse.data && tokenResponse.data.primaryMS) {
                                var primaryMS = {
                                    //url: 'dev1ms.sdc.vzwcorp.com',
                                    port: tokenResponse.data.primaryMS.slice(-4),
                                    url: tokenResponse.data.primaryMS.slice(0, -5)
                                        //port: '1885'
                                };
                                engagementModel.response.Page.primaryMS = primaryMS;
                                logger.general.info(logger.formatInfoMsg(req.session.id, "UDM primaryMS " + JSON.stringify(engagementModel.response.Page.primaryMS))); 
                            } else {
                                engagementModel.response.Page.primaryMS = tokenResponse.data.primaryMS;
                            }
                            if (tokenResponse.data && tokenResponse.data.secondaryMS) {
                                var secondaryMS = {
                                    //url: 'dev1ms.sdc.vzwcorp.com',
                                    port: tokenResponse.data.secondaryMS.slice(-4),
                                    url: tokenResponse.data.secondaryMS.slice(0, -5)
                                        //port: '1885'
                                };
                                engagementModel.response.Page.secondaryMS = secondaryMS;
                                logger.general.info(logger.formatInfoMsg(req.session.id, "UDM secondaryMS " + JSON.stringify(engagementModel.response.Page.secondaryMS)));                               
                            } else {
                                engagementModel.response.Page.secondaryMS = tokenResponse.data.secondaryMS;
                            }
                            engagementModel.response.Page.token = tokenResponse.data.token;
                            engagementModel.response.Page.deviceId = tokenResponse.data.deviceId;
                            engagementModel.response.Page.topic = tokenResponse.data.topic;
                            engagementModel.response.ModuleMap.Support.startMsgId = -1;                            
                            logger.general.info(logger.formatInBoundResMsg(req, engagementModel.response));
                            res.send(engagementModel.response);
                    });
                                       
                     if (req.session.agentGroupID !== 'WirelessSales') {
                         req.session.isSales = false;  
                     }else{
                         req.session.isSales = true;
                     }  
                } else {
                   var errObj = {
                        message: proxyResponse.statusMessage,
                        statusCode: proxyResponse.statusCode
                    };
                    logger.error.error(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id)); 
                    logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                    res.send(errObj);                      
                }
            });
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));                                
                res.send(err);
            });
        });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    });

module.exports = router;
