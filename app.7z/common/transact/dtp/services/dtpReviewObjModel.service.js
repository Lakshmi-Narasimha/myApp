/**
 * @ngdoc service
 * @name reviewSwpDetailsModel
 * @description
 *
 * - It will have the setter and getter components of switch details
 *
 */

'use strict';

var reviewDtpDetailsModel = function (Restangular, $q, fticLoggerMessage, loggerConstants) {
    var _swpObj = null;
    var _detailsObj = null, _type = null;
    var reviewDtpDetailsModel = {

        fetchTxnDetailsSwp : function (params) {
            
            var deferred = $q.defer();
            //Restangular.all('/getNewInvBanks').getList().then(function (preRegBanks) {
                Restangular.one('getTxnDetailsSwp').get(params).then(function (swpDetails) {
                deferred.resolve(swpDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        
        getReviewDtpObj: function() {
            return _swpObj;
        },
        setReviewDtpObj: function(swpObj) {            
            _swpObj = swpObj;
        },
        resetReviewSwpObj: function() {            
            _swpObj = null;
            return _swpObj;
        },
          getData: function() {
            return _detailsObj;
        },
        setDataObj: function(detailsObj) {            
            _detailsObj = detailsObj;
        },
        getDataObj:function(){
            return _detailsObj;
        },
        setType : function(type) {
            _type = type;
        },

        getType : function() {
            return _type;
        },
        isSwitchEdited:false
    };
    return reviewDtpDetailsModel;
};

reviewDtpDetailsModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants'];

module.exports = reviewDtpDetailsModel;