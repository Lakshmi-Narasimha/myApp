// ProductLiteratureEmailDocuments.model.js
// grab the mongoose module
// define our usernames.model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var ProductLiteratureEmailDocumentsSchema = new mongoose.Schema({
    ProductLiteratureEmailDocuments: {
        type: Array,
        "default": []
    }
});

var ProductLiteratureEmailDocumentsLookUp = mongoose.model('ProductLiteratureEmailDocumentsLookUp', ProductLiteratureEmailDocumentsSchema);
/*json order: investor book-*/
var ProductLiteratureEmailDocumentsModel = new ProductLiteratureEmailDocumentsLookUp({
  "ProductLiteratureEmailDocuments": []
});

ProductLiteratureEmailDocumentsLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating ProductLiteratureEmailDocumentsLookUp table, please contact admin...');
    } else {
        ProductLiteratureEmailDocumentsLookUp.remove({}, function(err) {
            console.log('ProductLiteratureEmailDocumentsLookUp collection removed');
           ProductLiteratureEmailDocumentsModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating ProductLiteratureEmailDocumentsLookUp table, please contact admin...');
                }
                console.log('ProductLiteratureEmailDocumentsLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = ProductLiteratureEmailDocumentsLookUp;
