/**
 * @ngdoc property
 * @name Accordion Directive
 * @requires $state
 * @description
 *
 * - Accordion directive will load the accordion with title specified and routes the page to the route specified to the directive.
 *
 **/
'use strict';

var smartSolAnotherFundSelection = function() {
	return {
          template: require('./smartSolFundSelection.html'),
           restrict: 'E',
           replace: true,
            controller:['$scope', function($scope){
              $scope.anotherfundSelection = "Franklin India Flexi Fund";
            }]
        };
};

smartSolAnotherFundSelection.$inject = [];
module.exports = smartSolAnotherFundSelection;