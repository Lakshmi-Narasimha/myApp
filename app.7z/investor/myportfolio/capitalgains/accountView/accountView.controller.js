/**
 * @ngdoc 
 * @name cgActView
 * @requires cgAccDetModel
 * @requires fticgAccDetLoadInitialService
 * @requires advisorEventConstants
 * @description Controller for Capital Gains Account View
 *
 * - 
 *
 **/


'use strict';

function CGAccountViewCtrl($scope, investorEventConstants, fticgAccDetLoadInitialService) {
    
    //$scope.$emit("changeNavCgPill","accountview");

    $scope.showcgAccountData = false;
    $scope.$on('cgapplyac', function(event, cgacfilter){   
        fticgAccDetLoadInitialService.loadAllServices($scope, cgacfilter);
    });

	$scope.$on(investorEventConstants.MyPortfolio.CG_ACCOUNT_DETAILS, function(event) {
	   $scope.showcgAccountData = true;
	});
}
CGAccountViewCtrl.$inject = ['$scope', 'investorEventConstants', 'fticgAccDetLoadInitialService'];
module.exports = CGAccountViewCtrl;