// getInvestorDashboard.model.js
// grab the mongoose module
// module.exports allows us to pass this to other files when it is called

'use strict';
var mongoose = require('mongoose');

var InvestorBasisFolioSchema = new mongoose.Schema({
    investorBasisFolioObject: {
        type: Object,
        'default': {}
    },
    investorBankDetailsObject: {
        type: Object,
        'default': {}
    }
});

var InvestorBasisFolioLookUp = mongoose.model('InvestorBasisFolioLookUp', InvestorBasisFolioSchema);

var InvestorBasisFolioModel = new InvestorBasisFolioLookUp({
    "investorBasisFolioObject": {
        "basisFolioDetails": [
            {
                "folioNo": "17877097",
                "fundName": "Franklin India Taxshield - Growth",
                "folioAccountNo": "1349904865101",
                "bankDetails": "ICICI Bank - 57523667318",
                "ifscCode": "ICIC0000001",
                "payType": "E-mandate"
            },{
                "folioNo": "25677097",
                "fundName": "Franklin Asian Equity Fund - Dividend",
                "folioAccountNo": "2568904865101",
                "bankDetails": "HDFC Bank - 38923667318",
                "ifscCode": "HDFC0000012",
                "payType": "NACH"
            },{
                "folioNo": "18977097",
                "fundName": "Franklin India Prima Pulse - Dividend",
                "folioAccountNo": "5479904865101",
                "bankDetails": "Dena Bank - 63523667318",
                "ifscCode": "DENA0000004",
                "payType": "Payout-Direct"
            },{
                "folioNo": "16477097",
                "fundName": "Franklin India Balanced Fund - Direct - Dividend",
                "folioAccountNo": "4267904865101",
                "bankDetails": "ICICI Bank - 15723667318",
                "ifscCode": "ICIC0000007",
                "payType": "Pay In | Pay Out"
            }
        ]
    },
    "investorBankDetailsObject": {
        "banksNames": ["HDFC Bank", "ICICI Bank", "Dena Bank", "YES Bank"]
    }
});

InvestorBasisFolioLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating InvestorBasisFolioLookUp table, please contact admin...' + err);
    } else {
        InvestorBasisFolioLookUp.remove({}, function(err) {
            console.log('InvestorBasisFolioLookUp collection removed' + err);
            InvestorBasisFolioModel.save(function(err) {
                if (err) {
                    console.log('Having toruble in creating InvestorBasisFolioLookUp table, please contact admin...');
                }
                console.log('InvestorBasisFolioLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = InvestorBasisFolioLookUp;
