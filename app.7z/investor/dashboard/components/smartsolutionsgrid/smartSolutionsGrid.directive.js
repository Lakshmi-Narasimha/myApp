/**
 * @ngdoc directive
 * @name fticSmartSolutionsGrid
 * @description
 *
 * - Displays the Smart Solutions grid with inventment goals information for goal categories.
 *
 **/
'use strict';


var smartSolutionsGrid = function() {
    return {
        template: require('./smartSolutionsGrid.html'),
        restrict: 'E',
        replace: true,
        scope: true,
        controller: function($scope) {
            var goalAchievedTemplate = '<div class="ui-grid-cell-contents"><div class="grid-cell-progress-text"><span class="custom-bold">{{row.entity.achieved}}</span>  {{ row.entity.goalText}}</div><div class=""><uib-progressbar type="success" value="row.entity.achieved.slice(0,row.entity.achieved.length-1)"></uib-progressbar></div><div ng-bind-html="row.entity.mktvalue | fticRupee"></div></div>';
            var rupeeTemplate = '<div class="ui-grid-cell-contents" ng-bind-html="grid.getCellValue(row, col) | fticRupee"></div>';
            var btnTemplate = '<button ui-sref="startsip" type="button" class="btn panel-orange-btn mt+">{{"VIEW_DETAILS" | translate}}</button>';
            var yearsToGoalTemplate = '<div class="ui-grid-cell-contents">{{grid.getCellValue(row, col)+ " years" }}</div>';
            $scope.columnDefs = [
                { field: 'goalDetails', displayName: 'GOAL', width: '130', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', enableSorting:false},
                { field: 'investmentAmount', displayName: 'INVESTMENT', width: '120', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: rupeeTemplate, enableSorting:false},
                { field: 'targetAmount', displayName: 'GOAL AMOUNT', width: '120', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: rupeeTemplate, enableSorting:false},
                { field: 'pendingTimeFrame', displayName: 'YEARS TO GOAL', width: '120', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: yearsToGoalTemplate, enableSorting:false},
                { field: 'mktvalue', displayName: 'GOAL ACHIEVED', width: '230', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: goalAchievedTemplate, enableSorting:false},
                { field: 'mktvalue', displayName: ' ', width: '114', headerCellClass: 'fti-grid-headercell fti-grid-sortDisabledHeader', cellTemplate: btnTemplate, enableSorting:false}
            ];
        }
    };

};
smartSolutionsGrid.$inject = [];
module.exports = smartSolutionsGrid;
