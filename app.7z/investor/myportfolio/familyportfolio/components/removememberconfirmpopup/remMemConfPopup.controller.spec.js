'use strict';
describe('Controller: remove member family portfolio controller', function() {
	var $controller,$scope,RemMenConfPopupController,$uibModalStack,investorEventConstants,$rootScope;

	beforeEach(angular.mock.module('investor'));
	beforeEach(angular.mock.module('investor.myportfolio'));

	beforeEach(angular.mock.inject(function(_$controller_, $rootScope,_$uibModalStack_,_investorEventConstants_) {
        $controller = _$controller_;
        $rootScope = $rootScope;
        $scope = $rootScope.$new();
        $uibModalStack = _$uibModalStack_;
		investorEventConstants = _investorEventConstants_;        
        RemMenConfPopupController = $controller('RemMemConfPopup', { $scope: $scope });

        spyOn($uibModalStack,'dismissAll').and.callThrough();
        spyOn($scope,'$emit').and.callThrough();        
        $uibModalStack.dismissAll();
    }));

    it('should be defined', function() {
        expect(RemMenConfPopupController).toBeDefined();        
    });

	it('should close the model on click of cancel button', function() {     		    		
        expect($uibModalStack.dismissAll).toHaveBeenCalled();
    });    

    it('should remove the member on click of submit button', function() {   
    	$scope.onSubmit();  		    		
        expect($uibModalStack.dismissAll).toHaveBeenCalled();        
        expect($scope.$emit).toHaveBeenCalledWith(investorEventConstants.MyPortfolio.FAMILY_PORTFOLIO_REMOVE_CONF_EVENT);
    });
});