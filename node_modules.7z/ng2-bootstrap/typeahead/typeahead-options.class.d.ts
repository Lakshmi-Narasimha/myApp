import { TypeaheadDirective } from './typeahead.directive';
export declare class TypeaheadOptions {
    placement: string;
    animation: boolean;
    typeaheadRef: TypeaheadDirective;
    constructor(options: TypeaheadOptions);
}
