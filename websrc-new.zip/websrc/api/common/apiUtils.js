var getMessageModel = require('../modules/getMessage/getMessage.model');
var engagementModel = require('../modules/engagement/engagement.model');
var dataPassModel = require('../modules/dataPass/dataPass.model');
var assistedModel = require('../modules/assisted/assisted.model');
var sendMessageModel = require('../modules/sendMessage/sendMessage.model');
var https = require('https');
var http = require('http');
//var httpsDebug = require('http-debug').https;
//httpsDebug.debug = 2;
var logger = require('../../config/logger');
var config = require('/app/conf/properties/mfchatnode/config');
var querystring = require('querystring');
var myCache = require('../../api-server');
var proxy = require('../../config/proxy');
var request = require('request');


var apiUtils = {
    dataPass: function(req, res, dataPassCallback) {
        //  logger.access.info(req.body);
        var post_data = {
            "engagementID": req.session.engagementID,
            "agentID": req.session.agentID
        };
        req.uri = dataPassModel.createRequestUri;
        post_data.VATranscript = myCache.get(req.session.engagementID+'.VATranscript');
        if(!req.session.isSales){
            post_data.Datapass =  myCache.get(req.session.engagementID+'.Datapass');
        }
        var postBody = querystring.stringify(post_data);
        //  logger.access.info(postBody);
        //console.log(postBody);
        var reqObj = {
            host: req.uri.host,
            method: 'POST',
            path: req.uri.path,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': req.session.sessionCookie,
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            logger.general.info(logger.formatOutBoundResMsg(reqObj, { statusCode: proxyResponse.statusCode }, req.session.id));
            if (proxyResponse.statusCode === 200) {
                dataPassCallback(res);
                //res.status(200).end();
            } else {
               var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);
            });
        });

        proxyRequest.write(postBody);
        proxyRequest.end();
    },
    getMsg: function(req, res, callBack) {
        req.uri = getMessageModel.createRequestUri;
        var reqObj = {
            method: 'GET',
            //url: 'https://'+req.uri.host + req.uri.path + req.session.engagementID,
            url: 'https://'+req.uri.host + req.uri.path + req.params.engagementID,
            agent: proxy.agent,
            ca:proxy.ca,
            timeout: 35*1000,
            headers: {
                'Cookie': req.session.sessionCookie,
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
        request(reqObj,function(error, response, body){
            //logger.general.info(logger.formatInfoMsg(req.session.id, "getMessage response code "+ response.statusCode + JSON.stringify(body)));
            if(error){
                logger.error.error(logger.formatOutBoundResMsg(reqObj, error, req.session.id));
                if(error.code === 'ESOCKETTIMEDOUT') {
                    console.log("timeout 35 seconds");
                   callBack('{}');
                }else{
                    callBack('{}');
                }
            }else if(response.statusCode === 401 || response.statusCode === 400){
               logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.interruptedResponse));
               logger.general.info(logger.formatResMsg(reqObj, response, req.session.id));
               res.send(getMessageModel.interruptedResponse);
               return;
            }else if(response.statusCode !== 204 && response.statusCode !== 200){                
                logger.error.error(logger.formatResMsg(reqObj, reqObj, req.session.id));
                logger.error.error(logger.formatResMsg(reqObj, {statusCode: response.statusCode}, req.session.id));
                callBack('{}');
            }else if (response.statusCode === 204) {
                // if(myCache.get(req.session.engagementID+".mqtt")===true){
                //     if(myCache.get(req.session.engagementID+".chatTimer")){
                //         var lastMsg = myCache.get(req.session.engagementID+".chatTimer");
                //         console.log("Timeout time: "+ (new Date().getTime()-lastMsg));
                //         if((new Date().getTime()-lastMsg)>5*1000*60){
                //             myCache.set(req.session.engagementID+".timeout", 'true');
                //         }
                //     }
                // }               
               logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.emptyResponse));
               logger.general.info(logger.formatResMsg(reqObj, response, req.session.id));
               callBack('{}');
            }else {
                logger.general.info(logger.formatInfoMsg(req.session.id, "getMessage response with engagementID ("+
                                req.session.engagementID+")from TC "+ JSON.stringify(body)));
                callBack(body);
            }
        });
    },
    generateToken: function(req, res, callBackToken) {
        var postBody = { 
            "deviceId": req.session.MDN,
            "requestor": req.session.requestor
        };
        var reqObj = {
           // host: 'sclmdm03wsi.sdc.vzwcorp.com',
            host: config.UDM_SERVER_NAME,
            //port: '6001',
            port: '80',
            method: 'POST',
            path: '/udmmw/udmapi/saveToken',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.general.info(logger.formatInfoMsg(req.session.id, "generateToken Call Trigerred"));
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    //  logger.access.info(chunk);
                    callBackToken(chunk);
                });
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);
            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    sendCmd: function(req, res, callBackSendCmd, isPersistent) {
        //req.session.udm.isConnected = req.session.udm.isConnected;
        //console.log('UDM::',req.session.udm)
        let persistFlag = (typeof isPersistent  !== 'undefined') ?  isPersistent  : false;
        var postBody = {
            "castType": "multicast",
            "cmd": "DROP_MSG",
            "requestor": req.session.requestor,
            "deviceList": [{
                "deviceId": req.session.MDN
            }],
            "sessionId": req.session.engagementID,
            "data": req.session.getMsgRes,
            "isPersistent": persistFlag
        };
        var reqObj = {
            //host: 'sclmdm03wsi.sdc.vzwcorp.com',
            host: config.UDM_SERVER_NAME,
            //port: '6001',
            port: '80',
            method: 'POST',
            path: '/udmmw/udmapi/sendCommand',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    res.status(200).end();
                    if(req.session.chatClosed){
                        req.session.destroy(function(){
                        });
                    }

                });
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.end();
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.end();

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    assisted: function(req, res) {
        //  logger.access.info(req.body);
        var post_data = {
            "tcCustomerID": req.session.customerID,
            "engagementID": req.session.engagementID,
            "businessRuleID": req.session.businessRuleID,
            "siteID": config.TC_SITE_ID,
            "viewID": "36219496"
        };
        var reqObj = {
            host: config.TC_SERVER_NAME,
            method: 'POST',
            path: config.TC_ASSISTED_URI,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Content-Type': 'application/json',
                'Cookie': req.session.sessionCookie,
                //'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            logger.general.info(logger.formatOutBoundResMsg(reqObj, {statusCode: proxyResponse.statusCode}, req.session.id));
            if (proxyResponse.statusCode === 200) {
                //assistedCallback(res);
                res.status(200).end();
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);
            });
        });

        proxyRequest.write(JSON.stringify(post_data));;
        proxyRequest.end();
    },
    saveMDN: function(req, res, callBack) {
        //  logger.access.info(req.body);
        var postBody = {
            "customerId": req.session.customerID,
            "mdn": req.session.MDN
        };
        var reqObj = {
            host: config.NLP_SERVER_URL,
            port: config.NLP_SERVER_PORT,
            method: 'POST',
            path: config.NLP_MDN_SAVE_URI,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        var data = {};
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');

            if (proxyResponse.statusCode !== 200) {
                 var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);

            }

            proxyResponse.on('data', function(chunk) {
               // logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                data = chunk;
            });
            proxyResponse.on('end', function() {
               logger.general.info(logger.formatOutBoundResMsg(reqObj, data, req.session.id));
               callBack(data);
            });

            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    conversion: function(req, res, callBack) {
        //  logger.access.info(req.body);
        var postBody = {
            "mdn": req.session.MDN
        };
        var reqObj = {
            host: config.NLP_SERVER_URL,
            port: config.NLP_SERVER_PORT,
            method: 'POST',
            path: config.NLP_MDN_SAVE_URI,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        var data = {};
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');

            if (proxyResponse.statusCode !== 200) {
                 var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);

            }

            proxyResponse.on('data', function(chunk) {
               // logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                data = chunk;
            });
            proxyResponse.on('end', function() {
               logger.general.info(logger.formatOutBoundResMsg(reqObj, data, req.session.id));
               callBack(data);
            });

            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    surveyEligibility: function(req, res, callBack) {
        //  logger.access.info(req.body);
        var postBody = {
            "mdn": req.session.MDN
        };
        var reqObj = {
            host: config.NLP_SERVER_URL,
            port: config.NLP_SERVER_PORT,
            method: 'POST',
            path: config.NLP_SURVEY_ELIGIBILITY_URI,
            headers: {
                'Content-Type': 'application/json'
            }
        };
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            logger.general.info(logger.formatInfoMsg(req.session.id, "surveyEligibility: "+proxyResponse.statusCode));
            if (proxyResponse.statusCode === 200) {
                proxyResponse.on('data', function(chunk) {
                    logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
                    chunk = JSON.parse(chunk);
                    callBack(chunk);
                });
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);

            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();

    },
    // mfcTagging: function(req, res, callBack) {
    // //  logger.access.info(req.body);
    // var postBody = {
    //     "mdn": req.session.MDN,
    //     "sessionId": req.session.id,
    //     "appId": "MF_Chat",
    //     "tagName": req.session.tag,
    //     "dwField": "Y",
    //     "deviceType": req.session.osName,
    //     "sourceID":"mvmrc",
    //     "deviceName": req.session.deviceName
    // };
    // var reqObj = {
    //     host: "app311dev.hss.vzwcorp.com",
    //     port: "19014",
    //     method: 'POST',
    //     path: config.NLP_TAGGING,
    //     headers: {
    //         'Content-Type': 'application/json'
    //     }
    // };
    // var data = {};
    // logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
    // var proxyRequest = http.request(reqObj, function(proxyResponse) {
    //     proxyResponse.setEncoding('utf8');

    //     // if (proxyResponse.statusCode !== 200) {
    //     //         var errObj = {
    //     //         message: proxyResponse.statusMessage,
    //     //         statusCode: proxyResponse.statusCode
    //     //     };
    //     //     logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
    //     //     logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
    //     //     res.send(errObj);

    //     // }

    //     proxyResponse.on('data', function(chunk) {
    //         // logger.general.info(logger.formatOutBoundResMsg(reqObj, chunk, req.session.id));
    //         data = chunk;
    //     });
    //     proxyResponse.on('end', function() {
    //         logger.general.info(logger.formatOutBoundResMsg(reqObj, data, req.session.id));
    //         //callBack(data);
    //     });

    //     proxyResponse.on('error', function(err) {
    //         logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
    //         logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
    //         res.send(err);

    //         });
    //     });
    //     proxyRequest.write(JSON.stringify(postBody));
    //     proxyRequest.end();

    // },
    formatOrderNum:function(orderString) {
        var s = "";
        if(orderString){
            s = orderString.substring(orderString.indexOf("#")+2);
            s = s.substring(0,s.indexOf(" "));
        }
        return s;
    },
    getProducts: function(req){
        var products = [];
        if(req.body.RequestParams.monthly && req.body.RequestParams.monthly.Devices){
            for(i=0;i<req.body.RequestParams.monthly.Devices.length;i++){
                var device = req.body.RequestParams.monthly.Devices[i];
                for(j=0;j<req.body.RequestParams.monthly.Devices[i].lineItems.length;j++){
                    var item = req.body.RequestParams.monthly.Devices[i].lineItems[j];
                    var obj = {};
                    obj.count = 1;
                    obj.product = device.deviceTitle==null?"":device.deviceTitle+ " - "+ item.title;
                    obj.price = item.amount;
                    products.push(obj);
                }

            }
        }

        if(req.body.RequestParams.monthly && req.body.RequestParams.dueToday.Devices){
            for(i=0;i<req.body.RequestParams.dueToday.Devices.length;i++){
                var device = req.body.RequestParams.dueToday.Devices[i];
                for(j=0;j<req.body.RequestParams.dueToday.Devices[i].lineItems.length;j++){
                    var item = req.body.RequestParams.dueToday.Devices[i].lineItems[j];
                    var obj = {};
                    obj.count = 1;
                    obj.product = device.deviceTitle==null?"":device.deviceTitle+ " - "+ item.title;
                    obj.price = item.amount;
                    products.push(obj);
                }
            }
        }
        return products;
    },
    getVATranscript:function(VATranscript){
        var transcript = "<br><div>";
        for(i=0;i<VATranscript.length;i++){
            transcript +="<p><b>" + VATranscript[i].type + ":</b>" + VATranscript[i].message +"</p>";
        }
        transcript += "</div>";
        return transcript;
    },
    getUserInfo:function(req){
        var validated = '';
        var postData = '';
        var result = '';
        if(req.session.agentGroupID !=="English_Prepaid" ){
            result = "<div><br><p><b> - Role: </b>"+ req.body.RequestParams.accRole;
        }
        var accRole = req.body.RequestParams.accRole.replace(' ','');

        if(accRole.trim().toUpperCase()==='ACCOUNTMANAGER'||
            accRole.trim().toUpperCase()==='ACCOUNTHOLDER'||
            accRole.trim().toUpperCase()==='ACCOUNTOWNER'){
            validated = 'Y';
        }else{
            validated = 'N';
        }
        if(req.session.agentGroupID !=="English_Prepaid" ){
            postData = "viewName=customerSearchNewView&noheader=true&validated=" + validated + "&Originsystem=TC&mdnSearched="
                     + req.body.RequestParams.MDN + "&fromScreen=TOOLBAR&hiddCustMdnSearch=mdn";
            result +=  "</p><p><b> - Mobile Number: </b>" + "<font color=\"#0000CC\"><u><a href=\"event:acss:"+ postData + "\">"+apiUtils.formatMDN(req.body.RequestParams.MDN) +"</a></u></font>" ;
        }else{
           result =  "<br></p><p><b> - Mobile Number: </b>" +apiUtils.formatMDN(req.body.RequestParams.MDN) ; 
        }
        result += "</p><p><b> - Greeting Name: </b>" + req.body.RequestParams.nickName;
        if(req.session.agentGroupID !== "English_Prepaid"){
            if(validated === 'Y'){
            result += "</p><p><b> - Security: </b><font color=\"#008000\">Validated</font></p>";
        }else{
            result += "</p><p><b> - Security: </b><font color=\"#ff0000\">Not Validated</font></p>";
        }
        }
        if(req.body.RequestParams.agentGroupID.indexOf('_EMP')!=-1){
             result += "</p><p><b> - ECPD ID: </b>" + req.body.RequestParams.ecpdId + "</p></div>" ;
        }else{
             result += "</p></div>";
        }

        return result;

    },
    formatMDN:function(mdn){
        return "(" + mdn.substring( 0,3 ) + ") " + mdn.substring( 3,6 ) + "-" + mdn.substring( 6,10 ); 
    },    
    cleanMFCCache(engagementID , session){
        myCache.del(engagementID+".chatGetMsgCounter");
        myCache.del(engagementID+".chatSendMsgCounter");
        myCache.del(engagementID+".isAssisted");
        myCache.del(engagementID+".closed");
        myCache.del(engagementID+".isRecurEnabled");
        myCache.del(engagementID+".Datapass");
        myCache.del(engagementID+".VATranscript");
        myCache.del(engagementID+".agentID");
        myCache.del(engagementID+".chatTimer");
        //myCache.del(engagementID+".timeout");
        myCache.del(engagementID+".mqtt");
        session = null;
    },
    formattedGetMsg: function(req, res, getMsgCallback) {
        req.uri = getMessageModel.createRequestUri;
         var reqObj = {
            host: req.uri.host,
            method: 'GET',
            path: req.uri.path + req.session.engagementID,
            agent: proxy.agent,
            ca:proxy.ca,
            headers: {
                'Cookie': req.session.sessionCookie
            }
        }
        var chunk = '';
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, reqObj, req.session.id));
        var proxyRequest = https.request(reqObj, function(proxyResponse) {
                proxyResponse.setEncoding('utf8');
                proxyResponse.on('data', function(data) {
                    chunk += data;
                });
                proxyResponse.on('end', function() {
                    if (proxyResponse.statusCode === 200) {                    
                        try{
                            logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message response with engagementID: "+ req.session.engagementID +" "+ JSON.stringify(chunk)));
                            chunk = JSON.parse(chunk);                       
                        }catch(e){
                            logger.general.info(logger.formatInfoMsg(req.session.id, "Not a valid json"));
                            getMsgCallback(false); 
                            return;                           
                        }                        
                        if(chunk.messages[0] && chunk.messages[0].state){
                            if(chunk.messages[0].state === 'assigned'){
                                req.session.agentID = engagementModel.response.Page.agentID = chunk.messages[0]['agentID'];
                                myCache.set(req.session.engagementID+".agentID", chunk.messages[0]['agentID']);
                                req.session.agentName = getMessageModel.response.Page.agentName = chunk.messages[0]['agent.alias'];
                                engagementModel.response.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                                engagementModel.response.Page.customerID = req.session.customerID ; /// storing customerID into the session
                                engagementModel.ResponseInfo.topMessage = "You're chatting with "+ chunk.messages[0]['agent.alias'];
                                engagementModel.ResponseInfo.type = "ChatTop";
                                engagementModel.response.ModuleMap.Support.ResponseInfo = engagementModel.ResponseInfo;
                                engagementModel.msgList[0].messageList[0].messageText =  chunk.messages[0]['agent.alias'] + " joined the conversation";
                                /*For tagging*/
                                req.session.tagBody.mdn = req.session.MDN;
                                req.session.engagementID = req.session.engagementID;
                                req.session.retryTimes = 0;
                                req.session.tagBody.event = "TC_Agent Joined Conversation";
                                 logger.tag.info(logger.tagsInfo(req.session.tagBody));
                                /* Tagging ends*/ 
                                // if(config.SEND_CHAT_HISTORY_FLAG){
                                //     engagementModel.msgList[0].messageList[0].condition = "showTranscript";
                                // }else{
                                //     if((typeof engagementModel.msgList[0].messageList[0].condition)  !== 'undefined'){
                                //         delete engagementModel.msgList[0].messageList[0].condition;
                                //     }
                                // }                                
                                                               
                                engagementModel.response.ModuleMap.Support.startMsgId = 9999;
                                engagementModel.response.ModuleMap.Support.msgList = engagementModel.msgList;
                                engagementModel.response.ResponseInfo = engagementModel.ResponseInfo;
                                req.session.getMsgRes = engagementModel.response;
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "#AgentConnected: " + " #EngagementId: "+ req.session.engagementID +" #AgentGroupId: " + req.session.agentGroupID + " #AgentName: " +req.session.agentID));
                                apiUtils.sendCmd(req, res, function(response) {}, true);
                                apiUtils.dataPass(req, res,function(response) {});
                                apiUtils.sendDataToAcss(req, res, function(response) {});
                                logger.general.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText));
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, engagementModel.msgList[0].messageList[0].messageText));
                                getMsgCallback(false);
                            }else if (myCache.get(req.session.engagementID+".closed") === true || chunk.messages[0].state === 'closed'){
                                req.session.chatClosed = true;
                                if(chunk.messages[0] && chunk.messages[0]['display.text']){
                                    req.session.closedMessage = chunk.messages[0] && chunk.messages[0]['display.text'];
                                    logger.conversation.info(logger.formatInfoMsg(req.session.id, "Closed Message "+ ' ' + req.session.closedMessage + ' with #engagementID' + req.session.engagementID));
                                }
                                /* for tagging*/
                                if(req.session.closedMessage.indexOf('Customer')!== 1){
                                    req.session.tagBody.engagementID = req.session.engagementID;
                                    req.session.tagBody.event = "TC_User Ended Chat";
                                    req.session.tagBody.retryTimes = 0;
                                    logger.tag.info(logger.tagsInfo(req.session.tagBody));        
                                }else if(req.session.closedMessage.indexOf('Agent')!== 1){
                                    req.session.tagBody.event = "TC_Agent Ended Chat";
                                    req.session.tagBody.retryTimes = 0;
                                    logger.tag.info(logger.tagsInfo(req.session.tagBody));
                                }
                                /* for tagging ends*/
                                myCache.set(req.session.engagementID+".mqtt", false);
                                if (parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 && parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 2 && !(req.session.channel && req.session.agentGroupID === "WirelessSales")) {
                                    apiUtils.surveyEligibility(req, res, function(response) {
                                        logger.conversation.info(logger.formatInfoMsg(req.session.id, "surveyEligibility response "+JSON.stringify(response)));
                                        if(response.eligible === true ){
                                            var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                            var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                            getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                            getMessageModel.surveyResponse.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                                            getMessageModel.surveyResponse.Page.customerID = req.session.customerID ; /// storing customerID into the session
                                            getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                            getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                            req.session.getMsgRes = getMessageModel.surveyResponse;
                                            apiUtils.sendCmd(req, res, function(response) {}, true);
                                            logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.surveyResponse));
                                            logger.conversation.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                                            logger.general.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                                            req.session.tagBody.event = "Survey Provided to TC_User";
                                            logger.tag.info(logger.tagsInfo(req.session.tagBody));
                                        }else{
                                            // var surveyUrl = getMessageModel.createSurveyUri(req.session);
                                            // var surveyMsg = getMessageModel.getSurveyMsg(req.session.nickName, req.session.agentName);
                                            // getMessageModel.surveyResponse.Page.surveyUrl = surveyUrl;
                                            // getMessageModel.surveyResponse.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                                            // getMessageModel.surveyResponse.Page.customerID = req.session.customerID ; /// storing customerID into the session
                                            // getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].ButtonMap.FeedLink.browserUrl = surveyUrl;
                                            // getMessageModel.surveyResponse.ModuleMap.Support.msgList[2].messageList[0].messageText = surveyMsg;
                                            
                                            // req.session.getMsgRes = getMessageModel.surveyResponse;
                                            // console.log(JSON.stringify(req.session.getMsgRes));
                                            // apiUtils.sendCmd(req, res, function(response) {}, true);
                                            // logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.surveyResponse));
                                            // logger.conversation.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                                            // logger.general.info(logger.formatInfoMsg(req.session.id, "Survey is provided for engagementID "+req.session.engagementID));
                                            // req.session.tagBody.event = "Survey Provided to TC_User";
                                            // logger.tag.info(logger.tagsInfo(req.session.tagBody));
                                            req.session.getMsgRes = getMessageModel.endResponse;
                                            apiUtils.sendCmd(req, res, function(response) {}, true);
                                            logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));
                                            logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                                            logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 24 hours rule with engagementID "+req.session.engagementID));
                                            req.session.tagBody.event = "No Survey Provided to TC_User";
                                            logger.tag.info(logger.tagsInfo(req.session.tagBody));
                                        }
                                        apiUtils.cleanMFCCache(req.session.engagementID, req.session);
                                    });
                                }else{
                                    getMessageModel.endResponse.Page.engagementID = req.session.engagementID; /// storing engagementID into the session
                                    getMessageModel.endResponse.Page.customerID = req.session.customerID ; /// storing customerID into the session
                                    req.session.getMsgRes = getMessageModel.endResponse;
                                    console.log(req.session.getMsgRes);
                                    apiUtils.sendCmd(req, res, function(response) {}, true);
                                    logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.endResponse));
                                    logger.general.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID " +req.session.engagementID));
                                    logger.conversation.info(logger.formatInfoMsg(req.session.id, "No survey provided due to 2X2 rule with engagementID "+req.session.engagementID));
                                    apiUtils.cleanMFCCache(req.session.engagementID, req.session);
                                }                                
                                getMsgCallback(true);
                            }else if(chunk.messages[0].state === 'agentIsTyping'){
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = 50000;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = 50000;
                                getMessageModel.response.ModuleMap.Support.msgList[0].msgId = 50000;
                                getMessageModel.response.ModuleMap.Support.msgList[0].state = chunk.messages[0].state;
                                getMessageModel.response.ModuleMap.Support.startMsgId = 50000;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type = chunk.messages[0].type;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0]['display.text'];
                                req.session.getMsgRes = getMessageModel.response;
                                apiUtils.sendCmd(req, res, function(response) {}, false);
                                getMsgCallback(false);
                            }else {
                                getMsgCallback(false);
                            }
                        }else if(chunk.messages[0] && chunk.messages[0].messageType === 'chatLine' && parseInt(chunk.messages[0].sequenceNumber,10) >=3 ){
                            var msgCount = parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"),10) || 0;
                            myCache.set(req.session.engagementID+".chatGetMsgCounter", msgCount+1);
                            myCache.set(req.session.engagementID+".chatTimer", new Date().getTime());
                            if (chunk.messages[0].messageText.toLowerCase() === 'login needed') {
                                req.session.tagBody.event = "TC_Customer was asked Login Needed";
                                logger.tag.info(logger.tagsInfo(req.session.tagBody));
                                getMessageModel.loginNeededResponse.Page.engagementID = req.session.engagementID;
                                getMessageModel.loginNeededResponse.Page.customerID = req.session.customerID;
                                getMessageModel.loginNeededResponse.Page.agentID = req.session.agentID;
                                if(req.session.agentGroupID === "English_Prepaid"){
                                 getMessageModel.loginNeededResponse.ModuleMap.Support.msgList[1].messageList[1].ButtonMap.FeedLink.appContext = 'mfPrepaySS';  
                                }else{
                                 getMessageModel.loginNeededResponse.ModuleMap.Support.msgList[1].messageList[1].ButtonMap.FeedLink.appContext = 'mobileFirstSS';
                                }
                                req.session.getMsgRes = getMessageModel.loginNeededResponse;
                            }else if(chunk.messages[0].messageText.toLowerCase().indexOf('<a href=')!==-1 && (chunk.messages[0].messageText.toLowerCase().indexOf('http')!==-1 || chunk.messages[0].messageText.toLowerCase().indexOf('https')!==-1)){ 
                                var messageWithLink= chunk.messages[0].messageText;
                                var browserUrlFormed = messageWithLink.match(/(?:"[^"]*"|^[^"]*$)/)[0].replace(/"/g, "");
                                req.session.openUrl = browserUrlFormed;
                                messageWithLink = messageWithLink.replace(/<a.*>/ig,'<a> Click Here</a>');
                                
                                getMessageModel.alinkResponse.Page.agentID = chunk.messages[0].agentID;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].messageList[0].messageText = messageWithLink;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].msgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                getMessageModel.alinkResponse.ModuleMap.Support.msgList[0].messageList[0].ButtonMap.FeedLink.browserUrl= req.session.openUrl;
                                getMessageModel.alinkResponse.ModuleMap.Support.startMsgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                //delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                                //delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                req.session.getMsgRes = getMessageModel.alinkResponse;
                             }
                            else if(chunk.messages[0].messageText.toLowerCase().indexOf('<a')!==-1 && !(chunk.messages[0].messageText.toLowerCase().indexOf('http')!==-1 || chunk.messages[0].messageText.toLowerCase().indexOf('https')!==-1)){
                                var pageWithLink= chunk.messages[0].messageText;
                                var pageFormed = pageWithLink.match(/(?:"[^"]*"|^[^"]*$)/)[0].replace(/"/g, "");
                                req.session.openPage = pageFormed;
                                pageWithLink = pageWithLink.replace(/<a.*>/ig,'<a> Click Here</a>');
                                
                                getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageList[0].messageText = pageWithLink;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].msgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageList[0].ButtonMap.FeedLink.pageType= req.session.openPage;
                                getMessageModel.blinkResponse.ModuleMap.Support.startMsgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                if(req.session.agentGroupID === "English_Prepaid"){
                                 getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageList[0].ButtonMap.FeedLink.appContext = 'mfPrepaySS';  
                                }else{
                                 getMessageModel.blinkResponse.ModuleMap.Support.msgList[0].messageList[0].ButtonMap.FeedLink.appContext = 'mobileFirstSS';
                                }
                                // delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                                // delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                req.session.getMsgRes = getMessageModel.blinkResponse;
                            }
                            else{
                                getMessageModel.response.Page.agentID = chunk.messages[0].agentID;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageType = chunk.messages[0].messageType;
                                getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].messageText = chunk.messages[0].messageText;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumberInt = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].sequenceNumber = chunk.messages[0].sequenceNumber;
                                getMessageModel.response.ModuleMap.Support.msgList[0].msgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                getMessageModel.response.ModuleMap.Support.startMsgId = getMessageModel.response.ModuleMap.Support.searchStartIndex + parseInt(chunk.messages[0].sequenceNumber,10);
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].messageList[0].type;
                                delete getMessageModel.response.ModuleMap.Support.msgList[0].state;
                                req.session.getMsgRes = getMessageModel.response;
                            }
                            if(req.session.isSales && !myCache.get(req.session.engagementID+".isAssisted") &&
                                parseInt(myCache.get(req.session.engagementID+".chatGetMsgCounter"), 10) >= 2 &&
                                parseInt(myCache.get(req.session.engagementID+".chatSendMsgCounter"), 10) >= 2) {
                                myCache.set(req.session.engagementID+".isAssisted", true);
                                    apiUtils.assisted(req,res,function(response) {});
                                    apiUtils.saveMDN(req,res,function(response) {});
                            }
                            logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.response));
                            logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Get Message: ' + chunk.messages[0].messageText);
                            apiUtils.sendCmd(req, res, function(response) {}, true);
                            getMsgCallback(false);
                        }else {
                            //console.log("*"+proxyResponse.statusCode+ JSON.stringify(chunk));
                            getMsgCallback(false);
                        }                                     
                } else if(proxyResponse.statusCode === 204){
                       //console.log(myCache.get(req.session.engagementID+".mqtt") + myCache.get(req.session.engagementID+".chatTimer"));
                       if(myCache.get(req.session.engagementID+".mqtt") && myCache.get(req.session.engagementID+".chatTimer")){
                            var lastMsg = myCache.get(req.session.engagementID+".chatTimer");
                            //console.log("Timeout time: "+ (new Date().getTime()-lastMsg));
                            if((new Date().getTime()-lastMsg)>10*1000*60){
                                req.session.chatClosed = true;
                                //myCache.set(req.session.engagementID+".timeout", 'true');
                                logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID due to timeout: "+ req.session.engagementID));
                                logger.conversation.info(logger.formatInfoMsg(req.session.id, "Get Message loop ended with EngagementID due to timeout: "+ req.session.engagementID));
                                req.session.getMsgRes = getMessageModel.timeoutResponse;
                                apiUtils.sendCmd(req, res, function(response) {}, true);
                                apiUtils.sendClosedMsg(req, res, function(response) {});
                                apiUtils.cleanMFCCache(req.session.engagementID, req.session);                                
                                logger.general.info(logger.formatInBoundResMsg(req, getMessageModel.timeoutResponse));
                                getMsgCallback(true);
                             }else{
                                logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message response with EngagementID: "+ req.session.engagementID + " statuscode:  "+ proxyResponse.statusCode));
                                getMsgCallback(false);
                             }
                        }else{
                            logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message response with EngagementID: "+ req.session.engagementID + " statuscode:  "+ proxyResponse.statusCode));
                            getMsgCallback(false);
                        }
                    } else if(proxyResponse.statusCode === 401 || proxyResponse.statusCode === 503 || proxyResponse.statusCode === 400){
                        logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message response with EngagementID: "+ req.session.engagementID + " statuscode:  "+ proxyResponse.statusCode));
                        logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message with EngagementID: "+ req.session.engagementID +" is interrupted"));
                        getMsgCallback(true);
                    } else {
                        logger.general.info(logger.formatInfoMsg(req.session.id, "Get Message with EngagementID: "+ req.session.engagementID + " statuscode:  "+ proxyResponse.statusCode));
                        getMsgCallback(false);
                    }
                });   
                proxyResponse.on('error', function(err) {
                   logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                   getMsgCallback(true);
                });
            });

        proxyRequest.write(res.body + '');
        proxyRequest.end();
    },  

    sendDataToAcss:function(req,res, callBack){        
        var postBody = {
            "realTimeId": req.session.engagementID,
            "skill": req.session.agentGroupIDNum,
            "chatIntend":"N/A",
            "repName": req.session.agentID,
            "GID": "0",
            "MDN":req.session.MDN,
            "accntNum":req.session.accountNum,
            "employeeId":req.session.agentID
        };
        var reqObj = {
            host: "http://premya-eapp1.odc.vzwcorp.com",            
            method: 'POST',
            path: "/vzwsvc/usc/lpNotify.action",
            port: "9180",
            agent: proxy.agent,
            //ca:proxy.ca,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',                
                'Content-Length': Buffer.byteLength(postBody)
            },
            rejectUnauthorized: true
        };

        logger.general.info(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
        var proxyRequest = http.request(reqObj, function(proxyResponse) {
            proxyResponse.setEncoding('utf8');
            logger.general.info(logger.formatOutBoundResMsg(reqObj, {statusCode: proxyResponse.statusCode}, req.session.id));
             if (proxyResponse.statusCode === 200) {            
                callBack();
            } else {
                var errObj = {
                    message: proxyResponse.statusMessage,
                    statusCode: proxyResponse.statusCode
                };
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, errObj, req.session.id));
                //res.send(errObj);
            }
            proxyResponse.on('error', function(err) {
                logger.error.error(logger.formatOutBoundReqMsg(reqObj, postBody, req.session.id));
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                res.send(err);
            });
        });
        proxyRequest.write(JSON.stringify(postBody));
        proxyRequest.end();
    },

    sendClosedMsg:function(req,res, callBack){           
        var post_data = {
             "engagementID" : req.session.engagementID,
             "messageType":"stateChange",
             "state":"closed"
        }; 
        var reqObj = {
            url:'https://'+ sendMessageModel.createRequestUri.host + sendMessageModel.createRequestUri.path,
            agent: proxy.agent,            
            ca:proxy.ca,            
            headers: {                
                'Cookie': req.session.sessionCookie,
                'Content-Type': 'application/json'
                },
            form:post_data
        }            
        logger.general.info(logger.formatOutBoundReqMsg(reqObj, post_data, req.session.id));
        logger.conversation.info('SessionID: '+ req.session.id + ' Engagement ID: ' + req.body.RequestParams.engagementID + ' Send Message: ' + "{'state': 'closed'}");
        request.post(reqObj,function(err,response,body){
            if(err){ 
                logger.error.error(logger.formatOutBoundResMsg(reqObj, err, req.session.id));
                callBack(err);
            }else{                    
                logger.general.info(logger.formatResMsg(reqObj, response, req.session.id));
                callBack(response);                    
            }                     
        });
    }
};

module.exports = apiUtils;
