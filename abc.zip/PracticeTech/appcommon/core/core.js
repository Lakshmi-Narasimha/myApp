﻿define([
   'appcommon/core/modules',
   'appcommon/core/logs',
   'appcommon/core/waiter',
   'appcommon/core/clientcontext',
], function (  Module, Logs, Waiter, ClientContext) {
    var core = function () {

        /* JSONDB - a method of keeping data */
        var jsonDB = function () { };
        jsonDB.prototype.addData = function (database, data) { }

        /* Utility Management*/
        var utility = function () { };

        /* Test Management*/
        var test = function () { };

        core = function () { }
        core.prototype.registry = {
            objects: {
                idBank: 0,
                loaded: 0,
                list: []
            },
            jsonDB: {
                idBank: 0,
                loaded: 0,
                list: []
            },
            module: {
                idBank: 0,
                loaded: 0,
                list: []
            },
            utils: {
                idBank: 0,
                loaded: 0,
                list: []
            },
            test: {
                idBank: 0,
                loaded: 0,
                list: []
            }
        }

        //used to declare new instances of a chained Module class
        createNew = function () { }
        createNew.prototype.module = Module;

        core.prototype.database = new jsonDB();
        core.prototype.errorLog = new Logs();
        core.prototype.warningLog = new Logs();
        core.prototype.stacktrace = new Logs();
        core.prototype.waiter = new Waiter();
        core.prototype.module = new Module;

        //dont worry about this...
        core.prototype.createNew = new createNew();
        core.prototype.clientContext = new ClientContext(); 
     
        return core;
    }
    
    return core();
});
    