// getBuildPlan.model.js
// grab the mongoose module
// define our usernames.model model
// module.exports allows us to pass this to other files when it is called

var mongoose = require('mongoose');

var BuildPlanSchema = new mongoose.Schema({
    buildPlanResp: {
        type: Array,
        "default": []
    }
});

var buildPlanLookUp = mongoose.model('buildPlanLookUp', BuildPlanSchema);

var buildPlanModel = new buildPlanLookUp({
  buildPlanResp: [
     {
      "planSmartSolutionPostReq": {
            "investorDetails": {
              "firstHolderName": "Shankar Narayan",
              "secondHolderName": "Syama Shankar",
              "thirdHolderDetails": "Anil Narayan",
              "folioNo": "4562124",
              "modeOfHolding": "Joint"
            },
          "goalSummary": [
                  {key:"Goal Name",value:"Child’s Education"},
                  {key:"Goal Amount",value:"20,00,000"},
                  {key:"Annual Withdrawals",value:"4000"},
                  {key:"Annual Step-up",value:"10%"},
                  {key:"Goal Tenor",value:"30 Yrs"}
           ],
        "investmentSummary": 
         {
            "fundDetails": [
              {
                "fundName": "Franklin India Prima Plus",
                "allocation": "50%",
                "installmentDetails": {
                  "monthly": "1,500",
                  "annually": "20,000",
                  "oneTime": "40,000"
                }
              },
              {
                "fundName": "Franklin India Bluechip Fund - Growth",
                "allocation": "50%",
                "installmentDetails": {
                  "monthly": "2,000",
                  "annually": "10,000",
                  "oneTime": "50,000"
                }
              }
           ],
            "total": {
              "allocation": "100%",
              "installmentDetails": {
                "monthly": "3,500",
                "annually": "30,000",
                "oneTime": "90,000"
          }
        }
      }
    }
}
  ]
});

buildPlanLookUp.find(function(err, data) {
    // if there is an error retrieving, send the error. 
    // nothing after res.send(err) will execute
    if (err) {
        console.log('Having toruble in creating buildPlanLookUp table, please contact admin...');
    } else {
        buildPlanLookUp.remove({}, function(err) {
            console.log('buildPlanLookUp collection removed');
            buildPlanModel.save(function(err) {
                if (err) {
                    console.log('Having trouble in creating buildPlanLookUp table, please contact admin...');
                }
                console.log('buildPlanLookUp table created in mongoose...');
            });
        });
        console.log(data.length);
    }
});

module.exports = buildPlanLookUp;
