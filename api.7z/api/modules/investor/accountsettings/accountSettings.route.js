'use strict';
var express = require('express'),
    router = express.Router(),
    InvBasisBankAccDetailsModel = require('./basisbankdetails/basisBankAcc.model'),
    InvDividendDetailsModel = require('./changedividend/getDividendDetails.model'),
    InvDividendChangeAssetCategoryModel = require('./changedividend/getChangeDividendAssetCategory.model'),
    InvBasisFolioModel = require('./basisfolio/basisFolio.model'),
    EmandateDetailsModel = require('./emandate/getEmandateDetails.model'),
    removeEmandateModel = require('./emandate/removeEmandate.model'),
    regEmandateModel = require('./emandate/regEmandate.model'),
    InvNomineeDetailsModel = require('./nomineedetails/getNomineeDetails.model'),
    InvBankListModel = require('./basisbankdetails/basisBankList.model'),
    FPUerAccessDetailsModel = require('./familyportfolioaccess/getUserAccessDetails.model'),
    ValidatePurchaseModel = require('./common/validatePurchaseDetails.model'),
    ValidateRedeemModel = require('./common/validateRedeemDetails.model'),
    SmartSavingsModel = require('./common/getSmartSavingsDetails.model'),
    RemovePurchaseModel = require('./common/removePurchaseDetails.model'),
    RemoveRedeemModel = require('./common/removeRedeemDetails.model'),
    SmartFundDetailsModel = require('./common/getFundDetails.model');

var error = {
    status: 300,
    message: 'Something went wrong!!'
}; /* Error messge object */
var errorManageSubscriptions = [{
    'errorCode': '2008',
    'errorSource': 'PFAPP',
    'errorDescription': 'The following field(s) can contain only numbers. They cannot contain alphabets or other characters: Mobile Number'
}];

router.route('/transact/emandateDetails')
    .get(function(req, res) {
        console.log('getEmandateDetails');
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        EmandateDetailsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].getEmandateDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].getEmandateDetails);
            }

        });
    });
router.route('/transact/removeEmandate')
    .post(function(req, res) {
        console.log('deleteEmandate');
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        removeEmandateModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].removeEmandate.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].removeEmandate);
            }

        });
    });

router.route('/transact/regEmandate')
    .post(function(req, res) {
        console.log('regEmandate');
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        regEmandateModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].regEmandate.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].regEmandate);
            }

        });
    });

router.route('/accountSettings/basisBankAccDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        InvBasisBankAccDetailsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].basisBankAccDetailsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0]);
            }

        });
    });

router.route('/accountSettings/BankAccEditDetails')
    .post(function (req, res) {
        if(req.body){
            res.json({'transactionStatus': 'S'});
        } else {
            res.send(error);
        }

    });

router.route('/accountSettings/basisBankListDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        InvBankListModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].basisBankNameListObject.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].basisBankNameListObject);
            }
        });
    });

router.route('/accountSettings/basisFolioDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        InvBasisFolioModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].investorBasisFolioObject.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].investorBasisFolioObject);
            }
        });
    });

router.route('/accountSettings/bankDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        InvBasisFolioModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].investorBankDetailsObject.length === 0) {
                res.send(errorObj);
            } else {
                res.json(data[0].investorBankDetailsObject);
            }
        });
    });

router.route('/clients/dividendSchemes')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        InvDividendDetailsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].dividendDetailsObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].dividendDetailsObject);
            }

        });
    });


router.route('/profile/portfolioMembers')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        FPUerAccessDetailsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].userAccessDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].userAccessDetails);
            }
        });
    });
router.route('/clients/nomineeDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        InvNomineeDetailsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].nomineeSummary.length === 0) {
                res.send(error);
            } else {
                res.json(data[0]);
            }


        });
    });

// smart saving and one touch

router.route('/getSmartSavings')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SmartSavingsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].getSmartSavingsDetails && data[0].getSmartSavingsDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].getSmartSavingsDetails);
            }
        });
    });

router.route('/removePurchases')
    .post(function(req, res) {
        console.log('deletePurchase');
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        RemovePurchaseModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].removePurchaseResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].removePurchaseResp);
            }

        });
    });

router.route('/removeRedeem')
    .post(function(req, res) {
        console.log('deleteRedeem');
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        // console.log('in myprofile route');
        RemoveRedeemModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].removeRedeemResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].removeRedeemResp);
            }

        });
    });

    router.route('/smartFundDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SmartFundDetailsModel.find(function(err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].getFundDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0]);
            }
        });
    });

router.route('/validatePurchases')
    .post(function(req, res) {
        ValidatePurchaseModel.find(function(err, data) {
            res.send(data[0].validatePurchaseResp);
        });
    });

router.route('/validateRedeem')
    .post(function(req, res) {
        ValidateRedeemModel.find(function(err, data) {
            res.send(data[0].validateRedeemResp);
        });
    });


module.exports = router;
