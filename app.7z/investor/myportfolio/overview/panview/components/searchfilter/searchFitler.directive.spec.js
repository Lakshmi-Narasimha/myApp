'use strict';

describe('Directive : Search Filter', function() {
    var rootScope, scope, compile, $window, event, directiveElem, isolatedScope, searchController, timeout;    
    var data = {
        category: "PA",
        title: "PAN as Any holder"
    }  
    var panView = {
            PAN_FILTER_OPT: [{
                title: 'PAN as Any holder',
                category: 'PA'
            }, {
                title: 'PAN as First holder',
                category: 'PF'
            }],
            DATE_FILTER_OPT: [{
                id: 1,
                key: 'AD',
                label: 'As on Date',
                type: 'fulldate'
            }, {
                id: 2,
                key: 'LF',
                label: 'Last financial year',
                type: 'defineddate'
            }, {
                id: 3,
                key: 'DR',
                label: 'Date Range',
                type: 'daterange'
            }, {
                id: 4,
                key: 'SI',
                label: 'Since Inception',
                type: 'defineddate'
            }],
        } 
    var panFilter = { 
                dayFlag: 'AD', 
                fromDate: new Date(), 
                toDate: new Date(), 
                flag: 'PA', 
                folioPanAccNo: '17877097' 
            };   
    var getCompiledElement = function() {
        var element = angular.element('<ftic-pan-search-filter></ftic-pan-search-filter>');
        var compiledElement = compile(element)(scope);
        scope.$digest();
        return compiledElement;
    };
    
    beforeEach(angular.mock.module('investor'));

    beforeEach(function() {
        angular.mock.inject(function(_$compile_, _$rootScope_, _$timeout_, _$window_) {
            rootScope = _$rootScope_;
            compile = _$compile_;
            timeout = _$timeout_;
            scope = rootScope.$new();
            $window = _$window_;
            $window.ga = function() {};
            event = document.createEvent("MouseEvent");
            event.initMouseEvent("click", true, true);

            directiveElem = getCompiledElement();
            isolatedScope = directiveElem.isolateScope();
        })

        spyOn(scope, '$broadcast');
    });

    it('should be defined', function() {
        expect(directiveElem).toBeDefined();
    });

    it('should be defined with scope:true', function() {
        expect(directiveElem.scope()).toBeDefined();
    });

    it('should create a separate isolatedscope', function() {
        expect(isolatedScope).toBeDefined();
    });

    it('should expect PanSearchVM to be defined and have values', function() {
        expect(isolatedScope.panSearchVM).toBeDefined();
        expect(isolatedScope.panSearchVM.dateOptions).toBeDefined();
        expect(isolatedScope.panSearchVM.searchOptions).toBeDefined();
        expect(isolatedScope.panSearchVM.hideSelect).toBe(true);
    });

    it('should call EVT_SELECTED_PAN_AS function', function() {
        scope.$broadcast('EVT_SELECTED_PAN_AS', event, data);
        expect(scope.$broadcast).toHaveBeenCalledWith('EVT_SELECTED_PAN_AS', event, data);   
    });

    it('should call selectedValue function', function() {
        scope.$broadcast('selectedValue', event, panView.DATE_FILTER_OPT[0]);
        expect(scope.$broadcast).toHaveBeenCalledWith('selectedValue', event, panView.DATE_FILTER_OPT[0]);   
    });

    it('should call emitApply function', function() {
        spyOn(isolatedScope, 'emitApply').and.callThrough();
        scope.$broadcast('getcurrentdate', event, panFilter.fromDate);
        expect(scope.$broadcast).toHaveBeenCalledWith('getcurrentdate', event, panFilter.fromDate);   
        expect(isolatedScope.initFlag).toBeDefined();
        timeout.flush();
        expect(isolatedScope.emitApply).toHaveBeenCalled();
    });

    it('should emit apply event', function() {   
        spyOn(isolatedScope, 'emitApply').and.callThrough();
        spyOn(isolatedScope, '$emit');
        isolatedScope.emitApply();
        expect(isolatedScope.emitApply).toHaveBeenCalled();
        expect(isolatedScope.$emit).toHaveBeenCalledWith('apply', panFilter);
    });

    it('should call getdaterange function', function() {
        scope.$broadcast('getdaterange', event, panFilter.fromDate, panFilter.toDate);
        expect(scope.$broadcast).toHaveBeenCalledWith('getdaterange', event, panFilter.fromDate, panFilter.toDate);
    });

    it('should call fticcmpFilterEvent function', function() {
        var inputVal = panFilter.fromDate;
        var inputType = 'dtr1';
        scope.$broadcast('fticcmpFilterEvent', event, inputVal, inputType);
        expect(scope.$broadcast).toHaveBeenCalledWith('fticcmpFilterEvent', event, inputVal, inputType);
        inputVal = panFilter.toDate;
        inputType = 'dtr2';
        scope.$broadcast('fticcmpFilterEvent', event, inputVal, inputType);
        expect(scope.$broadcast).toHaveBeenCalledWith('fticcmpFilterEvent', event, inputVal, inputType);
    });
});