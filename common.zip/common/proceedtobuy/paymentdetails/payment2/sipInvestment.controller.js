/**
 * @ngdoc property
 * @name payment 2 Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the Fund Details Lumpsum controller for Advisor module.
 *
 **/
 'use strict';
// Controller naming conventions should start with an uppercase letter
function payment2Ctrl($scope, $state, buildPlanModelService,buildPlanInitialLoader,keyValueGridConfig,TransactConstant,transactModel,$timeout,fundDetails, planSmartSolution, $stateParams, authenticationService, truncateTextService) {   
    
    $scope.isNewInvestor = transactModel.isNewInvestor;

    if(transactModel.getIsNewFolio())
    {
        $scope.isNewInvestor = true;
    }
var celltemp = '<div class="ui-grid-cell-contents" title="{{col.colDef.data[grid.renderContainers.body.visibleRowCache.indexOf(row)].fundName_orignal}}">{{COL_FIELD}}</div>';
    if(authenticationService.isInvestorLoggedIn()) {
        $scope.terms = {
            show: true
        };
    }
        
    $scope.sipFundDetails = angular.copy(planSmartSolution.getSIPFunds());
    $scope.sipFundDetails = truncateTextService.updateLabel(angular.copy($scope.sipFundDetails), 'fundName', 27);
    $scope.sipcolumnDefs = keyValueGridConfig.fundGridConfig[TransactConstant.guest.SMARTSIPINV];
    $scope.sipcolumnDefs[0].data = $scope.sipFundDetails;
    $scope.sipcolumnDefs[0].cellTemplate = celltemp;  
    var flag = false;
    $scope.accordionClicked = function(){        
        transactModel.setTransactType(TransactConstant.sip.SIP);
        $scope.showComp = true;
        if(!flag && ($stateParams.key !== TransactConstant.transact.Payment_Key)) {
            $timeout(function () {
                $scope.$broadcast('Go_To_Payment_Dtls');
            }, 0);
            flag = true;
        }
        
        fundDetails.removeFundDetails();
        
        angular.forEach(planSmartSolution.getSIPFunds(),function(obj){
            if(!angular.isNumber(obj.sipAmount)) {
                obj.sipAmount = obj.sipAmount.indexOf(',') >-1 ? obj.sipAmount.replace(/,/g, '') : obj.sipAmount;
            }

            fundDetails.setFundDetails(obj);
        });

        transactModel.setSipFundDtls(fundDetails.getFundDetails()); 
    };
    
    if(planSmartSolution.getTransactType()!=='Combo')
    {
        $scope.accordionClicked();
        $scope.isOpenInvGrid = {
            'open': true      
        };
    }

    $scope.$on('openSipAccordion',function(){
        $scope.accordionClicked();
        $scope.isOpenInvGrid = {
            'open': true      
        };
    });

    $scope.$on('openLumpsumAccordion',function(){
        $scope.isOpenInvGrid = {
            'open': false
        };
    });
    
}
payment2Ctrl.$inject = ['$scope', '$state', 'buildPlanModelService','buildPlanInitialLoader', 'keyValueGridConfig','TransactConstant','transactModel','$timeout','fundDetails', 'planSmartSolution', '$stateParams', 'authenticationService', 'truncateTextService'];
module.exports = payment2Ctrl;