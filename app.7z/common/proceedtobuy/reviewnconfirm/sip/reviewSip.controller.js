/**
 * @ngdoc property
 * @name review sip Controller
 * @requires $scope
 * @requires $state
 * @description
 *
 * - It is the review sip controller for guest module.
 *
 **/
'use strict';
// Controller naming conventions should start with an uppercase letter
function reviewSipController($scope, $state, keyValueGridConfig, TransactConstant, buildPlanModelService, $timeout, bankDtlsModel, profileDetailsModel, planSmartSolution, $filter, transactModel, fundDetails, $uibModal, eventConstants, $location, authenticationService) {

    var reqParams,paymentMethod,totalAmount,queryParams = $location.search();

    $scope.accordionClicked = function () {

        $scope.showSipComponents = true;

        if(queryParams.successFlag === "false" && queryParams.retryFlag === "false"){
            return;
        }

        reqParams = transactModel.getSipReqParams();
        paymentMethod = "";
        totalAmount = 0;

        angular.forEach(reqParams.fundOptions, function (obj, ind) {
            totalAmount = totalAmount + parseInt(obj.amount)
        })

        // Review Details
        fundDetails.removeFundDetails();
        angular.forEach(transactModel.getSipFundDtls(), function (obj, ind) {
            fundDetails.setFundDetails(obj)
        })

        $scope.showFundDtls = true;
        $scope.isNewInvestor = transactModel.isNewInvestor;

        transactModel.setTransactType(TransactConstant.sip.SIP);

        switch (reqParams.paymentMode) {
            case TransactConstant.common.EMANDATE_CODE:
                paymentMethod = TransactConstant.transact.SETUP_NEW_MANDATE;
                break;
            case TransactConstant.common.NET_BANKING_CODE:
                paymentMethod = TransactConstant.transact.NET_BANKING;
                break;
            case TransactConstant.common.NEFT_CODE:
                paymentMethod = TransactConstant.transact.NEFT_RTGS;
                break;
            case TransactConstant.common.DEBIT_CARD_CODE:
                paymentMethod = TransactConstant.transact.DEBIT_CARD;
                break;
            case TransactConstant.common.AUTO_DEBIT_CODE:
                paymentMethod = TransactConstant.transact.AUTO_DEBIT;
                break;
            case TransactConstant.common.BILL_PAY_CODE:
                paymentMethod = TransactConstant.transact.BILL_PAY;
                break;
        }
        /**
         * Changed the order of paymentDetails - Defect - Investor
         */
        $scope.paymentDetails = [
            /*{
                text: "Transaction Reference No.",
                value: transactModel.getSipWebRefNo()
            },
            */
            {
                text: "Mode of Payment",
                value: paymentMethod || "NA"
            },
            {
                text: "Bank Details",
                value: reqParams.bankName || "NA"
            },
            {
                text: 'Total Investment Amount',
                value: totalAmount ? '<span class="icon-fti_rupee"></span>' + totalAmount : 'NA'
            },
            {
                text: "Advisor ARN",
                value: profileDetailsModel.getProfileDtls() ? profileDetailsModel.getProfileDtls().profileDetails.ARN : ''
            }
        ];

        if(transactModel.isPaperless || $scope._isInvestor){
            $scope.paymentDetails.pop();
        }

        // -------Transaction details
        $scope.SIPkeyValueList = [
            {key: "Folio. No.", value: transactModel.getInvestorDetails().folioId},
            {key: "First Holder", value: transactModel.getInvestorDetails().custName}
        ];        

        $scope.infoObj = [];
        var SIPFunds = fundDetails.getFundDetails();
        angular.forEach(SIPFunds, function (obj) {
            $scope.infoObj.push([
                {
                    text: "Fund Name",
                    value: obj.fundName
                },
                {
                    text: "Account Number",
                    value: obj.accNo
                },
                {
                    text: "SIP amount",
                    value: obj.sipAmount
                },
                {
                    text: "Dividend Option",
                    value: obj.dividend || ""
                },
                {
                    text: "SIP First Installment date",
                    value: "Current Business Day"
                },
                {
                    text: "SIP Future installment date",
                    value: obj.futureInstallment || ""
                },
                {
                    text: "SIP End Date",
                    value: obj.endDate
                },
                {
                    text: "Frequency",
                    value: obj.frequency
                }
            ]);
        });

        $scope.showDtls.keyValueList = [
            {key: 'Transaction Reference Number', value: transactModel.getSipWebRefNo()},
            {key: 'Request Date and Time', value: $scope.showDtls.requestDateAndTime},
            {key: 'Total Investment Amount', value: totalAmount}
        ];

    };

    $scope.postTransactDataSip = function (advisorDetailsForm) {
        $scope.postReviewDetails("sip")
    };

    $scope.termsNconditions = function () {
        var modalInstance = $uibModal.open({
            template: require('../components/termsNconditions/termsNconditions.html'),
            scope: $scope,
            size: 'lg'
        });
    };

    $scope.reviewStandards = function() {

        var modalInstance = $uibModal.open({
            template: require('../../../transact/review/components/serviceStandards/serviceStandards.html'),
            scope: $scope,
            size: 'lg'
        });
    };


    if(planSmartSolution.getTransactType()!=="Combo")
    {
        $scope.accordionClicked();
        $scope.isOpenInvGrid = {
            'open': true      
        };
    }

    

    // $scope.$on('INV_OPEN_ACC', function(event, data) {
        
    //     $timeout(function() {

    //         if (data.type === 'sip') {
    //             $scope.accordionClicked();
    //             $scope.isOpenInvGrid = {
    //                 'open': true
    //             };
    //         } else {
    //             $scope.isOpenInvGrid = {
    //                 'open': false
    //             };
    //         }
    //     });
        
    // });
    $scope.$on(eventConstants.INV_OPEN_SIP_ACC,function(){
        $scope.accordionClicked();
        $scope.isOpenInvGrid = {
            'open': true      
        };
    });

    $scope.$on(eventConstants.INV_OPEN_LUMP_ACC,function(){
        $scope.isOpenInvGrid = {
            'open': false
        };
    });
    

    $scope.saveTransaction = function(){
        var details = {};
        details.bankDetails = reqParams.bankName+"-"+reqParams.bankAccountNumber;
        details.paymentMethod = paymentMethod;
        details.fundDetails = [];
        angular.forEach(fundDetails.getFundDetails(),function(obj,ind){
            var fundObj = {};
            fundObj.fund = obj.fundName;
            fundObj.sipAmount = obj.sipAmount;
            fundObj.dividend = obj.dividendFlag === "R" ? "Re-Investment" : (obj.dividendFlag === "P" ? "Payout" : "NA");
            fundObj.sipFirstInstallment = obj.firstInstallment;
            fundObj.sipFutureInstallment = obj.futureInstallment;
            fundObj.sipEndDate = obj.sipenddate || obj.endDate;
            fundObj.stepUp = obj.stepUpSip;
            details.fundDetails.push(fundObj);
        })
        $scope.submit.saveTransaction(details)
    }

}


reviewSipController.$inject = ['$scope', '$state', 'keyValueGridConfig', 'TransactConstant', 'buildPlanModelService', '$timeout', 'bankDtlsModel', 'profileDetailsModel', 'planSmartSolution', '$filter', 'transactModel', 'fundDetails', '$uibModal', 'eventConstants', '$location', 'authenticationService'];
module.exports = reviewSipController;