var express = require('express'),
    router = express.Router(),
    folioViewData = require('./valuation_statements/getFolioView.model'),
    panViewData = require('./valuation_statements/getPanView.model'),
    unitHolderData = require('./valuation_statements/getUnitHolderDetails.model'),
    SysPlansSIPRegdModel = require('./sysplans/sipregd.model'),
    SysPlansSTPRegdModel = require('./sysplans/stpregd.model'),
    SysPlansSWPRegdModel = require('./sysplans/swpregd.model'),
    SysPlansSIPInstallmentModel = require('./sysplans/sipinstallment.model'),
    SysPlansSTPInstallmentModel = require('./sysplans/stpinstallment.model'),
    SysPlansSWPInstallmentModel = require('./sysplans/swpinstallment.model'),
    CapitalGainsAccountModel = require('./getcgaccountdetails.model'),
    accountViewData = require('./valuation_statements/getAccountView.model'),
    CapitalGainsFolioModel = require('./getcgfolio.model'),
    accountViewData = require('./valuation_statements/getAccountView.model'),        
    PurchaseSummaryModel = require('./transactions/getPurchaseSummary.model'),
    PurchaseDetailsModel = require('./transactions/getPurchaseDetails.model'),
    RedumptionSummaryModel = require('./transactions/getRedumptionSummary.model'),
    RedumptionDetailsModel = require('./transactions/getRedumptionDetails.model'),
    SwitchSummaryModel = require('./transactions/getSwitchSummary.model'),
    SwitchDetailsModel = require('./transactions/getSwitchDetails.model'),
    DividendSummaryModel = require('./transactions/getDividendSummary.model'),
    DividendDetailsModel = require('./transactions/getDividendDetails.model'),
    LienSummaryModel = require('./transactions/getLienSummary.model'),
    PostalReturnsSummaryModel = require('./transactions/getPostalReturnsSummary.model'),
    NominationDetailsSummaryModel = require('./transactions/getNominationDetailsSummary.model'),
    searchResult = require('./searchResult.model'),
    SubscriptionDetailsModel = require('./subscriptions/subscriptionDetails.model');

// api route

var error = {status: 300, message: 'Something went wrong!!'}; /* Error messge object */


router.route('/getFolioViewDtls')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        folioViewData.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].folioViewObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].folioViewObject);
                //res.send(500, error);
            }

        });
});

//PAN view
router.route('/getPanViewDtls')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        panViewData.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].PanViewObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].PanViewObject);
                //res.send(500, error);
            }

        });
});


// Sys Plans
router.route('/SysPlansSIPRegistration')
    .get(function (req, res) {
        SysPlansSIPRegdModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].sipRegdResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].sipRegdResp);
            }

        });

});

// SIP Installment
router.route('/SysPlansSIPInstallment')
    .get(function (req, res) {
        SysPlansSIPInstallmentModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].sipInstallmentResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].sipInstallmentResp);
            }

        });

});

// STP Registration
router.route('/SysPlansSTPRegistration')
    .get(function (req, res) {
        SysPlansSTPRegdModel.find(function (err, data) {

            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].stpRegdResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].stpRegdResp);
            }

        });

});

// STP Installment
router.route('/SysPlansSTPInstallment')
    .get(function (req, res) {
        SysPlansSTPInstallmentModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].stpInstallmentResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].stpInstallmentResp);
            }

        });

});

// SWP Registration
router.route('/SysPlansSWPRegistration')
    .get(function (req, res) {
        SysPlansSWPRegdModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].swpRegdResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].swpRegdResp);
            }

        });

});
// SWP Installment
router.route('/SysPlansSWPInstallment')
    .get(function (req, res) {
        SysPlansSWPInstallmentModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].swpInstallmentResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].swpInstallmentResp);
            }

        });

});

router.route('/getPurchaseSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        PurchaseSummaryModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].PurchaseSummaryResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].PurchaseSummaryResp);
            }

        });
    });

router.route('/getPurchaseDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        PurchaseDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].PurchaseDetailsResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].PurchaseDetailsResp);
            }

        });
    });

router.route('/getRedumptionSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        RedumptionSummaryModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].RedumptionSummaryResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].RedumptionSummaryResp);
            }

        });
    });
    
router.route('/getRedumptionDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        RedumptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].RedumptionDetailsResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].RedumptionDetailsResp);
            }

        });
    });
    
router.route('/getNominationDetailsSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        NominationDetailsSummaryModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].NominationDetailsSummaryResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].NominationDetailsSummaryResp);
            }

        });
    });
    
router.route('/getAccountViewDtls')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        accountViewData.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].accountViewObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].accountViewObject);
                //res.send(500, error);
            }

        });
});

router.route('/getDividendsSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        DividendSummaryModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].dividendSummaryResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].dividendSummaryResp);
            }

        });
    });

router.route('/getDividendsDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        DividendDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].dividendDetailsResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].dividendDetailsResp);
            }

        });
    });

router.route('/getSwitchSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SwitchSummaryModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].switchSummaryResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].switchSummaryResp);
            }

        });
    });

router.route('/getSwitchDetails')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SwitchDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].switchDetailsResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].switchDetailsResp);
            }

        });
    });
    
router.route('/getLienSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        LienSummaryModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].LienSummaryResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].LienSummaryResp);
            }

        });
    });

router.route('/getPostalReturnsSummary')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        PostalReturnsSummaryModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].PostalReturnsSummaryResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].PostalReturnsSummaryResp);
            }

        });
    });
    
router.route('/getAccountViewDtls')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        accountViewData.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].accountViewObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].accountViewObject);
                //res.send(500, error);
            }

        });
});

router.route('/getcgaccountdetails')
  .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        CapitalGainsAccountModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].capitalGainsAccountObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].capitalGainsAccountObject);
            }

        });
    });
router.route('/getcapitalgainsfoliodetails')
  .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        CapitalGainsFolioModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].accountStatementResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].accountStatementResp);
            }

        });
    });

router.route('/getsearchresult')
  .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        searchResult.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].searchResultResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].searchResultResp[0]);
            }

        });
    });
  router.route('/getcgfoliodetails')
  .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        CapitalGainsFolioModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].folioResp.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].folioResp);
            }

        });
    });
router.route('/getUnitHolderDtls')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        unitHolderData.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute
            if (err) {
                res.send(err);
            } else if (data[0].UnitHolderObject.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].UnitHolderObject);
                //res.send(500, error);
            }

        });
});

router.route('/getSubscriptionDetailsData')
    .get(function(req, res) {
        // use mongoose to get all nerds in the database
        // Mandatary elements are present
        SubscriptionDetailsModel.find(function (err, data) {
            // if there is an error retrieving, send the error. 
            // nothing after res.send(err) will execute 
            if (err) {
                res.send(err);
            } else if (data[0].subscriptionDetails.length === 0) {
                res.send(error);
            } else {
                res.json(data[0].subscriptionDetails);
            }

        });
    });

module.exports = router;
