define([
  'jquery',
  'underscore',
  'backbone',
  'backbonesubroute',
  'appcommon/memmorymgr',
  'appmodules/accountviewer/avcommon',
  'appcommon/globalcontext',
  'appmodules/accountviewer/app/views/accountview',
  'appmodules/accountviewer/app/views/accountdetailsview',
  'appmodules/accountviewer/app/views/activitylistview',
  'appmodules/accountviewer/app/views/accountstatementsview',
  'appmodules/accountviewer/app/views/accountfinancialView',
  'appmodules/accountviewer/app/views/accountportfolioView',
  'appmodules/accountviewer/app/views/accountarrangementView',
  'errorLog',
  'appcommon/commonutility',
  'apipublic/navapi',
  'appcommon/constants',
  'text!appmodules/accountviewer/app/templates/accountshell.html',
  'appmodules/accountviewer/app/views/accountshellview',
  'text!appmodules/accountviewer/app/templates/accounttotalvalue.html',
  'appmodules/accountviewer/app/data/accountviewdatamodule',
  'appmodules/accountviewer/app/models/accountviewmodel',
], function ($, _, Backbone, backbonesubroute, MemoryMgr, AccountViewCommon, GlobalContext, AccountView, AccountDetailsView, ActivityListView, AccountstatementsView, AccountfinancialView, AccountportfolioView, AccountarrangementView, ErrorLog, Utils, NavApi, Constants, AccountShellTemplate, AccountShellView, AccountTotalValue, AccountViewDataModule, accountViewData) {

    var self=null,avRouter = Backbone.SubRoute.extend({
        routes: {
          //  'accountdetails/accountlist': 'showaccntlist',
            'moneymovements': 'donothing',
            'accntmntce': 'donothing',
            'accountholder': 'donothing',
            'accountdetails/:accountid/:productCd': 'showproduct',
            'activitylist': 'showactivitylist',
            'accountstatements': 'showaccountstatements',
            'financial': 'showfinancial',
            'portfolio': 'showportfolio',
            'arrangement': 'showarrangement',
            '*actions': 'defaultAction'
        },
        initialize: function () {
            self = this;
            this.accountview = null;
            $(document).off("GroupChangedInAccountsSubTab").on("GroupChangedInAccountsSubTab", self.groupChangeListener);
            $(document).off("GroupChangedEvent").on("GroupChangedEvent", self.handleGroupChange);
        },
        defaultAction : function (actions) {
            this.renderAccountShellView({ "callback": this.renderAccountView });
        },
        showaccountstatements: function () {
            this.renderAccountShellView({ "callback": this.renderStatements });
        },
        showfinancial: function () {
            this.renderAccountShellView({ "callback": this.renderFinancial });
        },
        showportfolio: function () {
            this.renderAccountShellView({ "callback": this.renderPortfolio });
        },
        showarrangement: function () {
            this.renderAccountShellView({ "callback": this.renderArrangements });
        },
        showproduct : function (accountId) {
            var detailsView = new AccountDetailsView(this.createDetailsViewParameters(accountId));
            MemmoryMgr.setcurrentview(detailsView);
            detailsView.render();
        },
        showactivitylist: function () {
            this.renderAccountShellView({ "callback": this.renderActivitylist });
        },
        createDetailsViewParameters: function(accountId) {
            var clientId = GlobalContext.getInstance().getGlobalContext().Context.ContactId;
            var groupId = GlobalContext.getInstance().getGlobalContext().Context.GroupId;
            var accountListItemModel = _.find(this.accountview.accountViewDataCollection, function(acct) {return acct.get('id') == accountId;});
            var accountProduct = accountListItemModel.get('accountProduct');
            var accountBalance = accountListItemModel.get('accountBalance');
            var accountRegistration = accountListItemModel.get('accountRegistration');
            var ownershipNames = _.pick(accountRegistration.toJSON(), 'legalTitle1Txt', 'legalTitle2Txt', 'legalTitle3Txt', 'legalTitle4Txt', 'legalTitle5Txt');
            ownershipNames = _.filter(ownershipNames, function(name) {return !Utils.isEmpty(name)});
            var accountSummary = {
                accountId: accountListItemModel.get('id'),
                fmtId: accountListItemModel.get('fmtId'),
                productCd: accountListItemModel.get('productCd'),
                longProdName: accountProduct.get('longNm'),
                mediumProdName: accountProduct.get('mediumNm'),
                fmtAccountBalance: accountBalance.get('totAcctBalFmtd'),
                statusCd: accountListItemModel.get('statusCd'),
                openDt: accountListItemModel.get('openDt') ? accountListItemModel.get('openDt').formatDateMMddYYYY() : null,
                ownershipNames: ownershipNames,
                accountPlan: accountListItemModel.get('accountPlan'),
                taxQualCd: accountListItemModel.get('taxQualCd'),
                planId: accountListItemModel.get('planId'),
                asOfDate: accountBalance.get('valueDt') ? accountBalance.get('valueDt') : null,
                adminCd: accountListItemModel.get("adminCd"),
                strategyNm: accountProduct.get("strategyNm"),
                brkgProdClsCd: accountProduct.get("brkgProdClsCd"),
                brkgProdClsNm: accountProduct.get("brkgProdClsNm"),
            };
            return {
                clientId: clientId, 
                groupId: groupId,
                accountSummary: accountSummary,
                errorHandler: function(error) {ErrorLog.ErrorUtils.myError(error);},
                clientPickHandler: function(clientId) {NavApi.changeContactAndLauchCP(clientId, Constants.contactType.Client);}
            }; 
        },
        renderAccountShellView: function (options) {
            if ($(".av-accounts-group-container").length < 1) {
                var _accountShellView = new AccountShellView();
                    _accountShellView.render(options);
            } else {
                options.callback();
            }
        },
        renderAccountView: function (response) {
            var globalcontext = GlobalContext.getInstance();
            self.accountview = new AccountView();
            MemmoryMgr.setcurrentview(self.accountview);
            var options = {
                groupId: globalcontext.getGlobalContext().Context.GroupId,
                fmId: AccountViewCommon.readCookie('FMID'),
                clientId: globalcontext.getGlobalContext().Context.ContactId
            };
            options.accounDetails = response ? response : null;
            self.accountview.render(options);
        },
        renderStatements: function (response) {
            var accountstatementsView = new AccountstatementsView();
            MemmoryMgr.setcurrentview(accountstatementsView);
            var globalcontext = GlobalContext.getInstance();
            var options = {
                groupId: globalcontext.getGlobalContext().Context.GroupId,
                fmId: AccountViewCommon.readCookie('FMID'),
                clientId: globalcontext.getGlobalContext().Context.ContactId
            };
            options.accounDetails = response ? response : null;
            accountstatementsView.render(options);
        },
        renderFinancial: function (response) {
            var accountfinancialView = new AccountfinancialView();
            MemmoryMgr.setcurrentview(accountfinancialView);
            var globalcontext = GlobalContext.getInstance();
            var options = {
                groupId: globalcontext.getGlobalContext().Context.GroupId,
                fmId: AccountViewCommon.readCookie('FMID'),
                clientId: globalcontext.getGlobalContext().Context.ContactId
            };
            options.accounDetails = response ? response : null;
            accountfinancialView.render(options);
        },
        renderPortfolio: function (response) {
            var accountportfolioView = new AccountportfolioView();
            MemmoryMgr.setcurrentview(accountportfolioView);
            var globalcontext = GlobalContext.getInstance();
            var options = {
                groupId: globalcontext.getGlobalContext().Context.GroupId,
                fmId: AccountViewCommon.readCookie('FMID'),
                clientId: globalcontext.getGlobalContext().Context.ContactId
            };
            options.accounDetails = response ? response : null;
            accountportfolioView.render(options);
        },
        renderArrangements: function (response) {
            var accountarrangementView = new AccountarrangementView();
            MemmoryMgr.setcurrentview(accountarrangementView);
            var globalcontext = GlobalContext.getInstance();
            var options = {
                groupId: globalcontext.getGlobalContext().Context.GroupId,
                fmId: AccountViewCommon.readCookie('FMID'),
                clientId: globalcontext.getGlobalContext().Context.ContactId
            };
            options.accounDetails = response ? response : null;
            accountarrangementView.render(options);
        },
        renderActivitylist: function (response) {
            var activitylistView = new ActivityListView();
            MemmoryMgr.setcurrentview(activitylistView);
            var globalcontext = GlobalContext.getInstance();
            var options = {
                groupId: globalcontext.getGlobalContext().Context.GroupId,
                fmId: AccountViewCommon.readCookie('FMID'),
                clientId: globalcontext.getGlobalContext().Context.ContactId
            };
            options.accounDetails = response ? response : null;
            activitylistView.render(options);
        },
        groupChangeListener: function (event) {
            var _route = event.message;
            switch (_route) {
                case "accountviewer/accountstatements":
                    self.renderStatements();
                    break;
                case "accountviewer/activitylist":
                    self.renderActivitylist();
                    break;
            }
        },
        handleGroupChange: function () {
            if (location.hash != "#accountviewer/") {
                $("#acc-total-val-conatiner-desk-tab, #acc-total-val-conatiner-mobile").empty();
                AccountViewDataModule.getAccountViewData(self.loadAccountInfo);            
            }
        },
        loadAccountInfo: function (accounDetails) {
            var _$aactSummaryContainer = $("#acc-total-val-conatiner-desk-tab, #acc-total-val-conatiner-mobile");
            var _gContext = GlobalContext.getInstance().getGlobalContext().Context;
            var _groupId = _gContext.GroupId, _partialOutput = false, _acctDt,
                _accountViewDataCollection = [], _accountvalTemplate = _.template(AccountTotalValue);
            var _acctngDateResp = accounDetails.accountingDateResp, _accountListResp = accounDetails.accountViewResp;
            if (_acctngDateResp && _acctngDateResp.d && _acctngDateResp.d.acctDt) {
                _acctDt = _acctngDateResp.d.acctDt;
            }
            if (_accountListResp && _accountListResp[0]) {
                _accountListResp = _accountListResp[0]['attributes'];
            } else {
                _accountListResp = _accountListResp['results'][0]['attributes'];
            }
            
            if (_accountListResp.dstrOverviewProcessingStatus.attributes.statCd && _accountListResp.dstrOverviewProcessingStatus.attributes.statCd == "0001") {
                _partialOutput = true;
            }
            var _totalValue = accountViewData.fillAccountListData(_accountListResp.overviewAccount, _accountViewDataCollection, _groupId);
            _$aactSummaryContainer.html(_accountvalTemplate({ "accountList": _accountViewDataCollection, "accountTotal": _totalValue, "partialOutput": _partialOutput, "acctDt": _acctDt }));
        }
    });

    return { avRouter: avRouter };
});