/**
 * @ngdoc service
 * @name FTI FamilyPortfolio Initial Load Service
 * @requires cgAccDetModel
 * @requires investorEvents
 * @requires toaster
 * @requires $timeout
 * loggerConstants
 * $loader
 * @description
 *
 * - Handles the services and model for FamilyPortFolio content details
 *
 */
'use strict';

var fticFamilyPortfolioLoadInitialService = function(familyPortfolioModel, investorEvents,  toaster, $loader) {
	var fticFamilyPortfolioLoadInitialService = {
		_isServicesData: false,
		loadAllServices : function (scope) {
            function familyPortfolioListSuccess(data){
				familyPortfolioModel.setFamilyPFList(data);
				investorEvents.myPortfolio.familyPortfolioList(scope);
			}
			function promiseFailure (data) {
				fticFamilyPortfolioLoadInitialService._isServicesData = false;
				toaster.error(data.data[0].errorDescription);
                console.log('fail',data);
			}
			function stopLoader() {
                $loader.stop();
            }
            $loader.start();
			familyPortfolioModel.fetchFamilyPFList()
			.then(familyPortfolioListSuccess, promiseFailure).finally(stopLoader);
		}
	};
	return fticFamilyPortfolioLoadInitialService;
};
fticFamilyPortfolioLoadInitialService.$inject = ['familyPortfolioModel', 'investorEvents', 'toaster', '$loader'];
module.exports = fticFamilyPortfolioLoadInitialService;