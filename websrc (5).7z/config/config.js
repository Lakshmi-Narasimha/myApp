var logger = require('./logger');

var devConfig = {
    "TC_FORM_LOGIN_URI": "/j_spring_security_check",
    "TC_ENGAGEMENT_URI": "/engagementAPI/v1/customer/engagement?output=JSON",
    "TC_GET_MSG_URI": "/engagementAPI/v1/customer/message?output=json&engagementID=",
    "TC_SEND_MSG_URI": "/engagementAPI/v1/customer/message",
    "TC_SURVEY_URI": "/engagementAPI/v1/customer/surveyUrl?output=JSON",
    "TC_DATA_PASS_URI": "/engagementAPI/v1/customer/dataPass",
    "TC_SITE_ID": "10004593",
    "BU_WirelessCare": "19000866",
    "BU_WirelessSales": "19000860",
    "BU_WirelessBGCO": "19000909",
    "BU_WirelessPrepaidCare": "19000910",
    "BU_WirelessHBA": "19000919",
    "AG_Billing": "10004688",
    "AG_Device": "10004690",
    "AG_Global": "10004689",
    "AG_MVTrans": "10004687",
    "AG_WirelessSales": "10004697",
    "AG_Test": "10004711",
    "BR_Billing": "MobileApp-Billing-DTSP", ////new addition// Business Rule ID
    "BR_Device": "MobileApp-Device-DTSP", ////new addition// Business Rule ID
    "BR_Global": "MobileApp-Global-DTSP", ////new addition// Business Rule ID
    "BR_MVTrans": "MobileApp-MVTrans-DTSP", ////new addition// Business Rule ID
    "BR_WirelessSales": "MobileApp-WirelessSales", ////new addition// Business Rule ID
    "AG_Spanish_Billing": "10004856",
    "AG_Spanish_MVTrans": "10004858",
    "AG_Spanish_Device": "10004860",
    "AG_Spanish_Global": "10004857",
    "AG_Care-Escalations": "10004712",
    "AG_Sales-Escalations": "10004713",
    "AG_Care_Escalations_Spanish": "10004878",
    "AG_BGCO-General": "10004875",
    "AG_English_Prepaid": "10004876",
    "AG_Spanish_Prepaid": "10004877",
    "AG_Prepaid-Escalations": "10004892",
    "AG_HBA-Care": "10004898",
    "AG_HBA-Spanish": "10004899",
    "AG_HBA-Tech": "10004900",
    "TC_SERVER_NAME": "api-verizon-dev.touchcommerce.com",
    "TC_API_USERNAME": "VWMobApp",
    "TC_API_PASSWORD": "x95VIFsC",
    "TC_AGENT_URI": "/engagementAPI/v1/customer/agentAvailability?output=JSON",
    "VZW_PROXY_SERVER_NAME": "server.proxy.vzwcorp.com",
    "VZW_PROXY_PORT_NUMBER": "9290",
    "TC_CUTOMER_TYPING_URI": "/engagementAPI/v1/customer/customerIsTyping",
    "HTTPCLIENT_POOL_SIZE": "400",
    "TC_ENGAGEMENT_PRIORITY": "600",
    "TC_ENGAGEMENT_QUEUE_THRESHOLD": "1.5",
    "TC_CHAT_HIST_URL": "https://ech.vzwcorp.com/echreports/transcripts/getChatPage?realTimeID=",
    "Mobile_CareNoNPS_URL": "https://app.keysurvey.com/f/1011097/56e5/?LQID=1&",
    "Mobile_CareNPS_URL": "https://app.keysurvey.com/f/1011103/171e/?LQID=1&",
    "Mobile_SalesNoNPS_URL": "https://app.keysurvey.com/f/989819/10d2/?LQID=1&",
    "Mobile_SalesNPS_URL": "https://app.keysurvey.com/f/989818/8bb1/?LQID=1&",
    "LP_API_VERSION": "1",
    "LP_SERVER_NAME": "https://api.liveperson.net/",
    "LP_BASE_URI": "api/account/11146012?v=1",
    "LP_SKILL_NAME": "verizon-mobilefirst-tmp",
    "LP_APP_KEY": "f0dea91cd8974dcfbdb10cb4b29ac8b3",
    "TC_ENGAGEMENT_SALES_PRIORITY": "1",
    "TC_ENGAGEMENT_SALES_QUEUE_THRESHOLD": "0.9",
    "NLP_SERVER_URL": "http://app111dev.hss.vzwcorp.com:9094/nlp",
    "NLP_LOG_URI": "/getMobileFirstLog",
    "SHOW_CHAT_HISTORY_FLAG": "FALSE",
    "TC_AGENT_BUSY_FLAG": "FALSE",
    "TC_AGENT_RETRY_TIMES": "6",
    "TC_AGENT_RETRY_TIME_PERIOD": "5",
    "TC_CONVERSION_URI": "/engagementAPI/v1/dataCollection/conversion",
    "TC_ASSISTED_URI": "/engagementAPI/v1/customer/event/assisted",
    "Launch_Type": "MobileApp-DTSP"

};

var prodConfig = {
    "TC_FORM_LOGIN_URI": "/j_spring_security_check",
    "TC_ENGAGEMENT_URI": "/engagementAPI/v1/customer/engagement?output=JSON",
    "TC_GET_MSG_URI": "/engagementAPI/v1/customer/message?output=json&engagementID=",
    "TC_SEND_MSG_URI": "/engagementAPI/v1/customer/message",
    "TC_SURVEY_URI": "/engagementAPI/v1/customer/surveyUrl?output=JSON",
    "TC_DATA_PASS_URI": "/engagementAPI/v1/customer/dataPass",
    "TC_SITE_ID": "10004593",
    "BU_WirelessCare": "19000866",
    "BU_WirelessSales": "19000860",
    "BU_WirelessBGCO": "19000909",
    "BU_WirelessPrepaidCare": "19000910",
    "BU_WirelessHBA": "19000919",
    "AG_Billing": "10004688",
    "AG_Device": "10004690",
    "AG_Global": "10004689",
    "AG_MVTrans": "10004687",
    "AG_WirelessSales": "10004697",
    "AG_Test": "10004711",
    "BR_Billing": "MobileApp-Billing", ////new addition// Business Rule ID
    "BR_Device": "MobileApp-Device", ////new addition// Business Rule ID
    "BR_Global": "MobileApp-Global", ////new addition// Business Rule ID
    "BR_MVTrans": "MobileApp-MVTrans", ////new addition// Business Rule ID
    "BR_WirelessSales": "MobileApp-WirelessSales", ////new addition// Business Rule ID
    "AG_Spanish_Billing": "10004856",
    "AG_Spanish_MVTrans": "10004858",
    "AG_Spanish_Device": "10004860",
    "AG_Spanish_Global": "10004857",
    "AG_Care-Escalations": "10004712",
    "AG_Sales-Escalations": "10004713",
    "AG_Care_Escalations_Spanish": "10004878",
    "AG_BGCO-General": "10004875",
    "AG_English_Prepaid": "10004876",
    "AG_Spanish_Prepaid": "10004877",
    "AG_Prepaid-Escalations": "10004892",
    "AG_HBA-Care": "10004898",
    "AG_HBA-Spanish": "10004899",
    "AG_HBA-Tech": "10004900",
    "TC_SERVER_NAME": "api-verizon-dev.touchcommerce.com",
    "TC_API_USERNAME": "VWMobApp",
    "TC_API_PASSWORD": "x95VIFsC",
    "TC_AGENT_URI": "/engagementAPI/v1/customer/agentAvailability?output=JSON",
    "VZW_PROXY_SERVER_NAME": "server.proxy.vzwcorp.com",
    "VZW_PROXY_PORT_NUMBER": "9290",
    "TC_CUTOMER_TYPING_URI": "/engagementAPI/v1/customer/customerIsTyping",
    "HTTPCLIENT_POOL_SIZE": "400",
    "TC_ENGAGEMENT_PRIORITY": "600",
    "TC_ENGAGEMENT_QUEUE_THRESHOLD": "1.5",
    "TC_CHAT_HIST_URL": "https://ech.vzwcorp.com/echreports/transcripts/getChatPage?realTimeID=",
    "Mobile_CareNoNPS_URL": "https://app.keysurvey.com/f/1011097/56e5/?LQID=1&",
    "Mobile_CareNPS_URL": "https://app.keysurvey.com/f/1011103/171e/?LQID=1&",
    "Mobile_SalesNoNPS_URL": "https://app.keysurvey.com/f/989819/10d2/?LQID=1&",
    "Mobile_SalesNPS_URL": "https://app.keysurvey.com/f/989818/8bb1/?LQID=1&",
    "LP_API_VERSION": "1",
    "LP_SERVER_NAME": "https://api.liveperson.net/",
    "LP_BASE_URI": "api/account/11146012?v=1",
    "LP_SKILL_NAME": "verizon-mobilefirst-tmp",
    "LP_APP_KEY": "f0dea91cd8974dcfbdb10cb4b29ac8b3",
    "TC_ENGAGEMENT_SALES_PRIORITY": "1",
    "TC_ENGAGEMENT_SALES_QUEUE_THRESHOLD": "0.9",
    "NLP_SERVER_URL": "http://app111dev.hss.vzwcorp.com:9094/nlp",
    "NLP_LOG_URI": "/getMobileFirstLog",
    "SHOW_CHAT_HISTORY_FLAG": "FALSE",
    "TC_AGENT_BUSY_FLAG": "FALSE",
    "TC_AGENT_RETRY_TIMES": "6",
    "TC_AGENT_RETRY_TIME_PERIOD": "5",
    "TC_CONVERSION_URI": "/engagementAPI/v1/dataCollection/conversion",
    "TC_ASSISTED_URI": "/engagementAPI/v1/customer/event/assisted",
    "Launch_Type": "MobileApp-DTSP"

};

//url config file
var config = null;
if (process.env.NODE_ENV === 'production') {
    logger.access.info('App production url configuration loded.');
    config = prodConfig;
} else {
    logger.access.info('App development url configuration loded.');
    config = devConfig;
}

module.exports = config;
