var express = require('express');
var https = require('https');
var querystring = require('querystring');
//var logger = require('../../../config/logger');
var router = express.Router();
//var udmConnection = require('../udmConnection/udmConnection.model');

// api route
router.route('/mfchat/rest/udmConnection')
    .post(function(req, res) {
      //logger.access.info(req.body);
      console.log("/mfchat/rest/udmConnection", req.body);
          if (req.body.RequestParams.isConnected) {
            if(req.session.isConnected && req.session.isConnected === 200){
              console.log(req.session.isConnected);
              console.log("Now the connection is existing between UDM and Node.js.");
              //logger.access.info({"isConnected": true, "message": "Now the connection is existing between UDM and Node.js."});
              return res.send({"isConnected": true, "message": "Now the connection is existing between UDM and Node.js."});
            }else if(req.session.isConnected && req.session.isConnected !== 200){
              console.log("Now the connection is not existing between UDM and Node.js.");
            //  logger.access.info({"isConnected": false, "message": "Now the connection is not existing between UDM and Node.js."});
              return res.send({"isConnected": false, "message": "Now the connection is not existing between UDM and Node.js."});
            }
           if(!req.session.isConnected){
             console.log("No Response from the agent yet.");
            // logger.access.info({"isConnected": true, "message": "No Response from the agent yet."});
            return res.send({"isConnected": true, "message": "No Response from the agent yet."});
           }
          }else{
            //logger.access.info({"status": "error", "message": "Missing connection flag, Please send it."});
             return res.send({"status": "error", "message": "Missing connection flag, Please send it."});
           }
    });

module.exports = router;
