/* eslint-disable */
'use strict';

describe('Directive: Chart', function() {

	var compile, scope, directiveEle, isoScope;

     //load all modules, including the html template, needed to support the test
    beforeEach(angular.mock.module('advisor'));

    
    beforeEach(function() {

 		angular.mock.inject(function($rootScope, $compile, $httpBackend) {
            scope = $rootScope.$new();
  			compile = $compile;
  			scope.aumChartSeriesConfig = {
                chart: {
                    type: 'area',
                    width: 382,
                    height: 220
                },
                title: {
                    text: ''
                },
                subtitle: {
                    text: ''
                },
                xAxis: {
                    categories: ["Sep'15","Oct'15","Nov'15","Dec'15","Jan'16","Feb'16"],
                    tickmarkPlacement: 'on',
                    title: {
                        enabled: false
                    },
                    labels: {
                        rotation: 0,
                        y: 25,
                        align: 'center'
                    },
                    plotLines: [{
                        color: '#C0D0E0',
                        width: 1,
                        // value: Date.UTC(profileDetailsDate.getFullYear(),profileDetailsDate.getMonth(),profileDetailsDate.getDate()),
                        value: 3,
                        zIndex: 999
                    }]
                },
                yAxis: [{
                    title: {
                        text: 'Cr',
                        align: 'high',
                        rotation: 0
                    },
                    labels: {
                        formatter: function () {
                            return this.value / 1000;
                        },
                        align: 'center'
                    }
                },
                {
                    title: {
                        text: 'Lacs',
                        align: 'high',
                        rotation: 0
                    },
                    opposite: true
                }
                ],
                tooltip: {
                    shared: true,
                    valueSuffix: ' millions'
                },
                plotOptions: {
                    area: { 
                        stacking: 'normal',
                        lineWidth: 1,
                        fillColor: "#ECF7FD",
                        marker: {
                            symbol: 'circle' ,
                            lineWidth: 0.5
                        }
                    }
                },
                series: [{
                    showInLegend: false,
                    name: 'AUM',
                    data: [502, 635, 809, 947, 1402, 3634],
                    color: '#5b9cd5'
                }, {
                    showInLegend: false,
                    name: 'Gross Sales',
                    data: [106, 107, 111, 133, 221, 767],
                    color: "#F59B00"
                }, {
                    showInLegend: false,
                    name: 'Redemptions',
                    data: [163, 203, 276, 408, 547, 729],
                    color: '#5fc0eb'
                }, {
                    showInLegend: false,
                    name: 'Net Sales',
                    data: [18, 31, 54, 156, 339, 818],
                    color: "#4F9D2D"
                }]
            };
        	//assign the template to the expected url called by the directive and put it in the cache
        });

        var element = angular.element('<ftic-chart chart-options="aumChartSeriesConfig"></ftic-chart>');
        directiveEle = compile(element)(scope);
        isoScope = directiveEle.isolateScope();
        scope.$digest();

    });

    it('should create seperate isolated scope', function() {
        expect(directiveEle.isolateScope()).toBeDefined();
    });

    it('should be defined',function(){
		expect(directiveEle).toBeDefined();
	})


});