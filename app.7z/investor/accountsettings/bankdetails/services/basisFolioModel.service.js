/**
 * @ngdoc service
 * @name Advisor Dashboard Details Model
 * @requires Restangular
 * @requires $q
 * @requires fticLoggerMessage
 * @requires loggerConstants
 * @description
 *
 * - Handles getting the advisor details, user widgets, and user details
 *
 */
'use strict';

var basisFolioModel= function(Restangular, $q, fticLoggerMessage, loggerConstants, authenticationService) {
    
    var _invBankDetails = null;
	var basisFolioModel = {
        fetchbasisfoliodetails : function (params) {
            params.guId = authenticationService.getUser().guId;
            var deferred = $q.defer();
            Restangular.one('/accountSettings/basisFolioDetails').get(params).then(function (basisFolioDetails) {
                deferred.resolve(basisFolioDetails);
            }, function (resp) {
                deferred.reject(resp);
                console.log('error');
            });
            return deferred.promise;
        },
        setbasisfoliodetails : function (invBankDetails) {            
            _invBankDetails = invBankDetails;
        },
        getbasisfoliodetails : function () {
            return _invBankDetails;
        }
    };
    return basisFolioModel;
};

basisFolioModel.$inject = ['Restangular', '$q', 'fticLoggerMessage', 'loggerConstants', 'authenticationService'];
module.exports = basisFolioModel;
