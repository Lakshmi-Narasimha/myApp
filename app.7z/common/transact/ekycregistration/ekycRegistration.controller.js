/**
 * @ngdoc property
 * @name ekycRegistrationCtrl Controller
 * @requires $scope
 * @description
 *
 * - 
 *
 **/


 'use strict';
// Controller naming conventions should start with an uppercase letter
function ekycRegistrationCtrl($scope, transactModel, transactEventConstants,$state,configUrlModel,appConfig,$window, TransactConstant) {   
            var configURL = configUrlModel.getEnvUrl('MARKETING_URL');
            var pdfUrl=appConfig[configURL] + TransactConstant.common.PHYSICAL_KYC_PDF_URL; 
	console.log("ekycRegistration controller");	
	$scope.closeFlow = false;
    $scope.openFlow = true;
    $scope.resultObj;
    var instantKycVals = [];

	$scope.folioId =  transactModel.getInvestorDetails().folioId;
    $scope.inputObj = transactModel.getInvestorDetails().holders;
    // if ($scope.inputObj) {
    //     angular.forEach($scope.inputObj, function(obj, key){
    //        obj.type = (key == 1?"Secondholder":"Thirdholder" && key == 0?"Firsthodler":"Thirdholder");
    //     });
    // }

    $scope.folioIdheader = {
        heading : 'FolioId : '+$scope.folioId
    };

    $scope.physicalKycValidation = function(){
        $scope.phyResult = false;
        angular.forEach($scope.resultObj, function(value, key){
            if ($scope.resultObj[key].aadhar == "" || null || undefined) {
                $scope.phyResult = true;
            }
        });
        return $scope.phyResult;
    }

    $scope.continue = function(){
        if ($scope.ekycReg.$valid) {
            $scope.$broadcast(transactEventConstants.transact.INSTANT_KYC);
            $scope.resultObj = $scope.ekycReg.kycVal;
            if ($scope.physicalKycValidation()) {
                //transactModel.setInstantKyc = [];
                $window.open(pdfUrl,"_blank");
                $scope.closeFlow = true;
                $scope.openFlow = false;
            }
            else{
                instantKycVals = $scope.ekycReg.kycVal;
                 angular.forEach(instantKycVals, function(obj, key){
                    obj.kycStatus = "KYC - Not Registered";
                }); 
                transactModel.setInstantKyc(instantKycVals);
                console.log("Came back after setting");
                $state.go("transact.ekyc");
            }                    
        }
    }
    $scope.cancelClick = function(){
        if (transactModel.getTransactType() == "FUNDSIP" || transactModel.getTransactType() == "SIP") {
            $state.go('transact.base.sip', {key:"Investor"});
        }
        else if (transactModel.getTransactType() == "BUYFUND" || transactModel.getTransactType() == "BUY") {
            $state.go('transact.base.buy', {key:"Investor"});
        }
        
    }
}

ekycRegistrationCtrl.$inject = ['$scope','transactModel','transactEventConstants','$state','configUrlModel','appConfig','$window', 'TransactConstant'];
module.exports = ekycRegistrationCtrl;