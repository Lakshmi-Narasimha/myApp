var _response;
var _response1;
define(
    ['text!appmodules/ncst/app/templates/ncstClientInfo.html',
        'appmodules/ncst/app/js/lib/validate-4.2', 'config',
        'appmodules/ncst/app/js/utils', 'appcommon/globalcontext', 'appmodules/ncst/app/js/models/model-address-entry', 'appmodules/ncst/app/js/models/model-client', 'appmodules/ncst/app/data/country-list', 'appmodules/ncst/app/js/models/model-new-client', 'appcommon/commonutility', 'appcommon/analytics', 'services/dataservice', 'appcommon/constants', 'components/js/views/RadioButtonView', 'appcommon/abstractview'
    ],
    function (Template, Validator, Config, Utils, GlobalContext, AddressModel, ClientModel, DropdownOptions, NewClientModel, CommonUtils, Analytics, Dataservice, Constants, RadioButtonView, AbstractView) {
    	var API_COMMON_DATA_BODY = Utils
            .getConfigProperty('API_COMMON_DATA_BODY'),
            BASE_URL = Config.odataServiceName,
            ClientInfoModel = ClientModel.get('clientInfo'),
            ClientDetailsModel = ClientModel.get('details'),
            _self = null;
    	var _serviceCounter = 0,
            prevAdvsrNum = null,
            noClientsAssociatedErrMsg = "There are no clients associated to this advisor number.",
            _paEligibleErrorMsg = "A Primary Advisor must be in a selling role and cannot be an AFA. Please enter an eligible ID.",
            invalidAdvsrIdMsg = "We are unable to determine if the ID entered is invalid or system is unavailable.  Please check the number entered and try again.";
    	var serviceErrorMsgs = {
    		'7090': 'Client already exists in our system.  If name and SSN/TIN are accurate, contact the Corporate Office.',
    		'7092': 'Client already exists in our system.  If name and SSN/TIN are accurate, contact the Corporate Office.',
    		'7102': 'Client already exists in our system.  If name and SSN/TIN are accurate, contact the Corporate Office.',
    		'7189': 'Client already exists in our system.  If name and SSN/TIN are accurate, contact the Corporate Office.',
    		'7057': 'Invalid SSN/TIN.',
    		'7115': 'Invalid organization name.',
    		'1014': 'Invalid organization name.'
    	}
    	var clientInfoView = AbstractView.extend({
    		el: '#ncst-app',
    		operationalityViewName: 'operationalityViewName',
    		clientEntityViewName:'clientEntityViewName',
    		statsTemplate: _.template(Template),
    		initialize: function () {
    			_self = this;
    			AbstractView.prototype.initialize.apply(this, arguments);
    			if (Utils.getView('clientInfo')) {
    				Utils.getView('clientInfo').clearView();
    			};
    			this.$primaryAdvsr;
    			this.$servcAdvsr;
    			this.firstLoad = true;
    			this.$main = this.$('#client-info');
    			this.operatingEntity = "#operating-entity";
    			this.ciCitizenshipCountry = "ci-citizenship-country";
    			this.ciSecondCitizenshipCountry = "ci-second-citizenship-country";

    			//events to track advisorNumber change
    			$(document).off("change keyup paste copy cut", "#i-advisor-number").on("change keyup paste copy cut", "#i-advisor-number", function (evt) {
    				var _keyCode = evt.keyCode || evt.which
    				if (_keyCode != 13) {
    					_self.hideErrorForAdvisorNumber();
    					_self.resetAssocClientSelection();
    				}

    			});
    			$(document).off("change keyup paste copy cut", "#s-advisor-number").on("change keyup paste copy cut", "#s-advisor-number", function (evt) {
    				//_self.handleServcAdvsrChange();
    				var _keyCode = evt.keyCode || evt.which
    				if (_keyCode != 13) {
    					_self.hideErrorForAdvisorNumber();
    					_self.resetAssocClientSelection();
    					$('#i-advisor-number').val("");
    				}
    			});
    		},
    		events: {
    			'click .assoc': 'assocClientoptionChangehandler',
    			'change input[type="radio"]': 'toggleRadioClassActive',
    			'click #step1-next-button,#m-step1-next-button': 'navigateToStep2',
    			'click [name=clientType]': 'changeSteps',
    			'change input[name="clientType"]': 'handleClieTypeChange',
    			'keypress #ci-ssn-1': 'ssn1Keypress',
    			'keypress #ci-ssn-2': 'ssn2Keypress',
    			'keypress #ci-ssn-3': 'ssn3Keypress',
    			'keyup #ci-ssn-1,#ci-ssn-2,#ci-ssn-3,#ci-ein-1,#ci-ein-2': 'ssnNextValidate',
    			'keypress #ci-ein-1,#ci-ein-2': 'ein1Keypress',
    			'change input[name="citizenShip"]': 'handleCitizenshipChange',
    			'change select#ci-entity-role': 'handleNonProfitGovtOption',
    			'click .cancel-text': 'handlerForCancel',
    			'change input[name="clientRole"]': 'handleClientRoleChange',
    			"click  .container-fluid": "hideIOSKeyboard",
    			"click .sad-text.sad-step1": "handleSAD",
    			'keyup #cd-assoc-name': 'hideNoRecords',
    			'focus #cd-assoc-name': 'showSearchOption',
    			//'blur #cd-assoc-name-search':'hideSearchOption',
    			'click .search-option-link': 'switchSerachOption',
    			'click #client-id-search-button': "doPreCheckForClIdSearch",
    			'click #cd-assoc-name-clear-search': 'clearClientSearch',
    			'click #cd-assoc-id-clear-search': 'clearClientIdSearch',
    			'click #cd-assoc-name-clear': 'clearAssociatedClient',
    			'change select#cd-assoc-reltn': 'assocReltnSelect',
    			'change #pt-select-industry': 'handleIndustryOptions',
    			'change #ci-entity-role': 'captureClientEntityRadio',
    		},
    		hideIOSKeyboard: function (e) {
    			CommonUtils.hideIOSKeyboard(e);
    		},
    		handleSAD: function () {
    			var _advsrNum = $('#i-advisor-number').val(),
                    _clTyp = $('input[name=clientType]:checked').val(),
                    _requrdFieldsFilled = false;
    			_self.hideServiceErrors();
    			_self.hideErrorForAdvisorNumber();
    			Analytics.analytics.recordSharedSuiteAction('ncstClientSetup:saveAsDraft:clicked');
    			if (_clTyp == "P") {
    				var _firstNm = $('#ci-first-name').val().trim(),
                        _lasttNm = $('#ci-last-name').val().trim(),
                        _ssn1 = $('#ci-ssn-1').val().trim(),
                        _ssn2 = $('#ci-ssn-2').val().trim(),
                        _ssn3 = $('#ci-ssn-3').val().trim();
    				if ($('input[name="citizenShip"]:checked').val() == 'Non-Resident Alien') {
    					if (_firstNm != "" && _lasttNm != "" && ((_ssn1.length == 3 && _ssn2.length == 2 && _ssn3.length == 4) || (_ssn1.length == 0 && _ssn2.length == 0 && _ssn3.length == 0)) && _advsrNum.length > 0) {
    						_requrdFieldsFilled = true;
    					}
    				} else {
    					if (_firstNm != "" && _lasttNm != "" && _ssn1.length == 3 && _ssn2.length == 2 && _ssn3.length == 4 && _advsrNum.length > 0) {
    						_requrdFieldsFilled = true;
    					}
    				}

    			} else {
    				var _orgNm = $('#ci-entity-name').val().trim(),
                        _ssn1 = $('#ci-ein-1').val().trim(),
                        _ssn2 = $('#ci-ein-2').val().trim();
    				if (_orgNm != "" && _ssn1.length == 2 && _ssn2.length == 7 && _advsrNum.length > 0) {
    					_requrdFieldsFilled = true;
    				}
    			}


    			if (_requrdFieldsFilled) {
    				Utils.lockForm();
    				var _paddedAdvNum = _self.zeropad(_advsrNum, 9),
                        _paddedServcAdvNum = _self.zeropad(_self.$servcAdvsr.val(), 9),
                        _prefillPA = false;
    				if (!ClientModel.get('isUserAAC') && (ClientModel.get("servicingAdvisorNumber") != _paddedServcAdvNum || ClientModel.get("servicingAdvisorNumber") != ClientModel.get("prepopulatedSA"))) {
    					_prefillPA = true;
    				}
    				_self.doSAValidation({
    					"servcAdvsrId": _paddedServcAdvNum,
    					"successCallback": function () {
    						_self.doAdvisorIdValidation({
    							"prefillPA": _prefillPA,
    							"servcAdvsrId": _paddedServcAdvNum,
    							"advisorId": _paddedAdvNum,
    							"successCallback": saveDraft,
    							"errorCallback": showErrors
    						});
    					},
    					"errorCallback": showSAError
    				});

    				function showErrors(xhr, errorCode) {
    					Utils.unlockForm();
    					if (xhr.status == 200) {
    						window.scrollTo(0, 100);
    						_self.showErrorForAdvisorNumber(_paEligibleErrorMsg);
    					} else {
    						if (xhr.status == "401") {
    							showAdvrsNumError(401);
    						} else if (errorCode == "500500") {
    							showAdvrsNumError("500500");
    						} else if (errorCode) {
    							Utils.setServerErrValidations("1", [errorCode]);
    						} else {
    							Utils.showSystemUnavailableMsg("1", "info", xhr.status);
    						}
    					}
    					Utils.logError(xhr);
    				}
    			} else {
    				var _errormsg = '<div class="sections no-margin-bottom"><div class="row"><div class="bootstrap-dialog-message">Before a draft can be saved, the following fields must be completed:</div>';
    				_errormsg += '<ul class="have-list-style"><li>Advisor number</li>'
    				if (_clTyp == "P") {
    					_errormsg += "<li>First and last name</li>";
    					_errormsg += '<li>SSN/TIN</li>';
    				} else {
    					_errormsg += "<li>Entity name</li>";
    					_errormsg += '<li>EIN</li>';
    				}

    				_errormsg += '</ul></div><div class="clearfix"></div></div>'

    				BootstrapDialog.show({
    					cssClass: 'ncst-save-as-draft',
    					title: 'Save as draft',
    					message: _errormsg,
    					buttons: [{
    						label: 'Cancel and close New Client Setup<i class="right-arrow-for-btn"></i>',
    						cssClass: "btn btn-default btn-default-transparent pt-btn-yes",
    						id: "ncst-cancel-btn-warning",
    						action: function (dialog) {
    							dialog.close();
    						}
    					}, {
    						label: 'Continue editing draft',
    						cssClass: "btn btn-primary ncst-draft-launch pt-btn-yes",
    						id: "ncst-draft-warning-close-btn",
    						action: function (dialog) {
    							dialog.close();
    						}
    					}]
    				});
    			}

    			function saveDraft() {
    				hideAdvsrNumError();
    				_self.model.setModel();
    				Utils.lockForm();
    				ClientModel.createDraft().done(function (response) {
    					Utils.unlockForm();
    					ClientModel.showDraftSaveSuccesMessage(response);
    				}).fail(function (error) {
    					Utils.unlockForm();
    					Utils.showDraftSaveErrorMessage();
    				});

    			}

    			function showAdvrsNumError(errorMsgCode) {
    				Utils.unlockForm();
    				var _$advsrNumCtnr = $('div[data-for=i-advisor-number]');
    				var _errorMsgObj = {
    					"401": "User doesn't have explicit relationship with the advisor number entered.",
    					"15657": "Invalid relationship or advisor ID.",
    					"500500": invalidAdvsrIdMsg
    				};
    				_$advsrNumCtnr.addClass('error');
    				_$advsrNumCtnr.find('label.error').removeClass("hidden").text(_errorMsgObj[errorMsgCode]);
    				_$advsrNumCtnr[0].scrollIntoView(true);
    			}
    		},
    		render: function (serverDown) {
    			$(document).off('click', '#ncst-cancel-btn-warning').on('click', '#ncst-cancel-btn-warning', function () {
    				$('body').removeAttr("style");
    				//$('#draft-save-warning-template').modal("hide");
    				var _context = GlobalContext.getInstance().getGlobalContext().Context;
    				//if standalone mode close the window
    				if (_context.IsStandalone == true) {
    					if (Utils.iOSversion() > 7 || window.chrome) {
    						var _cancelMsg = '<div class="container" align="center"><div  class="row cancld-txn-msg">This transaction has been cancelled. You may now close the window.</div>';
    						var _cntnr = $('#ncst-user-home-view');
    						_cntnr.html(_cancelMsg);
    					} else {
    						window.open('', '_self');
    						window.close();
    					}
    				} else {
    					location.hash = "contactprofile/";
    				}

    			});
    			$(document).off('click', '#ncst-draft-warning-close-btn').on('click', '#ncst-draft-warning-close-btn', function () {
    				$('body').removeAttr("style");
    				$('#draft-save-warning-template').modal("hide");
    			});
    			prevAdvsrNum = null;
    			var _data = {};
    			if (!serverDown) {
    				_data = this.model.toJSON();
    				_data.advisorNumber = ClientModel.get('advisorNumber');
    				_data.servicingAdvisorNumber = ClientModel.get('servicingAdvisorNumber');
    				_data.fromBackbutton = NewClientModel.get('fromBackbutton');
    				_data.client = ClientModel;
    				_data.isMobile = Utils.isMobile();
    				_data.serverDown = serverDown;
    				this.nxtStpBtnClicked = false;
    			} else {
    				_data.serverDown = serverDown;
    			}
    			Utils.unlockForm();
    			this.$main.html(this.statsTemplate(_data));
    			this.$primaryAdvsr = $("#i-advisor-number");
    			this.$servcAdvsr = $("#s-advisor-number");
    		}, 		    		
    		clearView: function () {
    			this.undelegateEvents(); // Unbind all local event
    			// bindings
    			this.model.unbind('change', this.render, this); // Unbind
    			// reference
    			// to
    			// the
    			// model
    		},
    		changeSteps: function () {
    			var cT = $('[name=clientType]:checked').val();
    			$.each($('.ncst-step').splice(4, 4), function (i,
                    obj) {
    				if (cT == 'O' && !i) {
    					$('.ncst-step').addClass(
                            'ncst-step-entity-rtmargin');
    					$(obj).hide();
    				} else if (cT == 'P' && !i) {
    					$('.ncst-step').removeClass(
                            'ncst-step-entity-rtmargin');
    					$(obj).show();
    				} else {
    					var stepNo = cT == 'P' ? 5 + i : 4 + i;
    					$(obj).find('.ncst-step-no').text(stepNo);
    				}
    			});
    			//fix for entity new client with same address
    			if (cT == "O") {
    				$('.ncst-steps-container').addClass(
                        'entity-role');
    			} else {
    				$('.ncst-steps-container').removeClass(
                        'entity-role');
    			}
    		},
    		afterRender: function (status, serverDown) {
    			if (serverDown) {
    				/*Add disabled class to all nav links to disable the click on server downtime.*/
    				$('.step-nav-links').addClass('click-disabled');
    				Utils.showSystemUnavailableMsg("0", "serverdown", 3000);
    				return;
    			} else {
    				$('.step-nav-links').removeClass('click-disabled');
    			}
    			//to restrict the user from entering any non digit character for client id search
    			$('#cd-assoc-id-search').off('keypress').on('keypress', function (event) {
    				event.which = event.which || event.keyCode;
    				if (event.which == 13) {
    					$('#client-id-search-button').trigger('click');
    					return;
    				}
    				var _regxNumOnly = /^\d*$/;
    				var _str = String.fromCharCode(event.keyCode);
    				if (!_regxNumOnly.test(_str)) {
    					event.stopPropagation();
    					if (event.preventDefault)
    						event.preventDefault();
    					return false;
    				}

    			});
    			$('#cd-assoc-name-search').off('keypress').on('keypress', function (event) {
    				var _regx = new RegExp(/^[ a-zA-Z-\-\']*$/g);
    				var _str = String.fromCharCode(event.keyCode);
    				if (!_regx.test(_str)) {
    					event.stopPropagation();
    					if (event.preventDefault)
    						event.preventDefault();
    					return false;
    				}

    			});
    			var _errorCodes = ClientModel.get('serverErrorCodes');
    			Utils.setServerErrValidations("1", _errorCodes);
    			ClientModel.set('serverErrorCodes', _.without(_errorCodes, '15508', '15657', '15666'));

    			var cT = ClientInfoModel.get('clientType');
    			if (cT == 'O') {
    				$.each($('.ncst-step').splice(4, 4), function (
                        i, obj) {
    					if (cT == 'O' && !i) {
    						$('.ncst-step').addClass(
                                'ncst-step-entity-rtmargin');
    						$(obj).hide();
    					} else if (cT == 'P' && !i) {
    						$('.ncst-step').removeClass(
                                'ncst-step-entity-rtmargin');
    						$(obj).show();
    					} else {
    						var stepNo = cT == 'P' ? 5 + i : 4 + i;
    						$(obj).find('.ncst-step-no').text(
                                stepNo);
    					}
    				});
    			}
    			// bind events to input text to block the field
    			// length
    			// to avoid citizenship changes for the initial
    			// render
    			this.model.set('initialLoad', true);
    			$(document)
                    .off('keypress', 'input[type="text"]')
                    .on(
                        'keypress',
                        'input[type="text"]',
                        function (e) {
                        	var _el = e.currentTarget;
                        	var _$el = $(_el);

                        	var _maxLength = _$el
                                .attr('maxlength');
                        	// if the text is selected,
                        	// allow the user to enter
                        	if (_maxLength &&
                                _$el.val().length >= _maxLength &&
                                _el.selectionStart == _el.selectionEnd) {
                        		return false;

                        	}
                        });
    			var _iosVersion = Utils.iOSversion();
    			if (_iosVersion && _iosVersion < 8) {
    				$('.ncst-row-label-custom-height.icon-info')
                        .addClass('ios-7');
    			}
    			this.loadCountryList();
    			if (NewClientModel.get('fromBackbutton')) {
    				this.setSavedValues(ClientModel.get('advisorNumber'));
    			} else {
    				// this.loadObolist(ClientModel
    				// .get('advisorNumber'));
    				$('#' + this.ciCitizenshipCountry, '#' + this.ciSecondCitizenshipCountry).val('').trigger('change');
    				// send the manual invoke parameter as true to
    				// avoid the unwanted handling of address enntry
    				// model
    				this.handleCitizenshipChange({}, true);
    			}
    			// init info popover
    			//this.initInfoPopup();
    			$("#ncst-user-home-view").invokeInfoPopup();
    			this.initializetypeahead();
    			$('.custom-select').customizeSelect();
    			var clientType = ClientInfoModel.get('clientType');
    			if (ClientModel.get('newClientWithAddress')) {
    				this.selectClientType(clientType);
    			} else if (this.firstLoad) {
    				if (clientType == 'O') {
    					$('#person-or-ent .radio-group-conatiner').removeClass('active');
    					$('#ct-entity').parent().parent().addClass('active');
    					$('input[name="clientType"][value="' + clientType + '"]').prop('checked', true);
    					$('.entity-field').removeClass('hidden');
    					$('.person-field').addClass('hidden');
    				}
    				if (this.model['honorific'] != '') {
    					$('#ci-client-honorific').val(this.model.get('honorific')).trigger('change');
    				}
    				if (this.model['suffix'] != '') {
    					$('#ci-client-suffix').val(this.model.get('suffix')).trigger('change');
    				}
    				this.firstLoad = false;
    			}
    			//$('div[data-for="ci-citizenship-country"]').addClass('hidden');
    			if ($('input[name="citizenShip"]:checked').val() == 'Non-Resident Alien') {
    				// make ssn optional
    				$('#ssn-help-block').show();
    			} else {
    				$('#ssn-help-block').hide();
    			}
    			if (ClientModel.get('clientCreated') == 'failed') {
    				Validator.validateInputs('client-info-view', true);
    			}
    			this.model.set('initialLoad', true);
    			// reset the new client flags
    			ClientModel.set('newClient', false);
    			//fix for entity new client with same address
    			this.changeSteps();

				//do here
    			if (this.model.get('isThisOperatingEntity') != null && this.model.get('isThisOperatingEntity').length > 0) {
    				this.renderOperationalityRadios(this.model.get('isThisOperatingEntity'));
    			} else {
    				this.renderOperationalityRadios();
    			}
    		},

    		renderOperationalityRadios: function (operationalityValue) {
    			var operationalityView,
                    selectedList = [];
    			operationalityView = new RadioButtonView({
    				el: this.$('#operationality-radio-container'),
    				items: [{
    					description: 'Operational',
    					id: 'operational'
    				},
                        {
                        	description: 'Non-Operational',
                        	id: 'non-operational'
                        }
    				]
    			});
    			if (operationalityValue != null && operationalityValue.length > 0) {
    				if (operationalityValue.valueOf() == 'N') {
    					selectedList = {
    						description: 'Operational',
    						id: 'operational'
    					};
    				} else {
    					selectedList = {
    						description: 'Non-Operational',
    						id: 'non-operational'
    					};
    				}
    				operationalityView.selectedItem = selectedList;
    			}

    			this.addNestedView(this.operationalityViewName, operationalityView);
    			operationalityView.render();
    		},
    		updateAdvisorDetails: function (advisor) {
    			$('#i-advisor-number').val(advisor.id);
    		},
    		loadObolist: function (advisorId) {
    			Utils
                    .getJson(
                        'data/mockOBO.json', {},
                        function (resp) {
                        	var _obolists = "<li class='obo-title roboto-bold-700'>On behalf of</li>";
                        	$(resp.obolist)
                                .each(
                                    function (i,
                                        _datum) {
                                    	var _class = "";
                                    	if (advisorId == _datum.id) {
                                    		_class = "selected roboto-bold-700";
                                    	}
                                    	_obolists += '<li class="' +
                                            _class +
                                            '" data-id="' +
                                            _datum.id +
                                            '">' +
                                            _datum.firstName +
                                            ' ' +
                                            _datum.lastName +
                                            '</li>';
                                    });
                        	$('#advisor-list').html(
                                _obolists);
                        },
                        function () {

                        });
    		},
    		handleClieTypeChange: function (e) {
    			var _$el = $(e.target);
    			this.hideServiceErrors();
    			Utils.hideErrorMsg();
    			var _$asscoClntQn = $('#clientAssociation'),
                    _$asscoClientOption = $('#asscoc-client-chose-option');
    			// hide the error messages
    			$("#client-info-view label.error").addClass(
                    "hidden");
    			$("#client-info-view div").removeClass("error");
    			// clearing models of its values if user changes
    			// client type.
    			$("span.ncst-adjust-left").addClass("hidden");
    			ClientModel.erase('all');
    			$('.ncst-step:not(".step1")').removeClass('pending finished');
    			// add a class to the step container for entity role
    			if (_$el.val() == "O") {
    				$('.ncst-steps-container').addClass('entity-role');
    				_$asscoClntQn.addClass('hidden');
    				_$asscoClientOption.addClass('hidden');
    			} else {
    				$('.ncst-steps-container').removeClass('entity-role');
    				_$asscoClntQn.removeClass('hidden');
    				_$asscoClientOption.removeClass('hidden');
    				$('#revoc-trust-help-cntnr').addClass('hidden');
    				$('#cd-assoc-reltn-cntnr').removeClass('hidden');
    			}
    			_self.resetAssocClientSelection();
    			this.toggleEntityPerson(_$el.val());
    			// clear the primary and mailing address since
    			// client type changed
    			AddressModel.set('primaryAddress', {});
    			AddressModel.set('mailingAddress', {});
    		},
    		selectClientType: function (clientType) {
    			if (clientType == "O") {
    				var _$el = $('#ct-entity');
    				this.toggleEntityPerson("O");
    			} else {
    				var _$el = $('#ct-individual');
    				this.toggleEntityPerson("P");
    			}
    			$('#person-or-ent .radio-group-conatiner').removeClass('active');
    			_$el.prop('checked', true).parent().parent().addClass('active');
    		},
    		toggleEntityPerson: function (clientType) {

    			if (clientType != "O") {
    				$('.entity-field').addClass('hidden');
    				$('.person-field').removeClass('hidden');
    				// send the manual invoke parameter as true to
    				// avoid the unwanted handling of address enntry
    				// model
    				this.handleCitizenshipChange({}, true);
    			} else {
    				$('.entity-field').removeClass('hidden');
    				$('.person-field').addClass('hidden');
    			}
    			// clearing all user entered text and combo values
    			$('#ncst-citizenship-container .radio-group-conatiner').removeClass('active')
    			$('#ncst-citizenship-container input[type="radio"]').prop('checked', false);
    			$(
                        '#client-info-view input[type=text]:not("#i-advisor-number,#s-advisor-number")')
                    .val('');
    			$(
                        '#client-info-view input[type=number]:not("#i-advisor-number,#s-advisor-number")')
                    .val('');
    			if (!NewClientModel.get('fromBackbutton')) {
    				$('#client-info-view select').val('').trigger(
                        'change');
    			}

    		},
    		getAdvisorClientList: function (url) {
    			_self = this;
    			var _data = $.extend(API_COMMON_DATA_BODY, {});
    			Utils.get(url, decodeURIComponent($.param(_data)), function (response) {
    				Utils.unlockForm();
    				var clientList = response.d.clientRefs.results;
    				if (clientList.length) {
    					$("#client-detls-error-msg-cntnr").addClass('hidden');
    					ClientDetailsModel.set('clientListData', true);
    					_self.model.set('clientNames', clientList);
    					$('.assoc-status').slideDown();
    				} else {
    					$('#clientAssociation').addClass('pt-error');
    					$('#pt-empty-client-list').removeClass('hidden');
    					ClientDetailsModel.set('clientListData', false);
    				}
    			},
                    function (xhr) {
                    	Utils.unlockForm();
                    	var _errorResp = undefined;
                    	if (xhr.responseJSON) {
                    		if (xhr.responseJSON.error) {
                    			_errorResp = xhr.responseJSON.error;
                    		}
                    	}
                    	if ((xhr.status == "404" && _errorResp && _errorResp.type == "Not Found") || xhr.status == "401" || xhr.status == "400") {
                    		var _errMsg = "";
                    		if (xhr.status == "404") {
                    			_errMsg = noClientsAssociatedErrMsg;
                    			Utils.setServerErrValidations("4", [404404]);
                    			$('.assoc-status').slideDown();
                    		} else if (xhr.status == "401") {
                    			_errMsg = "User doesn't have explicit relationship with the advisor number entered."
                    			Utils.setServerErrValidations("4", [401401]);
                    		}
                    		$('#clientAssociation').addClass("error").find('label.error').removeClass("hidden").text(_errMsg);
                    	} else {
                    		Utils.showSystemUnavailableMsg("4", "detls", xhr.status);
                    	}
                    	ClientDetailsModel.set('clientListData', false);
                    	Utils.logError(xhr);
                    }, {}, 0);
    		},
    		hideSearchOption: function () {
    			hideSearchOption();
    		},
    		resetFormFields: function () {
    			$('.assoc-status :input').each(function () {
    				switch (this.type) {
    					case 'text':
    						$(this).val('');
    						break;
    					case 'select-one':
    						$('#cd-assoc-reltn').val('');
    						$('#cd-assoc-reltn').next('.holder').text($('#cd-assoc-reltn')[0].options[0].text);
    						$('#cd-assoc-reltn-info').addClass('hide');
    						break;
    				}
    			});
    		},
    		assocClientoptionChangehandler: function (obj) {
    			var _$clickedButton = $(obj.currentTarget),
                    _prefillPA = false;
    			if (_$clickedButton.hasClass('active')) {
    				return false;
    			} else {
    				_self.hideErrorForAdvisorNumber();
    				var _users = {};
    				var _userLabels = [];
    				var _btnTxt = _$clickedButton.text();
    				_self = this;
    				$('.assoc').removeClass('active');
    				if (_btnTxt == 'Yes') {
    					_self.model.set('assClOption', true);
    					if (!_self.model.get('clientNames').length) {
    						var _paddedServcAdvNum = _self.zeropad(_self.$servcAdvsr.val(), 9),
                                _paddedAdvNum = _self.zeropad(_self.$primaryAdvsr.val(), 9);
    						var _url = BASE_URL + "ClientList(id='" + _paddedAdvNum + "',ctx='DMU.DIST',type='CAPLIST')?$expand=clientRefs";
    						Utils.lockForm();
    						if (!ClientModel.get('isUserAAC') && (ClientModel.get("servicingAdvisorNumber") != _paddedServcAdvNum || ClientModel.get("servicingAdvisorNumber") != ClientModel.get("prepopulatedSA"))) {
    							_prefillPA = true;
    						}
    						_self.doSAValidation({
    							"servcAdvsrId": _paddedServcAdvNum,
    							"successCallback": function () {
    								_self.doAdvisorIdValidation({
    									"prefillPA": _prefillPA,
    									"advisorId": _paddedAdvNum,
    									"servcAdvsrId": _paddedServcAdvNum,
    									"successCallback": function () {
    										_self.getAdvisorClientList(_url);
    									},
    									"errorCallback": function (xhr, errCd) {
    										showErrors(xhr, errCd, _prefillPA)
    									}
    								});
    							},
    							"errorCallback": showSAError
    						})



    					} else {
    						$('.assoc-status').slideDown();
    					}
    				} else {
    					_self.hideErrorForAdvisorNumber();
    					var _$parentCtnr = $('#clientAssociation');
    					_self.model.set('assClOption', false);
    					_self.model.clearClientAssociation();
    					$('#cd-assoc-name').data('value', '');
    					$("#client-detls-error-msg-cntnr").addClass('hidden');
    					$('#clientAssociation').removeClass('pt-error error');
    					_$parentCtnr.find('label.error').addClass('hidden');
    					_$parentCtnr.find('button').removeClass('no-recors-found not-authorized');
    					$('#pt-empty-client-list').addClass('hidden');
    					//if (!$("#client-detls-error-msg-cntnr :visible").length)
    					// ClientModel.set('clientListData', true);
    					_self.hideAssocError();
    					((_btnTxt == 'No') ? _self.resetFormFields() : '');
    					_self.hideSearchOption();
    				}
    				_$clickedButton.addClass('active');
    			}

    			function showErrors(xhr, errorCode, prefillPA) {
    				var _errMsg = "User doesn't have explicit relationship with the advisor number entered.";
    				Utils.unlockForm();
    				if (xhr.status == 200) {
    					window.scrollTo(0, 100);
    					_self.showErrorForAdvisorNumber(_paEligibleErrorMsg, prefillPA);
    				} else if (errorCode == "500500") {
    					_self.showErrorForAdvisorNumber(_paEligibleErrorMsg, errorCode);
    				} else if (typeof errorCode === "undefined" || xhr.status != 401) {
    					Utils.showSystemUnavailableMsg("1", "info", xhr.status);
    				} else {
    					$('#clientAssociation').addClass("error").find('label.error').removeClass("hidden").text(_errMsg);
    					//highlight advisorNumber field with error
    					_self.showErrorForAdvisorNumber(_errMsg, prefillPA);
    				}
    				Utils.logError(xhr);
    			}

    			function parsePAGroupCLientlist(grpClients) {
    				var _grpClients = [];
    				$.each(grpClients, function (i, client) {
    					var _grpClientList = client.grpClients.results;
    					$.each(_grpClientList, function (i, client) {
    						var _clientInfo = client;
    						var _grpClnt = {};
    						_grpClnt.clId8 = _clientInfo.clId.substr(_clientInfo.clId.length - 8);
    						_grpClnt.clId = _clientInfo.clId;
    						_grpClnt.clNm = _clientInfo.orgClient === null ? (_clientInfo.persClient.clLastNm + ", " + _clientInfo.persClient.clLastNm) : _clientInfo.orgClient.orgNm;
    						_grpClients.push(_grpClnt);
    					});

    				});
    				return _grpClients;
    			}
    		},
    		showErrorForAdvisorNumber: function (errMsg, SAError) {
    			//highlight advisorNumber field with error
    			window.scrollTo(0, 100);
    			if (SAError) {
    				$("div[data-for='s-advisor-number']").addClass("error");
    				$("#sa-error-message").removeClass("hidden").text(errMsg);
    			} else {
    				$("div[data-for='i-advisor-number']").addClass("error");
    				$("#advisor-number-error-message").removeClass("hidden").text(errMsg);
    			}

    		},
    		hideErrorForAdvisorNumber: function () {
    			//highlight advisorNumber field with error
    			Utils.hideSystemUnavailabelError();
    			$("div[data-for='i-advisor-number'],div[data-for='s-advisor-number']").removeClass("error");
    			$("#advisor-number-error-message,#sa-error-message").addClass("hidden").text("");
    		},
    		hideAssocError: function () {
    			$('.assoc-status').slideUp().children().removeClass('error');
    			$('.assoc-error').addClass("hidden");
    			var _$container = $('#associate-client-container');
    			_$container.removeClass("error customized-error").find('label.error:first').addClass("hidden");
    		},
    		resetAssocClientSelection: function (donotClearClientList) {
    			var _$parentCtnr = $('#clientAssociation');
    			//if (!donotClearClientList) {
    			_self.model.set('clientNames', []);
    			_self.model.set('groupClients', []);
    			//}
    			_self.model.set('clientListData', false);
    			_self.model.set('assClOption', false);
    			_self.model.clearClientAssociation();
    			$('.assoc').removeClass('active');
    			$('#cd-assoc-name').data('value', '');
    			$("#client-detls-error-msg-cntnr").addClass('hidden');
    			$('#clientAssociation').removeClass('pt-error error');
    			_$parentCtnr.find('label.error').addClass('hidden');
    			_$parentCtnr.find('button').removeClass('no-recors-found not-authorized');
    			$('#pt-empty-client-list').addClass('hidden');
    			$('.assoc-status').slideUp().children().removeClass('error');
    			$('.assoc-error').addClass("hidden");
    			_self.resetFormFields();
    			_self.hideSearchOption();
    			_self.hideAssocError();
    		},
    		toggleRadioClassActive: function (event) {
    			var _radio = $(event.target);
    			var _radioHolder = _radio.parents('div.radio-grp-holder');
    			_radioHolder.find('div.radio-group-conatiner').removeClass('active');
    			_radio.parents('div.radio-group-conatiner').addClass('active');
    		},
    		/*initInfoPopup : function() {
            	Utils.initInfoPopup();
            },*/
    		setSavedValues: function () {
    			var _model = this.model;
    			var _clientType = _model.get('clientType');
    			this.toggleEntityPerson(_clientType);
    			$('input[name="clientType"][value="' + _model.get('clientType') + '"]').prop('checked', true);
    			$('input[name="clientRole"][value="' + _model.get('clientRole') + '"]').prop('checked', true);
    			$('#ci-client-honorific').val(_model.get('honorific'));
    			$('#ci-first-name').val(_model.get('firstName'));
    			$('#ci-middle-name').val(_model.get('middleName'));
    			$('#ci-last-name').val(_model.get('lastName'));
    			$('#ci-client-suffix').val(_model.get('suffix'));
    			$('#ci-ssn-1').val(_model.get('ssn1'));
    			$('#ci-ssn-2').val(_model.get('ssn2'));
    			$('#ci-ssn-3').val(_model.get('ssn3'));
    			$('input[name="citizenShip"][value="' + _model.get('citizenship') + '"]').click();
    			$('#' + this.ciCitizenshipCountry).val(_model.get('citizenshipCountry')).trigger('change');
    			$('#' + this.ciSecondCitizenshipCountry).val(_model.get('secCitizenshipCountry')).trigger('change');
    			// send the manual invoke parameter as true to avoid
    			// the unwanted handling of address enntry model
    			this.handleCitizenshipChange({}, true);
    			// entity fields
    			$('#ci-entity-name').val(_model.get('entityName'));
    			$('#ci-entity-role').val(_model.get('entityRole')).trigger('change');
    			//$('#ci-entity-role').val(_model.get('entityRole')).trigger('change');
    			$('#ci-ein-1').val(_model.get('ein1'));
    			$('#ci-ein-2').val(_model.get('ein2'));
    			// change the client type active class
    			var _clTypeContnr = $('#person-or-ent');
    			_clTypeContnr.find('.radio-group-conatiner').removeClass('active');
    			_clTypeContnr.find('input[name="clientType"]:checked').parent().parent().addClass('active');
    			var _clRoleContainer = $("#acc-or-fid");
    			_clRoleContainer.find('.radio-group-conatiner').removeClass('active');
    			_clRoleContainer.find('input[name="clientRole"]:checked').parent().parent().addClass('active');
    			$('#cd-assoc-reltn').val(this.model.get('clientassocReltn'));
    			var _asocClId = _self.model.get('clientassocId');
    			if (_asocClId) {
    				$('#cd-assoc-name').data('value', _asocClId).val(_self.model.get('clientassocName'));
    			}
    			_self.initializetypeahead();

    		},
    		hideServiceErrors: function () {
    			Utils.hideSystemUnavailabelError();
    			$('.row.form-group.pt-warning').removeClass(
                    'pt-warning');
    			$('.row.form-group.pt-error').removeClass(
                    'pt-error');
    			$('.pt-ssn-error-bg,.pt-ein-error-bg').removeClass(
                    'pt-error');
    			$(
                        '#pt-ssn-service-err-msg,#pt-ein-service-err-msg,.pt-ein-top-name-std-msg,label.pt-warning,label.pt-error')
                    .addClass('hidden');
    		},
    		validateComponents: function () {
				var showErrFlag = false;
				for (var key in this.nestedViews) {
					if (key.indexOf("clientEntityViewName") > -1) {
						if (this.nestedViews[key].selectedItem == null) {
							nestedViewId = this.nestedViews[key].el.id;
							showErrFlag = true;
						} else {
							showErrFlag = false;
						}
					} else if (key.indexOf("operationalityViewName") > -1) {
						if (this.nestedViews[key].selectedItem == null) {
							nestedViewId = this.nestedViews[key].el.id;
							showErrFlag = true;
						} else {
							showErrFlag = false;
						}
					}

					if (showErrFlag) {
						$("div [data-for=" + nestedViewId + "]").addClass('error');
						$("div [data-for=" + nestedViewId + "] .ncst-adjust-left").removeClass('hidden');
						this.nestedViews[key].showError(true);
					}
				}
				return !(showErrFlag);
    		},
    		navigateToStep2: function () {
				var _context = GlobalContext.getInstance().getGlobalContext().Context;
				var _qryStrng = _context.QueryString ? _context.QueryString : '';
    			// remove service inline errors
    			this.navigateFromStep1('ncst/address-entry' + _qryStrng, 2, true);
    		},
    		navigateFromStep1: function (hashTag, clickedStep, isNextButtonCllick) {
    			var _$view = $('#client-info-view');
    			_$view.find('.entity-assoc-client,.inconsistent,.invalidAdvId,.not-authorized-step1,.pa-eligibiity-failed').removeClass('entity-assoc-client inconsistent invalidAdvId not-authorized-step1 pa-eligibiity-failed');
    			//_$view.find('.invalidAdvId').removeClass('invalidAdvId ');
    			//_$view.find('.not-authorized-step1').removeClass('not-authorized-step1 ');
    			//_$view.find('.pa-eligibiity-failed').removeClass('not-authorized-step1 ');

    			var _self = this,
                    _prefillPA = false,
                    otherIndustryOption = true, foreignDomiciledCheck = true;
    			this.hideServiceErrors();
    			_self.hideErrorForAdvisorNumber();
    			Utils.hideErrorMsg();
    			this.nextHash = hashTag ? hashTag : ('ncst/address-entry' + context.QueryString ? context.QueryString : '');
    			this.clickedStep = clickedStep ? clickedStep : 2;
    			var _paddedAdvNum = _self.zeropad($('#i-advisor-number').val(), 9),
                    _paddedServcAdvNum = _self.zeropad(_self.$servcAdvsr.val(), 9);
    			var _regulrValdtn = this.model.validate(true),
                    _custValdtn = (this.model.get("clientType") != "P" || this.doFirstnameLastnameLimitValdtn());
    			var selectedEntity = $('input[name="select-choice-entity-client-radiobuttons"]:checked').val();

    			if (this.model.get('frgnOrgCheck') == 'N' && selectedEntity == "Foreign entity") {
    				BootstrapDialog.show({
    					title: 'Important information',
    					message: "Foreign entities cannot be established within New Client Setup Tool. </br> For more information, go to <a target='_blank' href='https://www.askameriprise.com/app/answers/Adv_detail/a_id/10941'>New Business requirements for a foreign client </a>",
    					//closeByBackdrop: false,
    					cssClass: 'esig-mobile-unavailablity',
    					buttons: [{
    						label: 'OK',
    						cssClass: 'btn pt-btn-yes generic-button btn-primary',
    						action: function (dialog) {
    							dialog.close();
    						}
    					}]
    				});
    				foreignDomiciledCheck = false;
    			}

    			if (!$('#pt-industry-other').hasClass('hidden')) {
    				if ($('#pt-industry-other-input').val().length == 0) {
    					$('#industry-classification').addClass('error');
    					otherIndustryOption = false;
    				}
    			}
    			var validCompCheck = "";	
    			if ($('input[name="clientType"]:checked').val() == "P") {
    				validCompCheck = true;
    			} else {
    				validCompCheck = this.validateComponents();
    			}

    			if (_regulrValdtn && _custValdtn && otherIndustryOption && foreignDomiciledCheck && validCompCheck) {
    				Utils.lockForm();
    				if (!ClientModel.get('isUserAAC') && (ClientModel.get("servicingAdvisorNumber") != _paddedServcAdvNum || ClientModel.get("servicingAdvisorNumber") != ClientModel.get("prepopulatedSA"))) {
    					_prefillPA = true;
    			}
    				_self.doSAValidation({
    					"servcAdvsrId": _paddedServcAdvNum,
    					"successCallback": function () {
    						_self.doAdvisorIdValidation({
    							"prefillPA": _prefillPA,
    							"servcAdvsrId": _paddedServcAdvNum,
    							"advisorId": _paddedAdvNum,
    							"successCallback": doSecondaryServiceCalls,
    							"errorCallback": showAdvsrIdValdtnErrors
    					});
    				},
    					"errorCallback": showSAError
    			});
    		}

    			function doSecondaryServiceCalls() {
    				_self.nxtStpBtnClicked = true;
    				_self.model.setModel();
    				/* If valid inputs are given then save the advisor number to the base client model
					 * Requirement: Advisor number is editable and the edited number needs to be shown
					 * in the rest of the screens.
					 * */
    				try {
    					var _prevAdvsrNum = null;
    					if (isNextButtonCllick) {
    						_prevAdvsrNum = ClientModel.get('advisorNumber');
    					} else {
    						_prevAdvsrNum = prevAdvsrNum;
    				}
    					if (_prevAdvsrNum != _paddedAdvNum) {
    						//ClientModel.set('stepsCompleted', Utils.arraySplice(ClientModel.get('stepsCompleted'),'client-details'));
    						//$('.ncst-step.step4').removeClass('active pending finished');
    						//ClientModel.get('details').fetchClientList(_paddedAdvNum);
    				}
    					} catch (e) {

    			}
    				ClientModel.set('advisorNumber', _paddedAdvNum);

    				var clientType = $(
                            'input[name="clientType"]:checked')
                        .val();
    				if (clientType == "P") {
    					// escaping client existence call if citizenship is NRA and SSN is either null or all 0's
    					if (_self.model.get('citizenship') == 'Non-Resident Alien' &&
                            (_self.model.get('ssn1') == '' || _self.model.get('ssn1') +_self.model.get('ssn2') +_self.model.get('ssn3') == '000000000')) {
    						Utils.unlockForm();
    						_self.markActiveStep(_self.clickedStep);
    						location.hash = _self.nextHash;
    						window.scrollTo(0, 0);
    					} else {
    						_serviceCounter = 1;
    						// PERSON
    						// no need to call scrubClientname service
    						// so set as true
    						ClientInfoModel
                                .set('validEntityName', true);
    						_self
                                .callScrubClientExistenceService('Person');
    				}
    				} else {
    					_serviceCounter = 2;
    					// ENTITY
    					// Service to validate Organisation Name(ie
    					// Entity Name)
    					_self.callScrubClientNameService();
    					/* Service to check if the client exists */
    					_self
                            .callScrubClientExistenceService('Organisation');
    			}
    		}
    			this.sendEventsToAnalytics();
    		},
    		doSAValidation: function (options) {
    			var _servcAdvsrId = options.servcAdvsrId;
    			if (ClientModel.get('isUserAAC')) {
    				options.successCallback();
    				return;
    			}
    			Dataservice.getDistributorInfo(_servcAdvsrId, [401, 404, 500]).then(function (response) {
    				var _servcAdvsrDistInfo = response[0];
    				if (_servcAdvsrDistInfo != undefined && _servcAdvsrDistInfo != null) {
    					var _sfxTxt = (_servcAdvsrDistInfo.prefName && _servcAdvsrDistInfo.prefName.sfxTxt.trim()) ? (" " + _servcAdvsrDistInfo.prefName.sfxTxt) : "",
                            _srvcAdvisorName = _servcAdvsrDistInfo.prefName ? (_servcAdvsrDistInfo.prefName.firstNm + " " + _servcAdvsrDistInfo.prefName.lastNm + _sfxTxt) : "";
    					ClientModel.set("servicingAdvisorName", _srvcAdvisorName);
    					if (_servcAdvsrDistInfo.position.pstnCd && _servcAdvsrDistInfo.position.pstnCd == "76") {
    						ClientModel.set('isAFAUser', true);
    					} else {
    						ClientModel.set('isAFAUser', false);
    					}
    					if (_servcAdvsrDistInfo.sellInd == "Yes") {
    						ClientModel.set('servicingAdvisorNumber', _servcAdvsrId);
    						Dataservice.getDistributorAssistantRelationship(_servcAdvsrId).then(function (resp, status, xhr) {
    							if (resp && resp.d) {
    								options.successCallback();
    							} else {
    								options.errorCallback(xhr, {
    									'errorCd': "15657"
    								});
    							}
    						}).fail(function (error) {
    							options.errorCallback(error);
    						});
    					} else {
    						options.errorCallback(response, {
    							"sellInd": false
    						});
    					}
    				} else {
    					options.errorCallback(response);
    				}
    			}).fail(options.errorCallback);
    		},
    		doAdvisorIdValidation: function (options) {
    			var _advisorId = options.advisorId;
    			checkAdvisorEligibity(_advisorId);

    			function checkAdvisorEligibity(distId) {
    				var _aacPlfmCd = "04",
                        _plfmCd = null;
    				Dataservice.getDistributorInfo(distId, [401, 404, 500]).then(function (response) {
    					var _distributorInfo = response[0];
    					if (_distributorInfo !== undefined && _distributorInfo !== null) {
    						_plfmCd = _distributorInfo.plfmCd;
    						var _sfxTxt = (_distributorInfo.prefName && _distributorInfo.prefName.sfxTxt && _distributorInfo.prefName.sfxTxt.trim()) ? (" " + _distributorInfo.prefName.sfxTxt.trim()) : "",
                                _advisorName = _distributorInfo.prefName ? (_distributorInfo.prefName.firstNm + " " + _distributorInfo.prefName.lastNm + _sfxTxt) : "";
    						ClientModel.set("advisorNm", _advisorName);
    						if (_plfmCd != _aacPlfmCd) {
    							ClientModel.set('isAACUser', false);
    							checkPAEligibility(distId);
    						} else {
    							ClientModel.set('isAACUser', true);
    							checkAACEligibity(distId)
    						}
    					} else {
    						if (response && response.httpResponse && response.httpResponse.status == 500) {
    							options.errorCallback(response, 500500);
    						} else {
    							options.errorCallback(response);
    						}

    					}
    				}).fail(function (xhr) {
    					if (xhr && xhr.status == "500") {
    						options.errorCallback(xhr, 500500);
    					} else {
    						options.errorCallback(xhr);
    					}

    				});
    			}

    			function checkPAEligibility(primaryAdvsrId) {
    				Dataservice.getPrimaryAdvisorEligibility(primaryAdvsrId).then(function (resp, status, xhr) {
    					var _advsrEligbltyInfo = resp && resp.d ? resp.d : null;
    					if (_advsrEligbltyInfo !== null && _advsrEligbltyInfo.primaryAdvisorEligibility && _advsrEligbltyInfo.primaryAdvisorEligibility.isPrmAdvsEligInd === true) {
    						getDistributorCompSharingSets(primaryAdvsrId);
    					} else {
    						options.errorCallback(xhr);
    					}
    				}).fail(function (error) {
    					//handle error
    					var _uiErrorCd = undefined;
    					if (error.status == 401) {
    						_uiErrorCd = 401401;
    					}
    					options.errorCallback(error, _uiErrorCd);
    				});
    			}

    			function checkAACEligibity(advsrId) {
    				Dataservice.getDistributorPractice(advsrId).then(function (resp, status, xhr) {
    					if (resp && resp.d && resp.d.results && resp.d.results.length > 0) {
    						var _prscticeInfo = resp.d.results[0];
    						getpracticeMembers(_prscticeInfo.pracId);
    					} else {
    						//handle error  
    						options.errorCallback(xhr, 15657);
    					}

    				}).fail(function (error) {
    					//handle error 
    					var _uiErrorCd = undefined;
    					if (error.status == 401) {
    						_uiErrorCd = 401401;
    					}
    					options.errorCallback(error, _uiErrorCd);
    				});

    				function getpracticeMembers(pracId) {
    					Dataservice.getpracticeMembers(pracId).then(function (resp, status, xhr) {
    						if (resp && resp.d && resp.d.pracMbrs && resp.d.pracMbrs.results && resp.d.pracMbrs.results.length > 0) {
    							var _prscticeMmbrInfo = resp.d.pracMbrs.results[0];
    							var _dstrId = _self.zeropad(_prscticeMmbrInfo.dstrId, 9);
    							ClientModel.get("clientInfo").set("advisorNumber", _dstrId);
    							ClientModel.set("advisorNumber", _dstrId);
    							ClientModel.set("isAACUser", true);
    							getDistributorCompSharingSets(_advisorId, true);
    						} else {
    							//handle error  
    							options.errorCallback(xhr, 15657);
    						}

    					}).fail(function (error) {
    						var _uiErrorCd = undefined;
    						if (error.status == 401) {
    							_uiErrorCd = 401401;
    						}
    						options.errorCallback(error, _uiErrorCd);
    					});
    				}
    			}

    			function getDistributorCompSharingSets(advsrId, isAAC) {
    				Dataservice.getDistributorAssistantRelationship(advsrId).then(function (resp, status, xhr) {
    					if (resp && resp.d) {
    						//adsvr is authorized to create new client
    						if (!isAAC) {
    							ClientModel.get('clientInfo').set('advisorNumber', advsrId);
    							ClientModel.set('advisorNumber', advsrId);
    						}
    						options.successCallback();
    					} else {
    						//handle error  
    						options.errorCallback(xhr, 15657);
    					}
    				}).fail(function (error) {
    					var _uiErrorCd = undefined;
    					if (error.status == 401) {
    						_uiErrorCd = 401401;
    					}
    					options.errorCallback(error, _uiErrorCd);
    				});
    			}
    		},
    		sendEventsToAnalytics: function () {
    			if ('P' == ClientModel.get('clientInfo').get('clientType')) {
    				Analytics.analytics.recordSharedSuiteAction('ncstClientInfoClientType:individual');
    				Analytics.analytics.recordSharedSuiteAction('ncstClientInfoCitizenship:' + ClientModel.get('clientInfo').get('citizenshipType'));
    				if ('F' == ClientModel.get('clientInfo').get('clientRole')) {
    					Analytics.analytics.recordSharedSuiteAction('ncstClientInfoClientRole:fiduciary');
    				} else {
    					Analytics.analytics.recordSharedSuiteAction('ncstClientInfoClientRole:owner');
    				}
    			} else {
    				Analytics.analytics.recordSharedSuiteAction('ncstClientInfoClientType:entity');
    			}

    		},
    		callScrubClientNameService: function () {
    			// var _url = BASE_URL +
    			// 'scrubClientName?$format=json';
    			// var _url = 'data/scrubClientName.json';
    			var _url = BASE_URL +
                    'scrubClientName?$format=json';
    			var _data = {
    				"orgNm": ClientInfoModel.get('entityName')
    			};
    			this.clientNameValidationService(_data, _url);
    		},
    		clientNameValidationService: function (data, url) {
    			var _data = data;
    			var _url = url;
    			var _self = this;
    			$('#pt-ein-service-err-bg').removeClass(
                    'pt-warning');
    			$('.pt-ein-top-name-std-msg')
                    .addClass('hidden');
    			Utils
                    .post(
                        _url,
                        JSON.stringify(_data),
                        function (resp) {
                        	_response = resp.d;
                        	var _isSuccess = true;
                        	if (_response.scrbClNmStatCd == "0000") {
                        		_isSuccess = true;
                        	} else {
                        		if (_response.scrbClNmStatCd == "0001") {
                        			var _explCode = _response.scrbClNmRespExpl.results[0].explCd;
                        			switch (_explCode) {
                        				case '7272':
                        					// Standardized name
                        					// is greater than
                        					// 30 characters
                        				case '7274':
                        					// 7274- input name
                        					// >30, no
                        					// standardisation
                        					_isSuccess = false;
                        					break;
                        				case '7273':
                        					_isSuccess = true;
                        					break;
                        				default:
                        					_isSuccess = true;
                        					break;
                        			}

                        		}

                        		// scrub service failed save
                        		// the data userEntered data
                        		// as validated data

                        	}
                        	ClientModel.set('scrubEntityName',
                                null);
                        	if (_isSuccess) {
                        		ClientInfoModel.set(
                                    'validEntityName',
                                    true);
                        		_self
                                    .saveValidClientNameToModel(_response);
                        	} else {
                        		$('#ci-entity-name').val(
                                    _response.orgNm);
                        		showOrgNameWarning();
                        	}
                        	_self
                                .finalClientNameServiceSuccesHandler();

                        },
                        function (xhr) {
                        	var _isSystemFailure = true;
                        	//console.log(xhr);
                        	if (xhr.status == 400) {
                        		var _resp = xhr.responseJSON;
                        		if (_resp.error.errorCode == 1014) {
                        			_isSystemFailure = false;
                        			if (_resp.error.errorCode == "1014") {
                        				var _errMsg = serviceErrorMsgs['1014'];
                        				$('#pt-ein-service-err-bg')
                                            .addClass('pt-error');
                        				$('#pt-org-name-serv-error-msg')
                                            .removeClass('hidden')
                                            .html(_errMsg);
                        			}
                        		}
                        	}
                        	if (_isSystemFailure) {
                        		Utils.showSystemUnavailableMsg("1", "info", xhr.status);
                        	} else {
                        		ClientInfoModel.set(
                                    'validEntityName',
                                    false);
                        		_self
                                    .finalClientNameServiceSuccesHandler();
                        	}
                        	Utils.logError(xhr);
                        }, 0);

    			function showOrgNameWarning() {
    				ClientInfoModel.set('validEntityName', false);
    				$('#pt-ein-service-err-bg').addClass(
                        'pt-warning');
    				$('.pt-ein-top-name-std-msg')
                        .removeClass('hidden');
    				_self.saveUserEntdClientName();
    				$('.row.form-group.pt-warning')[0]
                        .scrollIntoView(true);

    			}
    		},
    		saveValidClientNameToModel: function (ScrbClNmResp) {
    			var _scrbClNmResp = ScrbClNmResp;
    			ClientModel.set('scrubEntityName',
                    _scrbClNmResp.orgNm);
    		},
    		saveUserEntdClientName: function () {
    			var _savedUsrOrgName = ClientInfoModel
                    .get('uEntityName');
    			ClientInfoModel.set('entityName', _savedUsrOrgName);
    		},
    		callScrubClientExistenceService: function (clientType) {
    			var _url1 = BASE_URL +
                    'validateClientExistence?$format=json';
    			// var _url1 = 'data/validateClientExistence.json';
    			var _data1 = {};
    			if (clientType == 'Person') {
    				var _rgstNbrTxt = $('#ci-ssn-1').val() +
                        $('#ci-ssn-2').val() +
                        $('#ci-ssn-3').val();
    				var _firstName = $('#ci-first-name').val();
    				var _lastNm = $('#ci-last-name').val();
    				var _middleName = $('#ci-middle-name').val() ? $(
                            '#ci-middle-name').val() :
                        '';
    				_data1 = {
    					"customerTypeCd": "Person",
    					"rgstNbrTxt": _rgstNbrTxt,
    					"vldClExstPersClDtl": {
    						"ttlTxt": "",
    						"firstNm": _firstName,
    						"midNm": _middleName,
    						"lastNm": _lastNm,
    						"sfxTxt": ""
    					}
    				};
    			} else {
    				var _rgstNbrTxt = $('#ci-ein-1').val() + $('#ci-ein-2').val();
    				var _orgName = $('#ci-entity-name').val();
    				var _selectedRole = $('#ci-entity-role option:selected');
    				var _orgTypeCode = _selectedRole.attr('data-scrub-value');
    				_data1 = {
    					"customerTypeCd": "Organisation",
    					"rgstNbrTxt": _rgstNbrTxt,
    					"vldClExstOrgClDtl": {
    						"orgNm": _orgName,
    						"orgTypCd": _orgTypeCode
    					}

    				};
    			}
    			this.clientExistenceValidationService(_data1, _url1);
    		},
    		clientExistenceValidationService: function (dataString,
                url) {
    			var _data1 = dataString;
    			var _url1 = url;
    			var _self = this;
    			ClientInfoModel.set('validClient', false);
    			$('#pt-ssn-service-err-msg').addClass('hidden');
    			Utils.post(_url1, JSON.stringify(_data1),
                    clientExistenceValidatoinSucces,
                    function (xhr) {
                    	ClientInfoModel.set('validClient',
                            false);
                    	Utils.showSystemUnavailableMsg("1", "info", xhr.status);
                    	Utils.logError(xhr);
                    }, 0);

    			function clientExistenceValidatoinSucces(resp) {
    				_response1 = resp.d;
    				var _explntn = _response1.vldClExstRespExpl.results[0];
    				var _isSuccess = true;
    				var _errMsg = serviceErrorMsgs['7090'];
    				switch (_explntn.explCd) {

    					case '7091':
    						_isSuccess = true;
    						break;
    					case '7090':
    						_errMsg = serviceErrorMsgs['7090'];
    						_isSuccess = false;
    						break;
    					case '7092':
    						_errMsg = serviceErrorMsgs['7092'];
    						_isSuccess = false;
    						break;
    					case '7102':
    						_errMsg = serviceErrorMsgs['7102'];
    						_isSuccess = false;
    						break;
    					case '7115':
    						_errMsg = serviceErrorMsgs['7115'];
    						_isSuccess = false;
    						break;
    					case '7189':
    						_errMsg = serviceErrorMsgs['7189'];
    						_isSuccess = false;
    						break;
    					case '7057':
    						_errMsg = serviceErrorMsgs['7057'];
    						_isSuccess = false;
    						break;

    					default:
    						_isSuccess = true;
    						_errMsg = "";
    						break;
    				}
    				if (_isSuccess) {
    					ClientInfoModel.set('validClient', true);
    					_self.saveUserEntdClientData();

    				} else {
    					ClientInfoModel.set('validClient', false);
    					_self
                            .saveClientExistenceToModel(_response1.VldClExstResp);
    					// showing error message from response for
    					// selected codes
    					// representing error case

    					// add red bg-color to ssn container
    					if ($('input[name="clientType"]:checked')
                            .val() == 'P') {
    						$('.pt-ssn-error-bg').addClass(
                                'pt-error');
    						$('#pt-ssn-service-err-msg')
                                .removeClass('hidden').html(
                                    _errMsg);
    					} else {
    						// if exp code 7115 throw error on
    						// orgname
    						if (_explntn.explCd == "7115") {
    							$('#pt-ein-service-err-bg')
                                    .addClass('pt-error');
    							$('#pt-org-name-serv-error-msg')
                                    .removeClass('hidden')
                                    .html(_errMsg);
    						} else {
    							$('.pt-ein-error-bg').addClass(
                                    'pt-error');
    							$('#pt-ein-service-err-msg')
                                    .removeClass('hidden')
                                    .html(_errMsg);
    						}

    					}
    					$('.row.form-group.pt-error')[0]
                            .scrollIntoView(true);
    					Utils.unlockForm();
    				}
    				_self.finalClientNameServiceSuccesHandler();

    			}
    		},
    		saveClientExistenceToModel: function (VldClExstResp) {
    			var _VldClExstResp = VldClExstResp;
    			/*
                 * Need to identify which all data needs to be saved
                 * on service success
                 */
    		},
    		saveUserEntdClientData: function () {
    			/*
                 * If clientExistence service fails then user
                 * entered data has to be saved
                 */
    		},
    		finalClientNameServiceSuccesHandler: function () {
    			_serviceCounter--;
    			var _clientExtValid = ClientInfoModel
                    .get('validClient');
    			var _clientNameValid = ClientInfoModel
                    .get('validEntityName');
    			// if client doesnt exist
    			var _deterProceed = _clientExtValid &&
                    _clientNameValid;
    			/*
                 * if both the services returned a response and
                 * client doesn't exist
                 */
    			if (_deterProceed && _serviceCounter == 0) {
    				ClientModel.set('newClientWithAddress', false);
    				Utils.unlockForm();
    				this.markActiveStep(this.clickedStep);
    				location.hash = this.nextHash;
    				window.scrollTo(0, 0);

    			}
    			if (_serviceCounter == 0) {
    				Utils.unlockForm();
    			}
    		},
    		markActiveStep: function (_clickedStep) {
    			$('.ncst-step').removeClass('active');
    			// add the variaable setup needed forcorresponding
    			// step
    			switch (_clickedStep) {
    				case 1:
    					$('.icon-info').popover('hide');
    					$('.ncst-step.step1').addClass('active')
                            .removeClass('finished');
    					break;
    				case 2:
    					$('.ncst-step.step2').addClass('active')
                            .removeClass('finished');
    					break;
    				case 3:
    					$('.ncst-step.step3').addClass('active')
                            .removeClass('finished');
    					break;
    				case 4:
    					$('.ncst-step.step4').addClass('active')
                            .removeClass('finished');
    					break;
    				case 5:
    					$('.ncst-step.step5').addClass('active')
                            .removeClass('finished');
    					break;
    				case 6:
    					$('.ncst-step.step6').addClass('active')
                            .removeClass('finished');
    					break;
    				case 7:
    					$('.ncst-step.step7').addClass('active')
                            .removeClass('finished');
    					break;
    				case 8:
    					$('.ncst-step.step8').addClass('active')
                            .removeClass('finished');
    					break;

    				default:
    					break;
    			}
    		},
    		handleIndustryOptions: function () {
    			var selectedOption = $('#pt-select-industry :selected').text();
    			if (selectedOption == "Other") {
    				$('#pt-industry-other').removeClass('hidden');
    			} else {
    				$('#pt-industry-other').addClass('hidden');
    			}
    			if (this.model && this.model.get('industryFreeFormText') != "") {
    				$('#pt-industry-other-input').val(this.model.get('industryFreeFormText'));
    			} else {
    				$('#pt-industry-other-input').val("");
    			}
    		},
    		industryClassification: function (indsClsCd) {
    			var mappingCode = Constants.industryClassifications;
    			var indsName = "";
    			_.each(mappingCode, function (list) {
    				if (list.name == indsClsCd) {
    					indsName = list.code;
    				}
    			});
    			return indsName;
    		},
    		renderClientEntityOption: function (addressEntryData) {
    			var clientEntityView, self = this;
    			clientEntityView = new RadioButtonView({
    				el: self.$('#entity-client-radiobuttons'),
    				items: [{ description: 'U.S. entity', id: 'pt-us-entity-option' },
							{ description: 'Foreign entity', id: 'pt-foreign-entity-option' }]
    			});
    			if (addressEntryData != undefined && addressEntryData.get('frgnOrgCheck') != "") {
    				var selectedList = [];
    				if (addressEntryData.get('frgnOrgCheck') == "Y") {
    					selectedList = clientEntityView.items[0];
    				} else {
    					selectedList = clientEntityView.items[1];
    				}
    				clientEntityView.selectedItem = selectedList;
    			}
    			clientEntityView.itemSelectionComplete = function (selectedItem) {
    			self.captureClientEntityRadio(selectedItem);
    			};
    			this.addNestedView(this.clientEntityViewName, clientEntityView);
    			clientEntityView.render();
    			if (addressEntryData != undefined && addressEntryData.get('frgnOrgCheck') != "") {
    				if (addressEntryData.get('frgnOrgCheck') == "Y") {
    					$('#pt-us-state-drpdown').val(addressEntryData.get('stOfIncorpCode'));
    				} 
    			}
    		},
    		captureClientEntityRadio: function (selectedItem) {
    			if (selectedItem.id == "pt-us-entity-option") {
    				$('#pt-state-container').removeClass('hidden');
    				Utils.loadSelectbox(["#pt-us-state-drpdown"], DropdownOptions.USStateslist);
    			} else {
    				$('#pt-state-container').addClass('hidden');
    			}
    		},
    		handleNonProfitGovtOption: function (event) {
    			var _prevRole = ClientModel.get('clientInfo').get('entityRole');
    			var selectedOption = $(event.target).val();
    			var _entityRoleSelected = selectedOption.toLowerCase();

    			//Industry Classification Code
    			var selectedDataValue = $('#ci-entity-role :selected').attr('data-value');
    			var industryOptionCode = ['1C', '1S', '02', '05', '6C', '6S', '10'];
    			var domiciledFieldCode = ['1C', '1S', '02', '04', '05', '6C', '6S', '09', '10'];

    			if (_.contains(domiciledFieldCode, selectedDataValue)) {
    				$('#entity-client-container').removeClass('hidden');

    				if (this.model && this.model.get('frgnOrgCheck') != "") {
    					this.renderClientEntityOption(this.model);
    				} else { this.renderClientEntityOption(); }

    			} else {
    				$('#entity-client-container').addClass('hidden');
    			}

    			if (_.contains(industryOptionCode, selectedDataValue)) {
    				if (_prevRole != selectedOption) {
    					$(this.operatingEntity).find('.active').removeClass('active');
    					this.renderOperationalityRadios();
    				}
    				$('#industry-classification, ' + this.operatingEntity).removeClass('hidden');
    				CommonUtils.loadSelectbox(["#pt-select-industry"], Constants.industryClassifications);
    				if (this.model && this.model.get('industryClassifyType') != "") {
    					indText = this.industryClassification(this.model.get('industryClassifyType'));
    					$("#pt-select-industry").val(indText);
    				}
    			} else {
    				$('#industry-classification, #pt-industry-other, ' + this.operatingEntity).addClass('hidden');
    			}

    			$('.helper-text-container:not(.revoc-trust-help)').hide();
    			$('#entity-role-container').find('.ncst-fn-text-container').hide();
    			// clearing preselected clientdetails(step4)
    			// association details.
    			var _$asscoClntQn = $('#clientAssociation'),
                    _$asscoClientOption = $('#asscoc-client-chose-option'),
                    _selectedClientType = $('input[name="clientType"]:checked').val();
    			if (_selectedClientType != "P") {
    				_$asscoClntQn.addClass('hidden');
    				_$asscoClientOption.addClass('hidden');
    			}
    			if ((selectedOption == "Non-Profit")) {
    				$('.entity-non-profit-role').show();
    				this.model.set('revocableFlag', 0);
    			} else if (selectedOption == "Government entity") {
    				$('.entity-govt-role').show();
    				this.model.set('revocableFlag', 0);
    			} else if (selectedOption == 'Revocable trust') {
    				_$asscoClntQn.removeClass('hidden');
    				_$asscoClientOption.removeClass('hidden');
    				$('#revoc-trust-help-cntnr').removeClass('hidden');
    				$('#cd-assoc-reltn-cntnr').addClass('hidden');
    				$('.entity-revoc-role').show();
    				this.model.set('revocableFlag', 1);
    			} else if (selectedOption == 'Irrevocable trust') {
    				// ClientDetailsModel.set('clientprimaryEmail',
    				// '');
    				$('.entity-irrevoc-role').show();
    				this.model.set('revocableFlag', 0);
    			} else {
    				this.model.set('revocableFlag', 0);
    			}
    		},
    		modelSaver: function (validateRequired) {
    			prevAdvsrNum = ClientModel.get('advisorNumber');
    			$('.icon-info').popover('hide');
    			if (this.model.validate(validateRequired)) {
    				/* If valid inputs are given then save the advisor number to the base client model
                     * Requirement: Advisor number is editable and the edited number needs to be shown
                     * in the rest of the screens.
                     * */
    				var _paddedAdvNum = this.zeropad($('#i-advisor-number').val(), 9)
    				ClientModel.set('advisorNumber', _paddedAdvNum);

    				if (this.model.get('clientType') == "P") {
    					// validate the citizenship separately
    					return this.validateCitizenship();
    				} else {
    					return true;
    				}
    			} else {
    				return false;
    			}
    		},
    		validateCitizenship: function () {
    			var _returnVal = true;
    			var _selectedCitznshp = $('input[name="citizenShip"]:checked').val();
    			var _selectedCountry = $('#ci-citizenship-country').val();
    			if (_selectedCitznshp != "U.S." && _selectedCountry == "") {
    				_returnVal = false;
    			}
    			if (!_returnVal) {
    				var _container = $('div[data-for="ci-citizenship-country"]');
    				_container.addClass('error');
    				_container
                        .find('.ncst-adjust-left,label.error')
                        .removeClass('hidden');
    			}
    			return _returnVal;
    		},
    		ssn1Keypress: function (e) {
    			var _ssn1Val = $('#ci-ssn-1').val();
    			var _el = document.getElementById('ci-ssn-1');
    			var _regxNumOnly = new RegExp('^\\d*$');
    			var _str = String.fromCharCode(e.keyCode);
    			if (!_regxNumOnly.test(_str)) {
    				e.stopPropagation();
    				e.preventDefault();
    				return false;
    			}
    			if (_el.selectionStart == _el.selectionEnd) {
    				if (_ssn1Val.length == 3) {
    					var _$ssn2 = $('#ci-ssn-2');
    					var _value = _$ssn2.val();
    					if (_value.length < 2) {
    						_value = _$ssn2.val() + _str;
    						_$ssn2.val(_value);
    						_$ssn2.trigger('focus');
    						this.setCaretPosition('#ci-ssn-2',
                                _$ssn2.val().length);
    					} else {
    						_$ssn2.select();
    					}

    					e.stopPropagation();
    					e.preventDefault();
    					return false;
    				}
    			}

    		},
    		ssn2Keypress: function (e) {
    			try {

    				var _ssn1Val = $('#ci-ssn-2').val();
    				if (e.keyCode == 9) {
    					return false;
    				}
    				var _regxNumOnly = new RegExp('^\\d*$');
    				var _str = String.fromCharCode(e.keyCode);
    				if (!_regxNumOnly.test(_str)) {
    					e.stopPropagation();
    					e.preventDefault();
    					return false;
    				}
    				var _el = document.getElementById('ci-ssn-2');
    				if (_el.selectionStart == _el.selectionEnd) {
    					if (_ssn1Val.length == 2) {
    						var _$ssn3 = $('#ci-ssn-3');
    						var _value = _$ssn3.val();
    						if (_value.length < 4) {
    							_value = _$ssn3.val() +
                                    String
                                    .fromCharCode(e.keyCode);
    							_$ssn3.val(_value);
    							_$ssn3.trigger('focus');
    						} else {
    							_$ssn3.select();
    						}
    						e.stopPropagation();
    						e.preventDefault();
    						return false;
    					}
    				}


    			} catch (e) {

    			}
    		},
    		ssn3Keypress: function (e) {
    			var _ssn1Val = $('#ci-ssn-3').val();
    			var _regxNumOnly = new RegExp('^\\d*$');
    			var _str = String.fromCharCode(e.keyCode);
    			if (!_regxNumOnly.test(_str)) {
    				e.stopPropagation();
    				e.preventDefault();
    				return false;
    			}
    			var _el = document.getElementById('ci-ssn-3');
    			try {
    				if (_el.selectionStart == _el.selectionEnd) {
    					if (_ssn1Val.length >= 4) {
    						// $('#ci-ssn-3').blur();
    						e.stopPropagation();
    						e.preventDefault();
    						return false;
    					}
    				}
    			} catch (e) { }

    		},
    		ein1Keypress: function (e) {
    			var _el = e.target;
    			var _ein1Val = _el.value;
    			var _regxNumOnly = new RegExp('^\\d*$');
    			var _str = String.fromCharCode(e.keyCode);
    			if (!_regxNumOnly.test(_str)) {
    				e.stopPropagation();
    				e.preventDefault();
    				return false;
    			}
    			try {
    				if (_el.id == "ci-ein-1") {
    					if (_el.selectionStart == _el.selectionEnd) {
    						if (_ein1Val.length == 2) {
    							var _$ein2 = $(_el).next();
    							var _value = _$ein2.val();
    							if (_value.length < 4) {
    								_value = _$ein2.val() + _str;
    								_$ein2.val(_value);
    								_$ein2.trigger('focus');
    								this.setCaretPosition('#ci-ein-2',
                                        _$ein2.val().length);
    							} else {
    								_$ein2.select();
    							}

    							e.stopPropagation();
    							e.preventDefault();
    							return false;
    						}
    					}
    				} else {
    					if (_el.selectionStart == _el.selectionEnd) {
    						if (_ein1Val.length >= 7) {
    							// $('#ci-ein-2').blur();
    							e.stopPropagation();
    							e.preventDefault();
    							return false;
    						}
    					}
    				}
    			} catch (e) { }

    		},
    		setCaretPosition: function (elemId, caretPos) {
    			try {
    				var elem = document.getElementById(elemId);
    				if (elem != null) {
    					if (elem.selectionStart) {
    						if (elem.selectionStart) {
    							$(elem).trigger('focus');
    							elem.setSelectionRange(caretPos,
                                    caretPos);
    						} else
    							$(elem).trigger('focus');
    					} else {
    						if (elem.createTextRange) {
    							var range = elem.createTextRange();
    							range.move('character', caretPos);
    							range.select();
    						}
    					}
    				}

    			} catch (e) {
    				console.log('no support to selection start');
    			}
    		},
    		ssnNextValidate: function (e) {
    			// if the user press tab do not change the focus
    			if (e.keyCode != 9 && e.keyCode != 16) {
    				var _$el = $(e.target);
    				var _currLength = _$el.val().length;
    				if (_currLength == _$el
                        .attr('data-required-length')) {
    					var _$nextEl = _$el.next();
    					_$nextEl.trigger('focus');
    					if (_$nextEl.val() != undefined &&
                            _$nextEl.val() != "undefined") {
    						this.setCaretPosition(_$nextEl
                                .attr('id'),
                                _$nextEl.val().length);
    					} else {

    					}

    				} else {
    					this.setCaretPosition(_$el.attr('id'), _$el
                            .val().length);
    				}
    			}

    		},
    		statusChangefor2and3: function () {
    			/* Resetting Change step2 and 3 completion status */
    			$('.ncst-step.step2,.ncst-step.step3').removeClass(
                    'pending active finished');
    			ClientModel.set('stepsCompleted', Utils
                    .arraySplice(ClientModel
                        .get('stepsCompleted'),
                        'address-entry'));
    			ClientModel.set('stepsCompleted', Utils
                    .arraySplice(ClientModel
                        .get('stepsCompleted'),
                        'address-validation'));
    		},
    		handleCitizenshipChange: function (e, prgmInvoke) {
    			var _$el = $('input[name="citizenShip"]:checked');
    			var _contnr = $('div[data-for=' + this.ciCitizenshipCountry + ']');
    			var secCitizenShipCountry = $('div[data-for=' + this.ciSecondCitizenshipCountry + ']');

    			if (_$el.val() == "U.S." || _$el.length === 0) {
    				_contnr.addClass('hidden').removeClass('error')
                        .find("span.ncst-adjust-left")
                        .addClass("hidden");
    				_contnr.find('label.error').addClass('hidden');
    				secCitizenShipCountry.addClass('hidden');
    			} else {
    				_contnr.removeClass('hidden');
    				secCitizenShipCountry.removeClass('hidden');
    			}
    			var _$ssnCntnr = $('div[data-for-ssn="ci-ssn-"]');

    			if (_$el.val() == 'Non-Resident Alien') {
    				// make ssn optional
    				_$ssnCntnr.removeClass('data-required');
    				_$ssnCntnr.find('.ssn').removeClass('required');
    				$('#ssn-help-block').show();
    			} else {
    				_$ssnCntnr.addClass('data-required');
    				_$ssnCntnr.find('.ssn').addClass('required');
    				$('#ssn-help-block').hide();
    			}
    			/*
                 * Change of Citizenship type to Non-Resident Alien
                 * from US or Resident Alien
                 */
    			var _saveCitznShpVal = ClientInfoModel
                    .get('citizenship');
    			var _$selectedCitznShp = $('input[name="citizenShip"]:checked');
    			var _selectdCitznShpVal = _$selectedCitznShp.val();
    			if (ClientModel.get('newClientWithAddress')) {
    				var _lastCreatedClientData = JSON.parse(ClientModel.toJSON().clientValidatedDtls);
    				if (_lastCreatedClientData && _lastCreatedClientData.personClient && _lastCreatedClientData.personClient.ctzp)
    					_saveCitznShpVal = _lastCreatedClientData.personClient.ctzp;
    			}
    			if ((ClientModel.get('newClientWithAddress') || _saveCitznShpVal) && !prgmInvoke) {
    				if (_saveCitznShpVal != _selectdCitznShpVal) {
    					this.statusChangefor2and3();
    					// clear the model
    					AddressModel.clear().set(AddressModel.defaults);
    					// Some dropdown fields were not getting
    					// cleared.Therefore code below is given
    					AddressModel.set('primaryAddress', {});
    					AddressModel.set('mailingAddress', {});
    				}
    			}
    		},
    		loadCountryList: function () {
    			var _countryList = DropdownOptions.ISOCountryList;
    			var _selectbox = ["#" + this.ciCitizenshipCountry, "#" + this.ciSecondCitizenshipCountry];
    			$.each(_selectbox, function (i, val) {
    				Utils.loadSelectbox(_selectbox[i], _countryList);
    			});
    		},
    		handlerForCancel: function () {
    			BootstrapDialog
                    .confirm(
                        "Cancel",
                        "All your work will be lost.  Are you sure you want to cancel?",
                        function (confirm) {
                        	if (confirm) {
                        		var _context = GlobalContext.getInstance().getGlobalContext().Context;
                        		//if standalone mode close the window
                        		if (_context.IsStandalone == true) {
                        			if (Utils.iOSversion() > 7 || window.chrome) {
                        				var _cancelMsg = '<div class="container" align="center"><div  class="row cancld-txn-msg">This transaction has been cancelled. You may now close the window.</div>';
                        				var _cntnr = $('#ncst-user-home-view');
                        				_cntnr.html(_cancelMsg);
                        			} else {
                        				window.open('', '_self');
                        				window.close();
                        			}
                        		} else {
                        			location.hash = "contactprofile/";
                        		}


                        	}

                        }, 'ncst-dialog');
    		},
    		handleClientRoleChange: function () {

    			ClientModel.set('stepsCompleted', Utils
                    .arraySplice(ClientModel
                        .get('stepsCompleted'), 'income'));
    			ClientModel.set('stepsCompleted', Utils
                    .arraySplice(ClientModel
                        .get('stepsCompleted'), 'client-details'));
    			$('.ncst-step.step6,.ncst-step.step4').removeClass(
                    'active pending finished');
    			var cT = $('[name=clientRole]:checked').val();
    			if ('F' == cT) {
    				Analytics.analytics.recordSharedSuiteAction('ncstClientInfoClientRole:fiduciary');
    			} else {
    				Analytics.analytics.recordSharedSuiteAction('ncstClientInfoClientRole:owner');
    			}

    		},
    		clientTypeToggleMsg: function () {
    			BootstrapDialog
                    .confirm(
                        "Cancel",
                        "All your work will be lost.  Are you sure to proceed?",
                        function (confirm) {
                        	if (confirm) {
                        		window.close();
                        	} else {
                        		return false;
                        	}
                        });
    		},
    		/* Function to pad zero. Parameters one is the given number other is the padlength required*/
    		zeropad: function (num, numLength) {
    			var n = Math.abs(num);
    			var zeros = Math.max(0, numLength - Math.floor(n).toString().length);
    			var zeroString = Math.pow(10, zeros).toString().substr(1);
    			if (num < 0) {
    				zeroString = '-' + zeroString;
    			}

    			return zeroString + n;
    		},
    		initializetypeahead: function () {
    			var _self = this;
    			// code for typeahead
    			$("#cd-assoc-name-search").typeahead({
    				items: 1000,
    				source: function (query, process) {
    					if (query.length < 3) {
    						return;
    					}
    					_self.clearAssociatedClient();
    					var _curObj = this;
    					var _userLabels = [],
                            _userSearchVal = [];
    					var _userfmtNm = '';
    					_curObj._userids = {};
    					_curObj.users = {};
    					if ($('#client-name-search').hasClass("active")) {
    						if (!isNaN(query)) {
    							_self.showClientSerachInlineError('No records found. Try by Client ID.');
    							return
    						}
    						_.each(_self.model.get('clientNames'),
                                function (item, ix, list) {
                                	var idTrunked = item.id.substr(-9);
                                	if (item.firstNm) {
                                		_userfmtNm = item.lastNm + ', ' + item.firstNm + ' - ' + idTrunked;
                                	} else {
                                		_userfmtNm = item.orgNm + ' - ' + idTrunked;
                                	}
                                	// add the label to the display array
                                	_userLabels.push(_userfmtNm, item.id);
                                	_userSearchVal.push(_userfmtNm);
                                	var _name = item.firstNm ? (item.lastNm + ', ' + item.firstNm) : item.orgNm
                                	// also store a mapping to get from label back to ID
                                	_curObj.users[_userfmtNm] = {
                                		id: item.id,
                                		name: _name
                                	};
                                	_curObj._userids[item.id] = {
                                		id: item.id,
                                		name: _name
                                	};

                                });
    						// adding userids to users object
    						_self.mix(_curObj._userids, _curObj.users);
    						// return the display array
    						process(_userSearchVal);
    					}
    					/*else{
                        									if(!isNaN(query) && query.trim().length == 8){
                        										//do the client id search
                        										_self.doClientIdSearch(query.trim());
                        									}
                        								}*/

    				},

    				updater: function (item, a, b) {
    					var pos = item.indexOf(' - '),
                            _contactSearch = this;
    					try {
    						var _$cdAsscNm = $('#cd-assoc-name'),
                                _$cdAssocNmSearch = $('#cd-assoc-name-search');
    						if (ClientModel.get('isAACUser') != true) {
    							Utils.lockForm();
    							_self.validatePrimaryAdvsr(_contactSearch.users[item]['id'], validatePrimaryAdvsrSuccess,
                                    function (xhr) {
                                    	Utils.unlockForm();
                                    	if (xhr.status == "401") {
                                    		showNotAssociatedMessage();
                                    	} else {
                                    		$('.modal-backdrop:visible').click()
                                    		Utils.showSystemUnavailableMsg("1", "info", xhr.status);
                                    	}

                                    });


    						} else {
    							var _fmtdData = _contactSearch.users[item]['name'].concat(' - ', _contactSearch.users[item]['id'].substr(-8));
    							selectClient(_fmtdData);
    							return _fmtdData;
    						}

    						function selectClient(fmtdData) {
    							_self.hideErrorForAdvisorNumber();
    							_self.hideSearchOption();
    							_$cdAssocNmSearch.data('value', _contactSearch.users[item]['id']);
    							_$cdAsscNm.data('value', _contactSearch.users[item]['id']);
    							_$cdAsscNm.val(fmtdData);
    						}

    						function validatePrimaryAdvsrSuccess(dstrId, noActiveHouseholdGroupsFlag) {
    							Utils.unlockForm();
    							if (dstrId) {
    								var _fmtdData = _contactSearch.users[item]['name'].concat(' - ', _contactSearch.users[item]['id'].substr(-8));
    								selectClient(_fmtdData);
    								return _fmtdData;
    							} else {
    								if (noActiveHouseholdGroupsFlag) {
    									_self.showClientSerachInlineError('Unable to associate because existing client does not have a household group.  Create client and use the Household Account Grouping workflow on Advisor Mobile or eForms Manager.');
    								} else {
    									showNotAssociatedMessage();
    								}
    							}
    						}

    						function showNotAssociatedMessage() {
    							_$cdAssocNmSearch.data('value', "");
    							_$cdAsscNm.data('value', "");
    							var _errorMsg = 'The primary advisor is not associated to the selected client.';
    							_self.showClientSerachInlineError(_errorMsg);
    							//highlight advisor number
    							_self.showErrorForAdvisorNumber(_errorMsg)
    							///BootstrapDialog.alert("Not authorized");
    							return "";
    						}

    					} catch (e) {

    					}

    				},
    				sorter: function (items) {
    					if (items.length == 0) {
    						setTimeout(function () {
    							$('#cd-assoc-name,#cd-assoc-name-search').data('value', '');
    							$('#afi-nav-modal').modal('show');
    							var _$dropdownMenu = $('#add-details .typeahead.dropdown-menu');
    							_$dropdownMenu.hide();
    							_self.clearAssociatedClient();
    							_self.showClientSerachInlineError('No records found. Try by Client ID.');
    						}, 10);
    					} else {
    						$('#ncst-no-record-found').hide();
    					}
    					return items;
    				},
    				highlighter: function (item) {
    					var p = this.users[item];
    					var itm = '' +
                            "<div class='typeahead_wrapper'>" +
                            "<div class='typeahead_labels'>" +
                            "<div class='typeahead_primary'>" +
                            p.name +
                            "</div>" +
                            "<div class='typeahead_secondary'>" +
                            p.id.substr(-8) +
                            "</div>" +
                            "</div>" +
                            "</div>";
    					return itm;
    				},
    				minLength: 3
    			});
    		},
    		validateClientAgianstPAClients: function (clId) {
    			var _returnObj = null;
    			var _grpClients = _self.model.get('groupClients');
    			console.log(clId, _grpClients, "_grpClients");
    			if (_grpClients.length == 0) {
    				return _returnObj;
    			}
    			$.each(_grpClients, function (i, client) {
    				if (client.clId == clId) {
    					_returnObj = client;
    				}
    			});
    			return _returnObj
    		},
    		showClientSerachInlineError: function (msg) {
    			$('#ncst-no-record-found').html(msg).show();
    		},
    		doPreCheckForClIdSearch: function () {
    			_self.hideErrorForAdvisorNumber();
    			$('#ncst-no-record-found').hide();
    			var _clid = $('#cd-assoc-id-search').val().trim();
    			if (_clid.length < 8 || isNaN(_clid)) {
    				this.showClientSerachInlineError("Not full 8 digit typed.");
    			} else {
    				var _fmtdClId = this.clientIDFormatter(_clid),
                        _$cdAsscNm = $('#cd-assoc-name'),
                        _$cdAssocNmSearch = $('#cd-assoc-name-search');
    				if (ClientModel.get('isAACUser') != true) {
    					Utils.lockForm();
    					_self.validatePrimaryAdvsr(_fmtdClId, function (dstrId, noActiveHouseholdGroupsFlag) {
    						Utils.unlockForm();
    						if (dstrId) {
    							_self.doClientIdSearch(_clid);
    						} else if (noActiveHouseholdGroupsFlag) {
    							_self.showClientSerachInlineError('Unable to associate because existing client does not have a household group.  Create client and use the Household Account Grouping workflow on Advisor Mobile or eForms Manager.');
    						} else {
    							var _errorMsg = 'The primary advisor is not associated to the selected client.';
    							_self.showClientSerachInlineError(_errorMsg);
    							//highlight advisor number
    							_self.showErrorForAdvisorNumber(_errorMsg)
    						}

    					}, function (xhr) {
    						Utils.unlockForm();
    						if (xhr.status == "401") {
    							_self.showClientSerachInlineError('8 digit matches but not authorized.');
    						} else {
    							Utils.showSystemUnavailableMsg("1", "info", xhr.status);
    						}

    					});
    				} else {
    					this.doClientIdSearch(_clid);
    				}
    			}
    		},
    		validatePrimaryAdvsr: function (clId, successCallback, errorCallback) {
    			var _paddedAdvNum = _self.zeropad($('#i-advisor-number').val(), 9);
    			Dataservice.getActiveGroups(clId).done(function (response, status, xhr) {
    				var _activeGrps = [],
                        _activeHouseholdGroups = [],
                        _processingCount = 0,
                        _grpPrmryAdvsr = null;
    				if (response && response.d && response.d.results && response.d.results.length > 0) {
    					_activeGrps = response.d.results;
    					$.each(_activeGrps, function (key, actvGrp) {
    						if (actvGrp.grpCtgCd == "HOUSEHOLD") {
    							var _actvhouseHoldGrp = {
    								"id": actvGrp.id,
    								"grpPrmAdvisor": actvGrp.grpPrmAdvisor
    							};
    							_activeHouseholdGroups.push(_actvhouseHoldGrp);
    						}

    					});
    				}
    				if (_activeHouseholdGroups.length > 0) {
    					validatePrimaryAdvsr(_processingCount);

    					function validatePrimaryAdvsr(_processingCount) {
    						Dataservice.getGrpPrimaryAdvisor(_activeHouseholdGroups[_processingCount].id).done(function (response, status, xhr) {
    							_processingCount++;
    							if (response && response.d && response.d.dstrId && _self.zeropad(response.d.dstrId, 9) == _paddedAdvNum) {
    								successCallback(_self.zeropad(response.d.dstrId, 9));
    							} else {
    								if (_processingCount < _activeHouseholdGroups.length) {
    									validatePrimaryAdvsr(_processingCount);
    								} else {
    									successCallback();;
    								}
    							}

    						}).fail(function (xhr) {
    							errorCallback(xhr);
    						});
    					}
    				} else {
    					successCallback(null /*distrId*/, true /*no active groups flag*/);
    				}
    			}).fail(function (xhr) {
    				errorCallback(xhr);
    			});
    		},
    		doClientIdSearch: function (clientId) {
    			var _self = this;
    			var _fmtdClId = this.clientIDFormatter(clientId);
    			Utils.lockForm();
    			Dataservice.getClientgroup(_fmtdClId, [401, 500]).then(function (response) {
    				Utils.unlockForm();
    				if (response && response[0]) {
    					var _clientObj = {
    						name: "",
    						id: _fmtdClId
    					};
    					var _name = "";
    					var _clModel = response[0];
    					var _clntInfo = _clModel.get("personClient").toJSON();
    					if (_clntInfo.clFirstNm != null) {
    						_name = _clntInfo.clLastNm + ", " + _clntInfo.clFirstNm;
    					} else {
    						_clntInfo = _clModel.get("orgClient").toJSON();
    						_name = _clntInfo.orgNm;
    					}
    					_name = _name.toLowerCase();
    					_clientObj.name = _name;
    					_self.hideSearchOption();
    					$('#cd-assoc-name').val(_name + " - " + clientId).data("value", _fmtdClId);
    				} else {
    					if (response && response.status == 500) {
    						_self.showClientSerachInlineError('Incorrect 8 digit typed.');
    					} else if (response && response.status == 401) {
    						_self.showClientSerachInlineError('8 digit matches but not authorized.');
    					} else {
    						_self.hideSearchOption();
    						Utils.logError(response, true);
    					}
    				}

    			}).fail(function (error) {
    				Utils.unlockForm();
    			});
    		},
    		clientIDFormatter: function (id) {
    			var _admnCd = '001',
                    _formattedIdLength = 23,
                    _padzeoLength = 12,
                    _zeroString = "",
                    _formattedId = id;
    			_padzeoLength = (_formattedIdLength - _admnCd.length - id.length);
    			if ((_admnCd.length + id.length) < 23) {
    				_zeroString = Math.pow(10, _padzeoLength).toString().substr(1);
    				_formattedId = _admnCd + '' + _zeroString + '' + id;
    			}
    			return _formattedId;

    		},
    		mix: function (source, target) {
    			for (var key in source) {
    				if (source.hasOwnProperty(key)) {
    					target[key] = source[key];
    				}
    			}
    		},
    		clearClientSearch: function () {
    			$('.typeahead.dropdown-menu').hide();
    			$('#cd-assoc-name-search').val('');
    			$('#ncst-no-record-found').hide();
    		},
    		clearClientIdSearch: function () {
    			$('.typeahead.dropdown-menu').hide();
    			$('#cd-assoc-id-search').val('');
    			$('#ncst-no-record-found').hide();
    		},
    		clearAssociatedClient: function () {
    			var _$slectedClnt = $('#cd-assoc-name');
    			_$slectedClnt.data('value', '');
    			_$slectedClnt.val('');
    		},
    		showSearchOption: function () {
    			document.getElementById("ncst-client-serach-ctnr").scrollIntoView();
    			$('#ncst-user-home-view .icon-info').popover('hide');
    			$('body').addClass("ncst-custom-modal-bg");
    			$('#ncst-no-record-found').hide();
    			$('#ncst-client-serach-ctnr').css('height', '110px');
    			var _$typeheadInput = $('#cd-assoc-name-search');
    			$('.client-id-search-fields-r').addClass("hidden");
    			$('#afi-nav-modal').modal('show');
    			_$typeheadInput.val("");
    			_$typeheadInput.data("value", "");
    			$('.client-id-search-fields').removeClass("hidden");
    			$('#client-id-search-button,#cd-assoc-id-search,#cd-assoc-id-clear-search').addClass("hidden");
    			$('.search-option-link').removeClass("active");
    			$('#client-name-search').addClass("active");
    			_$typeheadInput.focus();
    		},
    		hideSearchOption: function () {
    			hideSearchOption();
    		},
    		clearTypehead: function () {

    		},
    		hideNoClientsAsscoaitedError: function () {
    			var _$container = $('#clientAssociation');
    			if (_$container.find('label.error').text() == noClientsAssociatedErrMsg) {
    				var _$ctnr = $('#clientAssociation');
    				_$ctnr.find('button').removeClass('no-recors-found');
    				_$ctnr.removeClass("error").find('label.error').addClass("hidden");
    			}
    		},
    		switchSerachOption: function (evt) {
    			_self.hideErrorForAdvisorNumber();
    			var _$searchBox = $("#cd-assoc-name-search");
    			var _$idSearchBox = $('#cd-assoc-id-search');
    			$('.typeahead.dropdown-menu').hide();
    			$('#ncst-no-record-found').hide();
    			var _$el = $(evt.currentTarget);
    			$('#ncst-contact-search-div .search-option-link').removeClass("active");
    			_$el.addClass("active");
    			if (_$el.attr("data-search-type") == "name") {
    				$('#client-id-search-button,#cd-assoc-id-clear-search').addClass("hidden");
    				_$searchBox.removeClass("hidden");
    				_$idSearchBox.addClass("hidden");
    				$('#cd-assoc-name-clear-search').removeClass("hidden");
    				_$searchBox.focus().val("");
    			} else {
    				$('#cd-assoc-name').data('value', '').val("");
    				this.hideNoClientsAsscoaitedError();
    				$('#cd-assoc-name-clear-search').addClass("hidden");
    				$('#client-id-search-button,#cd-assoc-id-clear-search').removeClass("hidden");
    				_$idSearchBox.removeClass("hidden");
    				_$searchBox.addClass("hidden");
    				if (Utils.isMobile()) {
    					_$idSearchBox.attr('type', 'tel');
    				} else {
    					_$idSearchBox.attr('type', 'text');
    				}
    				_$idSearchBox.focus().val("");
    			}
    		},
    		doFirstnameLastnameLimitValdtn: function () {
    			var _$firstName = $('#ci-first-name'),
                    _$lastName = $('#ci-last-name'),
                    _$firstNmCntnr = $('div[data-for="ci-first-name"]'),
                    _$laststNmCntnr = $('div[data-for="ci-last-name"]');
    			var _firstNm = _$firstName.val().trim(),
                    _lastNm = _$lastName.val().trim();
    			if (_firstNm.length + _lastNm.length > 27) {
    				_$firstNmCntnr.addClass('error').find('label.error').text("First name and last name must not exceed 27 characters total").removeClass("hidden");
    				_$firstNmCntnr.find('.ncst-adjust-left').removeClass("hidden");
    				_$laststNmCntnr.addClass('error').find('label.error').text("First name and last name must not exceed 27 characters total").removeClass("hidden");
    				_$laststNmCntnr.find('.ncst-adjust-left').removeClass("hidden");
    				return false;
    			}
    			return true;
    		},
    		addZIndex: function () {
    			$('#cd-assoc-name,#ncst-contact-search-div').addClass('z-index');
    		},
    		removeZIndex: function () {
    			return;
    			if (!$('#add-details .typeahead.dropdown-menu').is(':visible')) {
    				$('#cd-assoc-name,#ncst-contact-search-div').removeClass('z-index');
    			}
    		},
    		hideNoRecords: function () {
    			var _$assocNm = $('#cd-assoc-name');
    			if (_$assocNm.val() < 3) {
    				$('#ncst-no-record-found').hide();
    				$('#afi-nav-modal').modal('hide');
    			}
    		},
    		assocReltnSelect: function (event) {
    			var _assocMsgs = {
    				'Spouse': '',
    				'Domestic Partner': '',
    				'Dependent Child': 'Dependent child must be under 21 years of age.'
    			};
    			var _assocReltnSelctd = _assocMsgs[$(event.target)
                    .val()];
    			if (_assocReltnSelctd)
    				$('#cd-assoc-reltn-info').removeClass('hide')
                    .find('div').text(_assocReltnSelctd);
    			else
    				$('#cd-assoc-reltn-info').addClass('hide');
    		}

    	});

    	function hideAdvsrNumError() {
    		var _$advsrNumCtnr = $('div[data-for=i-advisor-number],div[data-for=s-advisor-number]');
    		_$advsrNumCtnr.removeClass('error');
    		_$advsrNumCtnr.find('label.error').addClass("hidden");
    	}

    	function showAdvsrIdValdtnErrors(xhr, errorCode, prefill) {
    		Utils.unlockForm();
    		if (xhr.status == 200) {
    			window.scrollTo(0, 100);
    			_self.showErrorForAdvisorNumber(_paEligibleErrorMsg, prefill);
    		} else {
    			if (typeof errorCode === "undefined") {
    				Utils.showSystemUnavailableMsg("1", "info", xhr.status);
    			} else {
    				if (prefill) {
    					if (xhr.status == 401 || errorCode == "401401") {
    						_self.showErrorForAdvisorNumber("User doesn't have explicit relationship with the advisor number entered.", prefill)
    					} else {
    						Utils.showSystemUnavailableMsg("1", "info", xhr.status);
    					}

    				} else {

    					if (errorCode == "500500") {
    						_self.showErrorForAdvisorNumber(invalidAdvsrIdMsg);
    					} else {
    						Utils.setServerErrValidations("1", [errorCode]);
    						if (errorCode == "401401") {
    							Validator.validateInputs('client-info-view', true);
    						}
    					}

    				}
    			}
    		}
    		Utils.logError(xhr);
    	}

    	function showSAError(error, options) {

    		Utils.unlockForm();
    		var _servcAdvsrErrorMsgs = {
    			"invalid": "We are unable to determine if the ID entered is invalid or system is unavailable.  Please check the number entered and try again.",
    			"notInSell": "The advisor is not in a selling role.",
    			"unauth": "User doesn't have explicit relationship with the advisor number entered.",
    			"15657": "Invalid relationship or advisor ID.",
    		},
                _errorMsg, _$servcAdvsrNum = $("#s-advisor-number"),
                _errorResp = error && error.httpResponse && error.httpResponse.data ? error.httpResponse.data : {};
    		_errorResp = typeof _errorResp == "string" ? JSON.parse(_errorResp) : _errorResp;

    		if (error && error.status == 500) {
    			_errorMsg = invalidAdvsrIdMsg;
    		} else if (error && error.status == 401) {
    			_errorMsg = _servcAdvsrErrorMsgs["unauth"];
    		} else if (options && options.sellInd == false) {
    			_errorMsg = _servcAdvsrErrorMsgs["notInSell"];
    		} else if (options && options.errorCd && options.errorCd == "15657") {
    			_errorMsg = _servcAdvsrErrorMsgs[options.errorCd];
    		} else {
    			Utils.showSystemUnavailableMsg("1", "info", error.status);
    			return;
    		}
    		if (_errorMsg) {
    			_$servcAdvsrNum[0].scrollIntoView();
    			_self.showErrorForAdvisorNumber(_errorMsg, true);
    		}
    	}

    	function hideSearchOption() {
    		$('#ncst-client-serach-ctnr').removeAttr('style');
    		var _$typehdInpt = $('#cd-assoc-name-search');
    		$('#afi-nav-modal').modal('hide');
    		//$('#ncst-contact-search-div').addClass("hidden");
    		//_$typehdInpt.addClass("hidden");
    		$('.client-id-search-fields').addClass("hidden");
    		$('.client-id-search-fields-r').removeClass("hidden");
    		_$typehdInpt.data('value', "");
    		_$typehdInpt.val("");
    		$('#cd-assoc-id-search').val("");

    	}
    	$('#afi-nav-modal').on('hide.bs.modal', function (e) {
    		$('body').removeClass("ncst-custom-modal-bg");
    	});
    	//commented as per new requirement
    	$(document).on('click touchstart', '.modal-backdrop', function () {
    		hideSearchOption();
    		var _$ele = $('#cd-assoc-name-search');
    		if (_$ele.is(':visible') && _$ele.val().indexOf('-') == -1) {
    			//$('#cd-assoc-name,#ncst-contact-search-div').removeClass('z-index');
    			//clientDetailsView.model.clearClientAssociation();
    			_$ele.val('');
    			_$ele.data('value', '');
    			$('#afi-nav-modal').modal('hide');
    			$('.typeahead.dropdown-menu').hide();
    			$('#ncst-no-record-found').hide();
    			//clear the datvalue of li
    			$('#add-details').find('.typeahead.dropdown-menu li').attr('data-value', '');
    		} else if ($('#cd-assoc-name').is(':visible')) {
    			$('.typeahead.dropdown-menu').hide();
    			$('#ncst-no-record-found').hide();
    		}
    	});
    	return clientInfoView;
    });